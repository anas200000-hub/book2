const CACHE_NAME = 'kids-games-cache-v47';
const ASSETS = [
    './',
    'index.html',
    'manifest.json',
    'css/style.css',
    'js/audio.js',
    'js/main.js',
    'js/games/animals.js',
    'js/games/coloring.js',
    'js/games/balloons.js',
    'js/games/memory.js',
    'js/games/shapes.js',
    'js/games/catch.js',
    'js/games/piano.js',
    'js/games/popit.js',
    'js/games/odd-one.js',
    'js/games/feed.js',
    'js/games/shadow.js',
    'js/games/counting.js',
    'js/games/fireworks.js',
    'js/games/dressup.js',
    'js/games/tictactoe.js',
    'js/games/whack.js',
    'js/games/english-letters.js',
    'js/games/arabic-letters.js',
    'js/games/numbers.js',
    'js/games/fruits.js',
    'js/games/halves-puzzle.js',
    'js/games/tangram-puzzle.js',
    'js/games/girls-dressup.js',
    'js/games/picture-puzzle.js',
    'js/games/jump-game.js',
    'js/games/math-game.js',
    'js/games/missing-item.js',
    'js/games/size-order.js',
    'js/games/word-scramble.js',
    'js/games/color-numbers.js',
    'js/games/cooking-game.js',
    'js/games/connect-dots.js',
    'assets/emojis/1f5bc.svg',
    'assets/emojis/1f3c3.svg',
    'assets/emojis/2795.svg',
    'assets/emojis/1f441.svg',
    'assets/emojis/1f4cf.svg',
    'assets/emojis/1f524.svg',
    'assets/emojis/1f58d.svg',
    'assets/emojis/1f373.svg',
    'assets/emojis/270f.svg',
    'assets/emojis/1f58a.svg',
    'assets/sounds/cat.mp3',
    'assets/sounds/chicken.mp3',
    'assets/sounds/cow.mp3',
    'assets/sounds/dog.mp3',
    'assets/sounds/duck.mp3',
    'assets/sounds/elephant.mp3',
    'assets/sounds/horse.mp3',
    'assets/sounds/lion.mp3',
    'assets/sounds/sheep.mp3',
    'assets/emojis/1f332.svg',
    'assets/emojis/1f347.svg',
    'assets/emojis/1f349.svg',
    'assets/emojis/1f34a.svg',
    'assets/emojis/1f34c.svg',
    'assets/emojis/1f34d.svg',
    'assets/emojis/1f34e.svg',
    'assets/emojis/1f352.svg',
    'assets/emojis/1f353.svg',
    'assets/emojis/1f366.svg',
    'assets/emojis/1f369.svg',
    'assets/emojis/1f36d.svg',
    'assets/emojis/1f37c.svg',
    'assets/emojis/1f380.svg',
    'assets/emojis/1f388.svg',
    'assets/emojis/1f3a8.svg',
    'assets/emojis/1f3a9.svg',
    'assets/emojis/1f3e0.svg',
    'assets/emojis/1f411.svg',
    'assets/emojis/1f412.svg',
    'assets/emojis/1f414.svg',
    'assets/emojis/1f418.svg',
    'assets/emojis/1f41f.svg',
    'assets/emojis/1f420.svg',
    'assets/emojis/1f424.svg',
    'assets/emojis/1f42b.svg',
    'assets/emojis/1f42e.svg',
    'assets/emojis/1f430.svg',
    'assets/emojis/1f431.svg',
    'assets/emojis/1f434.svg',
    'assets/emojis/1f436.svg',
    'assets/emojis/1f438.svg',
    'assets/emojis/1f451.svg',
    'assets/emojis/1f496.svg',
    'assets/emojis/1f4a3.svg',
    'assets/emojis/1f60b.svg',
    'assets/emojis/1f60e.svg',
    'assets/emojis/1f62d.svg',
    'assets/emojis/1f634.svg',
    'assets/emojis/1f680.svg',
    'assets/emojis/1f697.svg',
    'assets/emojis/1f913.svg',
    'assets/emojis/1f920.svg',
    'assets/emojis/1f922.svg',
    'assets/emojis/1f947.svg',
    'assets/emojis/1f955.svg',
    'assets/emojis/1f981.svg',
    'assets/emojis/1f986.svg',
    'assets/emojis/1f98b.svg',
    'assets/emojis/1f9c1.svg',
    'assets/emojis/1f9d9.svg',
    'assets/emojis/1f9e3.svg',
    'assets/emojis/1f9f8.svg',
    'assets/emojis/1fa98.svg',
    'assets/emojis/26bd.svg',
    'assets/emojis/2708.svg',
    'assets/emojis/2b50.svg',
    'assets/emojis/1f534.svg',
    'assets/emojis/1f7e6.svg',
    'assets/emojis/1f53a.svg',
    'assets/emojis/1f7e2.svg',
    'assets/emojis/1f319.svg',
    'assets/emojis/1f48e.svg',
    'assets/emojis/2600.svg',
    'assets/emojis/1f340.svg',
    'assets/emojis/1f4a7.svg',
    'assets/emojis/274c.svg',
    'assets/emojis/1f33f.svg',
    'assets/emojis/1f356.svg',
    'assets/emojis/1f969.svg',
    'assets/emojis/1f435.svg',
    'assets/emojis/1f638.svg',
    'assets/emojis/1f9e2.svg',
    'assets/emojis/1f452.svg',
    'assets/emojis/1f576.svg',
    'assets/emojis/1f453.svg',
    'assets/emojis/2b55.svg',
    'assets/emojis/1f9e0.svg',
    'assets/emojis/1f4d0.svg',
    'assets/emojis/1f3b9.svg',
    'assets/emojis/1f50d.svg',
    'assets/emojis/1f465.svg',
    'assets/emojis/1f522.svg',
    'assets/emojis/1f386.svg',
    'assets/emojis/1f520.svg',
    'assets/emojis/1f170.svg',
    'assets/emojis/1f9e9.svg',
    'assets/emojis/1f467.svg',
    'assets/emojis/1f335.svg',
    'assets/emojis/1fab9.svg',
    'assets/emojis/1f355.svg',
    'assets/emojis/1fa81.svg',
    'assets/emojis/1f9c3.svg',
    'assets/emojis/1f3bb.svg',
    'assets/emojis/1f40b.svg',
    'assets/emojis/1f3b5.svg',
    'assets/emojis/26f5.svg',
    'assets/emojis/1f993.svg',
    'assets/emojis/1f478.svg',
    'assets/emojis/1f302.svg',
    'assets/emojis/2602.svg',
    'assets/emojis/1f33a.svg',
    'assets/emojis/1f30a.svg',
    'assets/emojis/1f308.svg',
    'assets/emojis/1f42c.svg',
    'assets/emojis/1f42a.svg',
    'assets/emojis/1f43a.svg',
    'assets/emojis/1f985.svg',
    'assets/emojis/1f98c.svg',
    'assets/emojis/1f3c6.svg',
    'assets/emojis/1f381.svg',
    'assets/emojis/1f339.svg',
    'assets/emojis/1f54a.svg',
    'assets/emojis/1f334.svg',
    'assets/emojis/1f31f.svg',
    'assets/emojis/1f98a.svg',
    'assets/emojis/1f422.svg',
    'assets/emojis/1f419.svg',
    'assets/emojis/1f42f.svg',
    'assets/emojis/1f992.svg',
    'assets/emojis/1f427.svg',
    'assets/emojis/1f426.svg',
    'assets/emojis/1f382.svg',
    'assets/emojis/1f338.svg',
    'assets/emojis/1f34b.svg',
    'assets/emojis/1f415.svg',
    'assets/emojis/1f408.svg'
];

// Install Service Worker and cache resources
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Caching assets...');
                return cache.addAll(ASSETS);
            })
            .then(() => self.skipWaiting())
    );
});

// Activate Service Worker and clean old caches
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cache => {
                    if (cache !== CACHE_NAME) {
                        console.log('Clearing old cache...', cache);
                        return caches.delete(cache);
                    }
                })
            );
        }).then(() => self.clients.claim())
    );
});

// Fetch events: Network first, fallback to Cache
self.addEventListener('fetch', event => {
    event.respondWith(
        fetch(event.request)
            .then(response => {
                // If it is a valid response, cache it and return it
                if (response && response.status === 200) {
                    const responseClone = response.clone();
                    caches.open(CACHE_NAME).then(cache => {
                        cache.put(event.request, responseClone);
                    });
                }
                return response;
            })
            .catch(() => {
                // Network failed, try caching
                return caches.match(event.request);
            })
    );
});
