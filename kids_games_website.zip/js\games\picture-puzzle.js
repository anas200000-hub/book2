// 9-Piece Picture Puzzle Game for Kids
// Supports drag and drop of interlocking jigsaw puzzle shapes

(function() {
    // Configurations of edges for each of the 9 pieces in a 3x3 grid
    // 0 = straight (border), 1 = outward tab, -1 = inward tab
    const pieceConfigs = [
        [ // Row 0
            { top: 0, right: -1, bottom: -1, left: 0 },
            { top: 0, right: 1, bottom: -1, left: 1 },
            { top: 0, right: 0, bottom: -1, left: -1 }
        ],
        [ // Row 1
            { top: 1, right: -1, bottom: -1, left: 0 },
            { top: 1, right: -1, bottom: -1, left: 1 },
            { top: 1, right: 0, bottom: 1, left: 1 }
        ],
        [ // Row 2
            { top: 1, right: -1, bottom: 0, left: 0 },
            { top: 1, right: -1, bottom: 0, left: 1 },
            { top: -1, right: 0, bottom: 0, left: 1 }
        ]
    ];

    // Generate the path string relative to 0,0 - 100,100
    function generatePathString(cfg) {
        let d = "M 0,0";
        
        // Top edge
        if (cfg.top === 0) {
            d += " L 100,0";
        } else if (cfg.top === 1) {
            d += " L 35,0 C 35,-15 45,-20 50,-20 C 55,-20 65,-15 65,0 L 100,0";
        } else if (cfg.top === -1) {
            d += " L 35,0 C 35,15 45,20 50,20 C 55,20 65,15 65,0 L 100,0";
        }
        
        // Right edge
        if (cfg.right === 0) {
            d += " L 100,100";
        } else if (cfg.right === 1) {
            d += " L 100,35 C 115,35 120,45 120,50 C 120,55 115,65 100,65 L 100,100";
        } else if (cfg.right === -1) {
            d += " L 100,35 C 85,35 80,45 80,50 C 80,55 85,65 100,65 L 100,100";
        }
        
        // Bottom edge
        if (cfg.bottom === 0) {
            d += " L 0,100";
        } else if (cfg.bottom === 1) {
            d += " L 65,100 C 65,115 55,120 50,120 C 45,120 35,115 35,100 L 0,100";
        } else if (cfg.bottom === -1) {
            d += " L 65,100 C 65,85 55,80 50,80 C 45,80 35,85 35,100 L 0,100";
        }
        
        // Left edge
        if (cfg.left === 0) {
            d += " Z";
        } else if (cfg.left === 1) {
            d += " L 0,65 C -15,65 -20,55 -20,50 C -20,45 -15,35 0,35 Z";
        } else if (cfg.left === -1) {
            d += " L 0,65 C 15,65 20,55 20,50 C 20,45 15,35 0,35 Z";
        }
        
        return d;
    }

    // SVG Puzzles (6 options for more variety)
    const puzzles = [
        {
            name: "قوس قزح والشمس",
            svg: `
            <rect width="300" height="300" fill="#87CEEB"/>
            <circle cx="150" cy="200" r="130" fill="none" stroke="#FF3D00" stroke-width="15"/>
            <circle cx="150" cy="200" r="115" fill="none" stroke="#FF9100" stroke-width="15"/>
            <circle cx="150" cy="200" r="100" fill="none" stroke="#FFEA00" stroke-width="15"/>
            <circle cx="150" cy="200" r="85" fill="none" stroke="#00E676" stroke-width="15"/>
            <circle cx="150" cy="200" r="70" fill="none" stroke="#2979FF" stroke-width="15"/>
            <circle cx="150" cy="200" r="55" fill="none" stroke="#651FFF" stroke-width="15"/>
            <circle cx="150" cy="200" r="40" fill="none" stroke="#AA00FF" stroke-width="15"/>
            <circle cx="150" cy="200" r="32" fill="#87CEEB" />
            <rect y="230" width="300" height="70" fill="#4CAF50"/>
            <circle cx="50" cy="50" r="25" fill="#FFD700"/>
            <circle cx="230" cy="60" r="20" fill="#FFFFFF"/>
            <circle cx="255" cy="65" r="16" fill="#FFFFFF"/>
            <circle cx="210" cy="68" r="16" fill="#FFFFFF"/>
            <rect x="210" y="62" width="45" height="15" fill="#FFFFFF"/>
            <circle cx="100" cy="265" r="6" fill="#E91E63"/>
            <circle cx="94" cy="265" r="5" fill="#FFEB3B"/>
            <circle cx="106" cy="265" r="5" fill="#FFEB3B"/>
            <circle cx="100" cy="259" r="5" fill="#FFEB3B"/>
            <circle cx="100" cy="271" r="5" fill="#FFEB3B"/>
            <rect x="99" y="271" width="2" height="15" fill="#388E3C"/>
            <circle cx="200" cy="260" r="6" fill="#FF5722"/>
            <circle cx="194" cy="260" r="5" fill="#FFEB3B"/>
            <circle cx="206" cy="260" r="5" fill="#FFEB3B"/>
            <circle cx="200" cy="254" r="5" fill="#FFEB3B"/>
            <circle cx="200" cy="266" r="5" fill="#FFEB3B"/>
            <rect x="199" y="266" width="2" height="15" fill="#388E3C"/>
            `
        },
        {
            name: "القطة الكيوت",
            svg: `
            <rect width="300" height="300" fill="#FCE4EC"/>
            <polygon points="60,110 110,40 120,110" fill="#FF9800"/>
            <polygon points="65,105 100,50 110,105" fill="#F8BBD0"/>
            <polygon points="240,110 190,40 180,110" fill="#FF9800"/>
            <polygon points="235,105 200,50 190,105" fill="#F8BBD0"/>
            <ellipse cx="150" cy="155" rx="95" ry="75" fill="#FFB74D"/>
            <circle cx="110" cy="140" r="16" fill="#FFFFFF"/>
            <circle cx="110" cy="140" r="9" fill="#00ACC1"/>
            <circle cx="106" cy="136" r="4" fill="#FFFFFF"/>
            <circle cx="190" cy="140" r="16" fill="#FFFFFF"/>
            <circle cx="190" cy="140" r="9" fill="#00ACC1"/>
            <circle cx="186" cy="136" r="4" fill="#FFFFFF"/>
            <polygon points="150,165 140,156 160,156" fill="#F06292"/>
            <path d="M150,165 Q145,178 135,172 M150,165 Q155,178 165,172" fill="none" stroke="#37474F" stroke-width="3" stroke-linecap="round"/>
            <line x1="70" y1="160" x2="25" y2="152" stroke="#37474F" stroke-width="2.5" stroke-linecap="round"/>
            <line x1="70" y1="168" x2="20" y2="168" stroke="#37474F" stroke-width="2.5" stroke-linecap="round"/>
            <line x1="70" y1="176" x2="25" y2="184" stroke="#37474F" stroke-width="2.5" stroke-linecap="round"/>
            <line x1="230" y1="160" x2="275" y2="152" stroke="#37474F" stroke-width="2.5" stroke-linecap="round"/>
            <line x1="230" y1="168" x2="280" y2="168" stroke="#37474F" stroke-width="2.5" stroke-linecap="round"/>
            <line x1="230" y1="176" x2="275" y2="184" stroke="#37474F" stroke-width="2.5" stroke-linecap="round"/>
            <circle cx="85" cy="165" r="10" fill="#FF8A80" opacity="0.6"/>
            <circle cx="215" cy="165" r="10" fill="#FF8A80" opacity="0.6"/>
            `
        },
        {
            name: "الزهرة الكرتونية",
            svg: `
            <rect width="300" height="300" fill="#E0F7FA"/>
            <circle cx="40" cy="40" r="22" fill="#FFF59D"/>
            <path d="M150,140 L150,270" stroke="#81C784" stroke-width="12" stroke-linecap="round"/>
            <path d="M150,210 Q110,190 80,205 Q110,225 150,210" fill="#4CAF50"/>
            <path d="M150,180 Q190,160 220,175 Q190,195 150,180" fill="#4CAF50"/>
            <circle cx="150" cy="80" r="28" fill="#F48FB1"/>
            <circle cx="150" cy="200" r="28" fill="#F48FB1"/>
            <circle cx="90" cy="140" r="28" fill="#F48FB1"/>
            <circle cx="210" cy="140" r="28" fill="#F48FB1"/>
            <circle cx="108" cy="98" r="28" fill="#FFB74D"/>
            <circle cx="192" cy="98" r="28" fill="#FFB74D"/>
            <circle cx="108" cy="182" r="28" fill="#FFB74D"/>
            <circle cx="192" cy="182" r="28" fill="#FFB74D"/>
            <circle cx="150" cy="140" r="32" fill="#FFF176"/>
            <circle cx="150" cy="140" r="22" fill="#FBC02D"/>
            <ellipse cx="245" cy="65" rx="8" ry="12" fill="#AB47BC" transform="rotate(15 245 65)"/>
            <ellipse cx="257" cy="70" rx="6" ry="10" fill="#AB47BC" transform="rotate(15 257 70)"/>
            <ellipse cx="250" cy="75" rx="3" ry="8" fill="#3F51B5" transform="rotate(15 250 75)"/>
            `
        },
        {
            name: "الدبدوب اللطيف",
            svg: `
            <rect width="300" height="300" fill="#FFF9C4"/>
            <circle cx="80" cy="100" r="30" fill="#8D6E63"/>
            <circle cx="80" cy="100" r="18" fill="#F8BBD0"/>
            <circle cx="220" cy="100" r="30" fill="#8D6E63"/>
            <circle cx="220" cy="100" r="18" fill="#F8BBD0"/>
            <circle cx="150" cy="170" r="75" fill="#A1887F"/>
            <ellipse cx="150" cy="195" rx="30" ry="22" fill="#D7CCC8"/>
            <circle cx="120" cy="150" r="10" fill="#3E2723"/>
            <circle cx="120" cy="148" r="3.5" fill="#FFFFFF"/>
            <circle cx="180" cy="150" r="10" fill="#3E2723"/>
            <circle cx="180" cy="148" r="3.5" fill="#FFFFFF"/>
            <ellipse cx="150" cy="188" rx="12" ry="8" fill="#3E2723"/>
            <path d="M150,196 C145,206 138,202 138,202 M150,196 C155,206 162,202 162,202" fill="none" stroke="#3E2723" stroke-width="3" stroke-linecap="round"/>
            <circle cx="95" cy="175" r="9" fill="#FF8A80" opacity="0.6"/>
            <circle cx="205" cy="175" r="9" fill="#FF8A80" opacity="0.6"/>
            `
        },
        {
            name: "السمكة الذهبية",
            svg: `
            <rect width="300" height="300" fill="#E0F2F1"/>
            <path d="M40,300 Q60,200 30,120" fill="none" stroke="#00897B" stroke-width="8" stroke-linecap="round"/>
            <path d="M260,300 Q240,220 270,150" fill="none" stroke="#00897B" stroke-width="8" stroke-linecap="round"/>
            <circle cx="90" cy="90" r="10" fill="none" stroke="#26A69A" stroke-width="2" opacity="0.7"/>
            <circle cx="100" cy="60" r="6" fill="none" stroke="#26A69A" stroke-width="1.5" opacity="0.7"/>
            <circle cx="80" cy="130" r="14" fill="none" stroke="#26A69A" stroke-width="2.5" opacity="0.7"/>
            <polygon points="70,150 20,110 35,150 20,190" fill="#FF7043"/>
            <ellipse cx="140" cy="150" rx="65" ry="48" fill="#FFAB91"/>
            <path d="M140,102 Q160,70 180,105" fill="#FF7043"/>
            <path d="M130,198 Q145,220 160,195" fill="#FF7043"/>
            <circle cx="175" cy="135" r="12" fill="#FFFFFF"/>
            <circle cx="177" cy="135" r="6" fill="#37474F"/>
            <circle cx="175" cy="133" r="3.5" fill="#FFFFFF"/>
            <path d="M200,160 Q190,165 180,160" fill="none" stroke="#D84315" stroke-width="3" stroke-linecap="round"/>
            <path d="M110,135 Q115,142 110,150 M125,140 Q130,147 125,155 M115,155 Q120,162 115,170" fill="none" stroke="#FF7043" stroke-width="2.5"/>
            `
        },
        {
            name: "صاروخ الفضاء",
            svg: `
            <rect width="300" height="300" fill="#1A237E"/>
            <circle cx="50" cy="60" r="2" fill="#FFF"/>
            <circle cx="250" cy="50" r="3" fill="#FFF"/>
            <circle cx="280" cy="220" r="2" fill="#FFF"/>
            <circle cx="70" cy="250" r="3.5" fill="#FFF"/>
            <circle cx="130" cy="30" r="1.5" fill="#FFF"/>
            <circle cx="240" cy="80" r="25" fill="#FFF59D"/>
            <circle cx="225" cy="80" r="22" fill="#1A237E"/>
            <polygon points="120,230 150,280 180,230" fill="#FF3D00"/>
            <polygon points="130,230 150,265 170,230" fill="#FFD600"/>
            <path d="M150,60 Q120,130 120,220 L180,220 Q180,130 150,60 Z" fill="#ECEFF1"/>
            <polygon points="120,180 90,220 120,220" fill="#3F51B5"/>
            <polygon points="180,180 210,220 180,220" fill="#3F51B5"/>
            <path d="M150,60 Q130,95 124,110 L176,110 Q170,95 150,60 Z" fill="#FF1744"/>
            <circle cx="150" cy="140" r="16" fill="#00E5FF" stroke="#37474F" stroke-width="3"/>
            <circle cx="146" cy="136" r="5" fill="#FFF" opacity="0.7"/>
            `
        }
    ];

    window.initPicturePuzzleGame = function(container) {
        container.innerHTML = "";

        let currentPuzzleIdx = 0;
        let matchedCount = 0;
        const clipSeed = Math.floor(Math.random() * 10000);

        // Header Control Area
        const controls = document.createElement("div");
        controls.style.display = "flex";
        controls.style.flexDirection = "column";
        controls.style.alignItems = "center";
        controls.style.gap = "10px";
        controls.style.marginBottom = "15px";
        controls.style.width = "100%";

        const title = document.createElement("h2");
        title.className = "game-title";
        title.innerText = "تركيب الصور الكيوت";
        title.style.margin = "5px 0";
        title.style.fontSize = "24px";
        title.style.color = "#4A148C";
        controls.appendChild(title);

        // Selector for Puzzles
        const selectorContainer = document.createElement("div");
        selectorContainer.style.display = "flex";
        selectorContainer.style.gap = "8px";
        selectorContainer.style.justifyContent = "center";
        selectorContainer.style.flexWrap = "wrap";

        puzzles.forEach((p, idx) => {
            const btn = document.createElement("button");
            btn.className = "menu-btn";
            btn.innerText = p.name;
            btn.style.padding = "6px 12px";
            btn.style.fontSize = "14px";
            btn.style.borderRadius = "20px";
            btn.style.border = "none";
            btn.style.cursor = "pointer";
            btn.style.background = idx === currentPuzzleIdx ? "#7C4DFF" : "#E0E0E0";
            btn.style.color = idx === currentPuzzleIdx ? "#FFF" : "#333";
            btn.style.transition = "all 0.2s";

            btn.addEventListener("click", () => {
                if (window.sound) window.sound.playClick();
                currentPuzzleIdx = idx;
                setupGame();
            });
            selectorContainer.appendChild(btn);
        });
        controls.appendChild(selectorContainer);
        container.appendChild(controls);

        // Game Area Layout
        const gameLayout = document.createElement("div");
        gameLayout.style.display = "flex";
        gameLayout.style.flexDirection = "column";
        gameLayout.style.alignItems = "center";
        gameLayout.style.gap = "20px";
        gameLayout.style.width = "100%";
        container.appendChild(gameLayout);

        // Preview and Board side-by-side or stacked
        const mainStage = document.createElement("div");
        mainStage.style.display = "flex";
        mainStage.style.flexDirection = "row";
        mainStage.style.flexWrap = "wrap";
        mainStage.style.justifyContent = "center";
        mainStage.style.alignItems = "center";
        mainStage.style.gap = "20px";
        gameLayout.appendChild(mainStage);

        // Small target preview
        const previewBox = document.createElement("div");
        previewBox.style.display = "flex";
        previewBox.style.flexDirection = "column";
        previewBox.style.alignItems = "center";
        previewBox.style.gap = "5px";

        const previewLabel = document.createElement("div");
        previewLabel.innerText = "الصورة الكاملة الدليل:";
        previewLabel.style.fontSize = "14px";
        previewLabel.style.fontWeight = "bold";
        previewLabel.style.color = "#555";
        previewBox.appendChild(previewLabel);

        const previewSvgContainer = document.createElement("div");
        previewSvgContainer.style.width = "100px";
        previewSvgContainer.style.height = "100px";
        previewSvgContainer.style.border = "3px solid #FFF";
        previewSvgContainer.style.borderRadius = "8px";
        previewSvgContainer.style.boxShadow = "0 4px 8px rgba(0,0,0,0.1)";
        previewSvgContainer.style.overflow = "hidden";
        previewBox.appendChild(previewSvgContainer);
        mainStage.appendChild(previewBox);

        // Puzzle Board
        const board = document.createElement("div");
        board.style.width = "300px";
        board.style.height = "300px";
        board.style.background = "#ECEFF1";
        board.style.borderRadius = "12px";
        board.style.boxShadow = "inset 0 4px 10px rgba(0,0,0,0.15), 0 8px 16px rgba(0,0,0,0.1)";
        board.style.display = "grid";
        board.style.gridTemplateColumns = "repeat(3, 100px)";
        board.style.gridTemplateRows = "repeat(3, 100px)";
        board.style.position = "relative";
        board.style.direction = "ltr"; // Force LTR to keep column 0 on the left
        mainStage.appendChild(board);

        // Palette for shuffled pieces
        const palette = document.createElement("div");
        palette.style.width = "100%";
        palette.style.maxWidth = "450px";
        palette.style.minHeight = "120px";
        palette.style.background = "rgba(255, 255, 255, 0.6)";
        palette.style.border = "2px dashed #B0BEC5";
        palette.style.borderRadius = "16px";
        palette.style.padding = "15px";
        palette.style.boxSizing = "border-box";
        palette.style.display = "flex";
        palette.style.flexWrap = "wrap";
        palette.style.justifyContent = "center";
        palette.style.alignItems = "center";
        palette.style.gap = "15px";
        palette.style.position = "relative";
        palette.style.direction = "ltr"; // Force LTR for consistency
        gameLayout.appendChild(palette);

        // Add a Restart Button
        const restartBtn = document.createElement("button");
        restartBtn.className = "menu-btn restart-btn";
        restartBtn.innerText = "إعادة اللعب 🔄";
        restartBtn.style.padding = "10px 20px";
        restartBtn.style.fontSize = "16px";
        restartBtn.style.background = "#FF9800";
        restartBtn.style.color = "#FFF";
        restartBtn.style.border = "none";
        restartBtn.style.borderRadius = "25px";
        restartBtn.style.cursor = "pointer";
        restartBtn.style.boxShadow = "0 4px 6px rgba(0,0,0,0.15)";
        restartBtn.addEventListener("click", () => {
            if (window.sound) window.sound.playClick();
            setupGame();
        });
        gameLayout.appendChild(restartBtn);

        // Set up the puzzle game state
        function setupGame() {
            // Update selectors
            Array.from(selectorContainer.children).forEach((btn, idx) => {
                btn.style.background = idx === currentPuzzleIdx ? "#7C4DFF" : "#E0E0E0";
                btn.style.color = idx === currentPuzzleIdx ? "#FFF" : "#333";
            });

            matchedCount = 0;
            board.innerHTML = "";
            palette.innerHTML = "";

            const activePuzzle = puzzles[currentPuzzleIdx];

            // Render small preview
            previewSvgContainer.innerHTML = `
                <svg viewBox="0 0 300 300" width="100%" height="100%">
                    ${activePuzzle.svg}
                </svg>
            `;

            // Create board slots
            const slots = [];
            for (let r = 0; r < 3; r++) {
                for (let c = 0; c < 3; c++) {
                    const slot = document.createElement("div");
                    slot.style.width = "100px";
                    slot.style.height = "100px";
                    slot.style.position = "relative";
                    slot.style.boxSizing = "border-box";
                    
                    // Draw slot dotted puzzle shape guide
                    const pcfg = pieceConfigs[r][c];
                    const pathStr = generatePathString(pcfg);
                    
                    slot.innerHTML = `
                        <svg viewBox="${c*100 - 20} ${r*100 - 20} 140 140" width="140" height="140" style="position: absolute; left: -20px; top: -20px; pointer-events: none; opacity: 0.25; z-index: 1;">
                            <path d="${pathStr}" transform="translate(${c*100}, ${r*100})" fill="#CFD8DC" stroke="#455A64" stroke-width="2" stroke-dasharray="3 3"/>
                        </svg>
                    `;
                    
                    board.appendChild(slot);
                    slots.push({ row: r, col: c, element: slot });
                }
            }

            // Create piece elements
            const pieces = [];
            for (let r = 0; r < 3; r++) {
                for (let c = 0; c < 3; c++) {
                    const pcfg = pieceConfigs[r][c];
                    const pathStr = generatePathString(pcfg);
                    const clipId = `clip-${r}-${c}-${clipSeed}`;

                    // Create standalone piece SVG (100px size for consistency)
                    const pieceEl = document.createElement("div");
                    pieceEl.style.width = "100px";
                    pieceEl.style.height = "100px";
                    pieceEl.style.cursor = "grab";
                    pieceEl.style.position = "relative";
                    pieceEl.style.touchAction = "none";
                    pieceEl.style.zIndex = "10";
                    pieceEl.dataset.row = r;
                    pieceEl.dataset.col = c;

                    // Centered SVG with left: -20px and top: -20px matching 140px width on 100px div
                    pieceEl.innerHTML = `
                        <svg viewBox="${c*100 - 20} ${r*100 - 20} 140 140" width="140" height="140" style="position: absolute; left: -20px; top: -20px; pointer-events: none; overflow: visible;">
                            <defs>
                                <clipPath id="${clipId}">
                                    <path d="${pathStr}" transform="translate(${c*100}, ${r*100})" />
                                </clipPath>
                            </defs>
                            <!-- Drop Shadow/Outer Border glow -->
                            <path d="${pathStr}" transform="translate(${c*100}, ${r*100})" fill="none" stroke="rgba(0,0,0,0.15)" stroke-width="5" />
                            <!-- Clipped image content -->
                            <g clip-path="url(#${clipId})">
                                ${activePuzzle.svg}
                            </g>
                            <!-- Piece border -->
                            <path d="${pathStr}" transform="translate(${c*100}, ${r*100})" fill="none" stroke="#FFFFFF" stroke-width="2" />
                        </svg>
                    `;

                    // Drag & Drop logic using pointer events
                    pieceEl.addEventListener("pointerdown", onPointerDown);

                    pieces.push(pieceEl);
                }
            }

            // Shuffle pieces and add to palette
            const shuffled = [...pieces].sort(() => Math.random() - 0.5);
            shuffled.forEach(p => palette.appendChild(p));
        }

        // Pointer Drag Handler
        function onPointerDown(e) {
            e.preventDefault();
            const piece = e.currentTarget;
            piece.style.cursor = "grabbing";
            piece.style.zIndex = "1000";

            if (window.sound) window.sound.playClick();

            const rect = piece.getBoundingClientRect();
            // Start offset relative to the piece element top-left
            const offsetX = e.clientX - rect.left;
            const offsetY = e.clientY - rect.top;

            // Remember the parent elements/positions in case we need to return
            const originalParent = piece.parentElement;
            const originalPosition = {
                left: piece.style.left,
                top: piece.style.top,
                position: piece.style.position,
                width: piece.style.width,
                height: piece.style.height
            };

            const containerRect = container.getBoundingClientRect();
            
            piece.style.position = "absolute";
            // Place initially matching the client position relative to game layout
            updatePosition(e.clientX, e.clientY);
            container.appendChild(piece);

            function updatePosition(clientX, clientY) {
                const targetX = clientX - containerRect.left - offsetX;
                const targetY = clientY - containerRect.top - offsetY;
                piece.style.left = `${targetX}px`;
                piece.style.top = `${targetY}px`;
                piece.style.width = "100px";
                piece.style.height = "100px";
            }

            function onPointerMove(moveEvt) {
                updatePosition(moveEvt.clientX, moveEvt.clientY);
            }

            function onPointerUp(upEvt) {
                window.removeEventListener("pointermove", onPointerMove);
                window.removeEventListener("pointerup", onPointerUp);

                piece.style.cursor = "grab";
                piece.style.zIndex = "10";

                // Check collision with the target slot on board
                const targetRow = parseInt(piece.dataset.row);
                const targetCol = parseInt(piece.dataset.col);
                
                // Get corresponding slot element
                const slots = board.children;
                const slotIndex = targetRow * 3 + targetCol;
                const targetSlot = slots[slotIndex];

                // Calculate board's position relative to the container
                const boardRect = board.getBoundingClientRect();
                const currentContainerRect = container.getBoundingClientRect();
                const boardLeftInContainer = boardRect.left - currentContainerRect.left;
                const boardTopInContainer = boardRect.top - currentContainerRect.top;

                // The correct left and top of the piece relative to the container
                const correctLeft = boardLeftInContainer + targetCol * 100;
                const correctTop = boardTopInContainer + targetRow * 100;

                // The current left and top of the piece relative to the container
                const currentLeft = parseFloat(piece.style.left);
                const currentTop = parseFloat(piece.style.top);

                const dx = currentLeft - correctLeft;
                const dy = currentTop - correctTop;
                const distance = Math.hypot(dx, dy);

                // Forgiving snapping threshold (60px instead of 40px)
                if (distance < 60) {
                    // Match! Snap to board
                    piece.style.position = "absolute";
                    piece.style.left = "0px";
                    piece.style.top = "0px";
                    piece.style.width = "100px";
                    piece.style.height = "100px";
                    
                    const svgEl = piece.querySelector("svg");
                    svgEl.style.left = "-20px";
                    svgEl.style.top = "-20px";
                    svgEl.style.width = "140px";
                    svgEl.style.height = "140px";

                    targetSlot.appendChild(piece);
                    piece.removeEventListener("pointerdown", onPointerDown);
                    piece.style.cursor = "default";

                    // Play pop/bubble sound
                    if (window.sound) window.sound.playBubble();

                    // Snap animation bounce
                    piece.classList.add("bounce-anim");
                    setTimeout(() => piece.classList.remove("bounce-anim"), 500);

                    matchedCount++;
                    checkVictory();
                } else {
                    // Fail to match - return to palette
                    piece.classList.add("shake-anim");
                    if (window.sound) window.sound.playFail();

                    // Animate back
                    piece.style.position = originalPosition.position;
                    piece.style.left = originalPosition.left;
                    piece.style.top = originalPosition.top;
                    piece.style.width = originalPosition.width;
                    piece.style.height = originalPosition.height;

                    const svgEl = piece.querySelector("svg");
                    svgEl.style.left = "-20px";
                    svgEl.style.top = "-20px";
                    svgEl.style.width = "140px";
                    svgEl.style.height = "140px";

                    originalParent.appendChild(piece);

                    setTimeout(() => piece.classList.remove("shake-anim"), 500);
                }
            }

            window.addEventListener("pointermove", onPointerMove);
            window.addEventListener("pointerup", onPointerUp);
        }

        // Check if all 9 pieces are placed
        function checkVictory() {
            if (matchedCount === 9) {
                setTimeout(() => {
                    if (window.sound) window.sound.playSuccess();
                    
                    // Show Victory Modal
                    const modal = document.createElement("div");
                    modal.className = "game-modal";
                    modal.style.position = "absolute";
                    modal.style.top = "50%";
                    modal.style.left = "50%";
                    modal.style.transform = "translate(-50%, -50%)";
                    modal.style.background = "#FFF";
                    modal.style.padding = "25px";
                    modal.style.borderRadius = "20px";
                    modal.style.boxShadow = "0 10px 30px rgba(0,0,0,0.3)";
                    modal.style.textAlign = "center";
                    modal.style.zIndex = "10000";
                    modal.style.width = "85%";
                    modal.style.maxWidth = "320px";

                    modal.innerHTML = `
                        <h2 style="color: #4CAF50; margin: 0 0 10px 0; font-size: 26px;">ممتاز! رائع جداً 🎉</h2>
                        <p style="color: #555; margin: 0 0 20px 0; font-size: 16px;">لقد قمت بتركيب الصورة كاملة بنجاح!</p>
                        <button class="menu-btn restart-btn" style="background:#7C4DFF; color:#FFF; border:none; padding:10px 20px; font-size:16px; border-radius:25px; cursor:pointer;">العب مرة أخرى 🔄</button>
                    `;

                    modal.querySelector("button").addEventListener("click", () => {
                        if (window.sound) window.sound.playClick();
                        modal.remove();
                        setupGame();
                    });

                    container.appendChild(modal);
                }, 600);
            }
        }

        // Run game initial setup
        setupGame();
    };
})();
