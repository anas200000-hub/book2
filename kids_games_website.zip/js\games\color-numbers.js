// تلوين بالأرقام - Color by Numbers Game
(function() {
    window.initColorNumbersGame = function(container) {
        container.innerHTML = "";

        const palette = [
            { num: 1, color: '#FF1744', label: 'أحمر' },
            { num: 2, color: '#FF9100', label: 'برتقالي' },
            { num: 3, color: '#FFD600', label: 'أصفر' },
            { num: 4, color: '#00C853', label: 'أخضر' },
            { num: 5, color: '#2979FF', label: 'أزرق' },
            { num: 6, color: '#AA00FF', label: 'بنفسجي' },
            { num: 7, color: '#FF4081', label: 'وردي' },
            { num: 8, color: '#A1887F', label: 'بني' },
        ];

        // Drawings: each region has id, fill number, and SVG path
        const drawings = [
            {
                name: 'شمس مشرقة',
                emoji: '☀️',
                viewBox: '0 0 200 200',
                regions: [
                    // sky
                    { id:'sky', num:5, d:'M0,0 H200 V140 H0 Z', label:'السماء' },
                    // ground
                    { id:'ground', num:4, d:'M0,140 H200 V200 H0 Z', label:'الأرض' },
                    // sun body
                    { id:'sunBody', num:3, cx:100, cy:70, r:35, type:'circle', label:'الشمس' },
                    // sun rays - top
                    { id:'ray1', num:2, d:'M100,25 L95,10 L105,10 Z', label:'الشعاع' },
                    { id:'ray2', num:2, d:'M100,115 L95,130 L105,130 Z', label:'الشعاع' },
                    { id:'ray3', num:2, d:'M55,70 L40,65 L40,75 Z', label:'الشعاع' },
                    { id:'ray4', num:2, d:'M145,70 L160,65 L160,75 Z', label:'الشعاع' },
                    { id:'ray5', num:2, d:'M68,37 L58,25 L65,20 Z', label:'الشعاع' },
                    { id:'ray6', num:2, d:'M132,37 L142,25 L135,20 Z', label:'الشعاع' },
                    { id:'ray7', num:2, d:'M68,103 L58,115 L65,120 Z', label:'الشعاع' },
                    { id:'ray8', num:2, d:'M132,103 L142,115 L135,120 Z', label:'الشعاع' },
                    // cloud
                    { id:'cloud', num:0, cx:160, cy:40, r:18, type:'cloud', label:'السحابة' },
                ]
            },
            {
                name: 'قلب ملون',
                emoji: '💖',
                viewBox: '0 0 200 200',
                regions: [
                    { id:'bg', num:3, d:'M0,0 H200 V200 H0 Z', label:'الخلفية' },
                    { id:'heart', num:1, d:'M100,155 C60,125 20,100 20,65 C20,40 40,20 65,20 C80,20 95,30 100,45 C105,30 120,20 135,20 C160,20 180,40 180,65 C180,100 140,125 100,155 Z', label:'القلب' },
                    { id:'star1', num:3, d:'M40,160 L43,150 L46,160 L56,160 L48,166 L51,176 L40,170 L29,176 L32,166 L24,160 Z', label:'نجمة' },
                    { id:'star2', num:3, d:'M160,160 L163,150 L166,160 L176,160 L168,166 L171,176 L160,170 L149,176 L152,166 L144,160 Z', label:'نجمة' },
                ]
            },
            {
                name: 'فراشة جميلة',
                emoji: '🦋',
                viewBox: '0 0 200 200',
                regions: [
                    { id:'bgb', num:5, d:'M0,0 H200 V200 H0 Z', label:'الخلفية' },
                    // wings
                    { id:'wingTL', num:7, d:'M100,100 C80,60 30,40 20,80 C10,110 50,130 100,100 Z', label:'جناح علوي' },
                    { id:'wingTR', num:6, d:'M100,100 C120,60 170,40 180,80 C190,110 150,130 100,100 Z', label:'جناح علوي' },
                    { id:'wingBL', num:2, d:'M100,100 C70,120 30,130 40,160 C50,180 90,165 100,100 Z', label:'جناح سفلي' },
                    { id:'wingBR', num:3, d:'M100,100 C130,120 170,130 160,160 C150,180 110,165 100,100 Z', label:'جناح سفلي' },
                    // body
                    { id:'bodyB', num:8, d:'M97,50 C97,50 95,100 95,130 C95,135 105,135 105,130 C105,100 103,50 103,50 Z', label:'الجسم' },
                    // antennae dots
                    { id:'dot1', num:4, cx:85, cy:42, r:6, type:'circle', label:'قرن' },
                    { id:'dot2', num:4, cx:115, cy:42, r:6, type:'circle', label:'قرن' },
                ]
            }
        ];

        let drawIdx = 0;
        let filledMap = {};
        let totalRegions = 0;
        let filledCount = 0;
        let selectedNum = 1;

        const wrap = document.createElement('div');
        wrap.style.cssText = 'display:flex;flex-direction:column;align-items:center;width:100%;max-width:400px;margin:0 auto;padding:10px;box-sizing:border-box;';
        container.appendChild(wrap);

        const title = document.createElement('h2');
        title.className = 'game-title';
        title.innerText = 'لون بالأرقام 🖍️';
        title.style.cssText = 'color:#E65100;margin-bottom:8px;';
        wrap.appendChild(title);

        // Drawing selector
        const selectorRow = document.createElement('div');
        selectorRow.style.cssText = 'display:flex;gap:8px;margin-bottom:10px;';
        wrap.appendChild(selectorRow);
        drawings.forEach((d, i) => {
            const btn = document.createElement('button');
            btn.innerText = d.emoji + ' ' + d.name;
            btn.style.cssText = `flex:1;padding:6px 4px;font-size:12px;font-weight:bold;border:2px solid #FF7043;border-radius:20px;background:${i===0?'#FF7043':'#FFF'};color:${i===0?'#FFF':'#FF7043'};cursor:pointer;transition:all 0.2s;`;
            btn.addEventListener('click', () => {
                document.querySelectorAll('.draw-sel-btn').forEach((b,j) => {
                    b.style.background = j===i?'#FF7043':'#FFF';
                    b.style.color = j===i?'#FFF':'#FF7043';
                });
                drawIdx = i;
                filledMap = {};
                filledCount = 0;
                renderDrawing();
            });
            btn.classList.add('draw-sel-btn');
            selectorRow.appendChild(btn);
        });

        // SVG canvas area
        const svgWrap = document.createElement('div');
        svgWrap.style.cssText = 'background:#FFF;border-radius:20px;padding:8px;box-shadow:0 6px 16px rgba(0,0,0,0.12);margin-bottom:12px;width:100%;max-width:240px;';
        wrap.appendChild(svgWrap);

        // Palette
        const paletteEl = document.createElement('div');
        paletteEl.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap;justify-content:center;width:100%;margin-bottom:12px;';
        wrap.appendChild(paletteEl);

        // Build palette
        palette.forEach(p => {
            const btn = document.createElement('button');
            btn.id = `colbtn_${p.num}`;
            btn.style.cssText = `width:40px;height:40px;border-radius:50%;background:${p.color};border:3px solid ${p.num===selectedNum?'#000':'transparent'};cursor:pointer;transition:transform 0.1s;position:relative;box-shadow:0 3px 6px rgba(0,0,0,0.2);`;
            const numLabel = document.createElement('span');
            numLabel.innerText = p.num;
            numLabel.style.cssText = 'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:14px;font-weight:bold;color:#FFF;text-shadow:0 1px 2px rgba(0,0,0,0.7);';
            btn.appendChild(numLabel);
            btn.addEventListener('click', () => {
                selectedNum = p.num;
                document.querySelectorAll('[id^="colbtn_"]').forEach(b => b.style.border = '3px solid transparent');
                btn.style.border = `3px solid #000`;
                btn.style.transform = 'scale(1.2)';
                setTimeout(() => btn.style.transform = 'scale(1)', 150);
            });
            paletteEl.appendChild(btn);
        });

        // Progress
        const progressEl = document.createElement('div');
        progressEl.style.cssText = 'font-size:13px;color:#777;text-align:center;';
        wrap.appendChild(progressEl);

        function getColor(num) {
            if (num === 0) return '#FFFFFF';
            const p = palette.find(x => x.num === num);
            return p ? p.color : '#E0E0E0';
        }

        function renderDrawing() {
            const draw = drawings[drawIdx];
            totalRegions = draw.regions.filter(r => r.num > 0).length;

            let svgContent = `<svg viewBox="${draw.viewBox}" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:auto;border-radius:14px;">`;
            draw.regions.forEach(region => {
                const filled = filledMap[region.id];
                const fillColor = filled ? getColor(filled) : '#F5F5F5';
                const stroke = filled ? 'rgba(0,0,0,0.1)' : '#BDBDBD';
                const numColor = filled ? 'transparent' : '#757575';
                let el = '';
                if (region.type === 'circle') {
                    el = `<circle id="region_${region.id}" cx="${region.cx}" cy="${region.cy}" r="${region.r}" fill="${fillColor}" stroke="${stroke}" stroke-width="1.5" style="cursor:pointer"/>`;
                    if (!filled && region.num > 0) el += `<text x="${region.cx}" y="${region.cy+5}" text-anchor="middle" font-size="10" fill="${numColor}" style="pointer-events:none">${region.num}</text>`;
                } else if (region.type === 'cloud') {
                    el = `<circle id="region_${region.id}" cx="${region.cx}" cy="${region.cy}" r="${region.r}" fill="${fillColor}" stroke="${stroke}" stroke-width="1.5" style="cursor:pointer"/>
                    <circle cx="${region.cx-12}" cy="${region.cy+4}" r="${region.r*0.7}" fill="${fillColor}" stroke="${stroke}" stroke-width="1.5" style="pointer-events:none"/>
                    <circle cx="${region.cx+12}" cy="${region.cy+4}" r="${region.r*0.7}" fill="${fillColor}" stroke="${stroke}" stroke-width="1.5" style="pointer-events:none"/>`;
                    if (!filled && region.num > 0) el += `<text x="${region.cx}" y="${region.cy+5}" text-anchor="middle" font-size="10" fill="${numColor}" style="pointer-events:none">☁️</text>`;
                } else {
                    const centroid = getCentroid(region.d);
                    el = `<path id="region_${region.id}" d="${region.d}" fill="${fillColor}" stroke="${stroke}" stroke-width="1.5" style="cursor:pointer"/>`;
                    if (!filled && region.num > 0) el += `<text x="${centroid.x}" y="${centroid.y}" text-anchor="middle" font-size="11" fill="${numColor}" style="pointer-events:none">${region.num}</text>`;
                }
                svgContent += el;
            });
            svgContent += '</svg>';

            svgWrap.innerHTML = svgContent;

            // Add event listeners
            draw.regions.forEach(region => {
                const el = svgWrap.querySelector(`#region_${region.id}`);
                if (el) {
                    el.addEventListener('click', () => {
                        if (region.num === 0) { filledMap[region.id] = 0; renderDrawing(); return; }
                        if (selectedNum === region.num) {
                            if (!filledMap[region.id]) { filledCount++; }
                            filledMap[region.id] = selectedNum;
                            if (window.sound) window.sound.playClick();
                            renderDrawing();
                            if (filledCount >= totalRegions) showWin();
                        } else {
                            el.style.animation = 'shake-anim 0.3s';
                            setTimeout(() => el.style.animation = '', 300);
                        }
                    });
                }
            });

            progressEl.innerText = `الملوّن: ${filledCount} / ${totalRegions} منطقة`;
        }

        function getCentroid(d) {
            const nums = d.match(/[0-9.]+/g);
            if (!nums || nums.length < 2) return { x: 100, y: 100 };
            let xs = [], ys = [];
            for (let i=0; i<nums.length-1; i+=2) {
                xs.push(parseFloat(nums[i]));
                ys.push(parseFloat(nums[i+1]));
            }
            return {
                x: xs.reduce((a,b)=>a+b,0)/xs.length,
                y: ys.reduce((a,b)=>a+b,0)/ys.length
            };
        }

        function showWin() {
            if (window.sound) window.sound.playSuccess();
            const modal = document.createElement('div');
            modal.style.cssText = 'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:#FFF;padding:25px;border-radius:24px;box-shadow:0 10px 30px rgba(0,0,0,0.3);text-align:center;z-index:10000;width:80%;max-width:300px;';
            modal.innerHTML = `<div style="font-size:56px">🎨</div><h3 style="color:#E65100;margin:8px 0;font-size:22px;">لوحة رائعة!</h3><p style="color:#555;">أنت فنان موهوب!</p><button class="menu-btn" style="background:#E65100;color:#FFF;border:none;padding:10px 20px;font-size:16px;border-radius:25px;cursor:pointer;margin-top:10px;">لون لوحة أخرى 🔄</button>`;
            modal.querySelector('button').addEventListener('click', () => {
                modal.remove();
                drawIdx = (drawIdx+1) % drawings.length;
                filledMap = {};
                filledCount = 0;
                renderDrawing();
            });
            container.appendChild(modal);
        }

        renderDrawing();
    };
})();
