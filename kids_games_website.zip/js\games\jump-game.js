// Super Mario style Kids Jump Game
// Canvas-based platform running and jumping game with 5 levels and 3 lives

(function() {
    window.initJumpGame = function(container) {
        container.innerHTML = "";

        // Game state variables
        let level = 1;
        let score = 0;
        let lives = 5;
        let timeRemaining = 15; // 15 seconds per level
        let gameActive = false;
        let gameTimerInterval = null;
        let animationFrameId = null;

        // Colors for levels
        const levelThemes = [
            { sky: "#CE93D8", ground: "#81C784", name: "المرحلة الأولى: حديقة المغامرات" },
            { sky: "#90CAF9", ground: "#AED581", name: "المرحلة الثانية: الوادي الأخضر" },
            { sky: "#80DEEA", ground: "#D4E157", name: "المرحلة الثالثة: السماء الزرقاء" },
            { sky: "#FFF59D", ground: "#FFD54F", name: "المرحلة الرابعة: شروق الشمس" },
            { sky: "#FFCC80", ground: "#FF8A65", name: "المرحلة الخامسة: أرض الأحلام" }
        ];

        // Container structure
        const wrapper = document.createElement("div");
        wrapper.style.display = "flex";
        wrapper.style.flexDirection = "column";
        wrapper.style.alignItems = "center";
        wrapper.style.position = "relative";
        wrapper.style.width = "100%";
        wrapper.style.maxWidth = "360px";
        wrapper.style.margin = "0 auto";
        container.appendChild(wrapper);

        // Header controls (Level, Lives, Timer, Score)
        const header = document.createElement("div");
        header.style.width = "100%";
        header.style.display = "flex";
        header.style.justifyContent = "space-between";
        header.style.alignItems = "center";
        header.style.marginBottom = "10px";
        header.style.padding = "5px 10px";
        header.style.background = "#FFF";
        header.style.borderRadius = "12px";
        header.style.boxShadow = "0 3px 6px rgba(0,0,0,0.1)";
        header.style.boxSizing = "border-box";
        wrapper.appendChild(header);

        const levelInfo = document.createElement("div");
        levelInfo.style.fontSize = "14px";
        levelInfo.style.fontWeight = "bold";
        levelInfo.style.color = "#311B92";
        header.appendChild(levelInfo);

        const livesInfo = document.createElement("div");
        livesInfo.style.fontSize = "16px";
        header.appendChild(livesInfo);

        const timerInfo = document.createElement("div");
        timerInfo.style.fontSize = "14px";
        timerInfo.style.fontWeight = "bold";
        timerInfo.style.color = "#D84315";
        header.appendChild(timerInfo);

        const scoreInfo = document.createElement("div");
        scoreInfo.style.fontSize = "14px";
        scoreInfo.style.fontWeight = "bold";
        scoreInfo.style.color = "#2E7D32";
        header.appendChild(scoreInfo);

        // Canvas element
        const canvas = document.createElement("canvas");
        canvas.width = 320;
        canvas.height = 360;
        canvas.style.borderRadius = "16px";
        canvas.style.boxShadow = "0 6px 15px rgba(0,0,0,0.2)";
        canvas.style.cursor = "pointer";
        canvas.style.background = "#FFF";
        canvas.style.display = "block";
        wrapper.appendChild(canvas);

        const ctx = canvas.getContext("2d");

        // Game Instructions Label
        const instr = document.createElement("div");
        instr.innerText = "اضغط على الشاشة للقفز وتجنب العقبات! 🏃‍♂️💨";
        instr.style.marginTop = "10px";
        instr.style.fontSize = "14px";
        instr.style.color = "#555";
        instr.style.fontWeight = "bold";
        wrapper.appendChild(instr);

        // Restart button
        const restartBtn = document.createElement("button");
        restartBtn.className = "menu-btn restart-btn";
        restartBtn.innerText = "إعادة اللعب 🔄";
        restartBtn.style.marginTop = "10px";
        restartBtn.style.padding = "8px 16px";
        restartBtn.style.fontSize = "14px";
        restartBtn.style.background = "#FF9800";
        restartBtn.style.color = "#FFF";
        restartBtn.style.border = "none";
        restartBtn.style.borderRadius = "20px";
        restartBtn.style.cursor = "pointer";
        restartBtn.style.boxShadow = "0 3px 6px rgba(0,0,0,0.15)";
        restartBtn.addEventListener("click", () => {
            if (window.sound) window.sound.playClick();
            // Clear any modal if present
            const modals = wrapper.querySelectorAll(".game-modal");
            modals.forEach(m => m.remove());
            // Reset state
            level = 1;
            score = 0;
            lives = 5;
            startLevel();
        });
        wrapper.appendChild(restartBtn);

        // Physics constants
        const groundY = canvas.height - 60;
        const gravity = 0.52;

        // Game Objects
        const player = {
            x: 40,
            y: groundY,
            vy: 0,
            width: 25,
            height: 45,
            isGrounded: true,
            jumpForce: -12.5,
            invincible: 0, // flashing timer
            runFrame: 0
        };

        let obstacles = [];
        let coins = [];
        let bgClouds = [
            { x: 50, y: 40, size: 20 },
            { x: 180, y: 60, size: 15 },
            { x: 280, y: 30, size: 25 }
        ];

        // Start level parameters
        function getLevelSpeed() {
            return 1.5 + level * 0.4;
        }

        // Tap to jump
        function handleJump(e) {
            if (e) {
                // Ignore clicks on buttons (like restartBtn or level navigation buttons)
                if (e.target && e.target.tagName && e.target.tagName.toLowerCase() === "button") return;
                e.preventDefault();
            }
            if (!gameActive) return;

            if (player.isGrounded) {
                player.vy = player.jumpForce;
                player.isGrounded = false;
                if (window.sound) window.sound.playClick();
            }
        }

        // Attach to wrapper instead of canvas to trigger jump from anywhere on screen
        wrapper.addEventListener("pointerdown", handleJump);

        // Update levels parameters
        function spawnObstacle() {
            if (!gameActive) return;
            // Spacing depends on speed
            const minSpacing = 160;
            const lastObstacle = obstacles[obstacles.length - 1];
            if (!lastObstacle || (canvas.width - lastObstacle.x > minSpacing + Math.random() * 100)) {
                // Different shapes
                const type = Math.random() > 0.5 ? "spike" : "box";
                obstacles.push({
                    x: canvas.width + 20,
                    y: groundY,
                    width: type === "spike" ? 18 : 16,
                    height: type === "spike" ? 22 : 18,
                    type: type,
                    color: type === "spike" ? "#D50000" : "#E65100"
                });
            }
        }

        function spawnCoin() {
            if (!gameActive) return;
            const minSpacing = 120;
            const lastCoin = coins[coins.length - 1];
            if (!lastCoin || (canvas.width - lastCoin.x > minSpacing + Math.random() * 80)) {
                // Height can be high or low
                const heightChoice = Math.random() > 0.4 ? groundY - 45 : groundY - 80;
                coins.push({
                    x: canvas.width + 20,
                    y: heightChoice,
                    width: 14,
                    height: 14,
                    collected: false
                });
            }
        }

        function updateUI() {
            levelInfo.innerText = `المرحلة: ${level}/5`;
            livesInfo.innerText = "❤️".repeat(lives) + "🖤".repeat(5 - lives);
            timerInfo.innerText = `الوقت: ${timeRemaining}ث`;
            scoreInfo.innerText = `النقاط: ${score}`;
        }

        // Timer interval
        function startTimer() {
            clearInterval(gameTimerInterval);
            gameTimerInterval = setInterval(() => {
                if (!gameActive) return;
                timeRemaining--;
                updateUI();

                if (timeRemaining <= 0) {
                    // Level cleared!
                    clearInterval(gameTimerInterval);
                    levelCleared();
                }
            }, 1000);
        }

        function levelCleared() {
            gameActive = false;
            cancelAnimationFrame(animationFrameId);

            if (window.sound) window.sound.playSuccess();

            if (level >= 5) {
                showVictory();
            } else {
                showLevelTransition();
            }
        }

        function showLevelTransition() {
            const modal = document.createElement("div");
            modal.className = "game-modal";
            modal.style.position = "absolute";
            modal.style.top = "50%";
            modal.style.left = "50%";
            modal.style.transform = "translate(-50%, -50%)";
            modal.style.background = "#FFF";
            modal.style.padding = "20px";
            modal.style.borderRadius = "20px";
            modal.style.boxShadow = "0 10px 30px rgba(0,0,0,0.3)";
            modal.style.textAlign = "center";
            modal.style.zIndex = "10000";
            modal.style.width = "80%";
            modal.style.maxWidth = "280px";

            modal.innerHTML = `
                <h3 style="color: #4CAF50; margin: 0 0 10px 0; font-size: 22px;">تم اجتياز المرحلة ${level}! 🎉</h3>
                <p style="color: #666; margin: 0 0 20px 0; font-size: 15px;">استعد للمرحلة التالية بسرعة أكبر!</p>
                <button class="menu-btn" style="background:#4CAF50; color:#FFF; border:none; padding:10px 20px; font-size:16px; border-radius:25px; cursor:pointer;">ابدأ المرحلة ${level+1} ➡️</button>
            `;

            modal.querySelector("button").addEventListener("click", () => {
                if (window.sound) window.sound.playClick();
                modal.remove();
                level++;
                startLevel();
            });

            wrapper.appendChild(modal);
        }

        function showVictory() {
            const modal = document.createElement("div");
            modal.className = "game-modal";
            modal.style.position = "absolute";
            modal.style.top = "50%";
            modal.style.left = "50%";
            modal.style.transform = "translate(-50%, -50%)";
            modal.style.background = "#FFF";
            modal.style.padding = "25px";
            modal.style.borderRadius = "20px";
            modal.style.boxShadow = "0 10px 30px rgba(0,0,0,0.3)";
            modal.style.textAlign = "center";
            modal.style.zIndex = "10000";
            modal.style.width = "80%";
            modal.style.maxWidth = "280px";

            modal.innerHTML = `
                <h3 style="color: #FFD700; margin: 0 0 10px 0; font-size: 24px;">بطل المغامرة! 🏆</h3>
                <p style="color: #555; margin: 0 0 10px 0; font-size: 16px;">لقد فزت بجميع المراحل الخمسة!</p>
                <p style="color: #2E7D32; font-weight: bold; font-size: 18px; margin: 0 0 20px 0;">نقاطك النهائية: ${score}</p>
                <button class="menu-btn restart-btn" style="background:#7C4DFF; color:#FFF; border:none; padding:10px 20px; font-size:16px; border-radius:25px; cursor:pointer;">العب مجدداً 🔄</button>
            `;

            modal.querySelector("button").addEventListener("click", () => {
                if (window.sound) window.sound.playClick();
                modal.remove();
                level = 1;
                score = 0;
                lives = 5;
                startLevel();
            });

            wrapper.appendChild(modal);
        }

        function showGameOver() {
            gameActive = false;
            cancelAnimationFrame(animationFrameId);
            clearInterval(gameTimerInterval);

            if (window.sound) window.sound.playFail();

            const modal = document.createElement("div");
            modal.className = "game-modal";
            modal.style.position = "absolute";
            modal.style.top = "50%";
            modal.style.left = "50%";
            modal.style.transform = "translate(-50%, -50%)";
            modal.style.background = "#FFF";
            modal.style.padding = "25px";
            modal.style.borderRadius = "20px";
            modal.style.boxShadow = "0 10px 30px rgba(0,0,0,0.3)";
            modal.style.textAlign = "center";
            modal.style.zIndex = "10000";
            modal.style.width = "80%";
            modal.style.maxWidth = "280px";

            modal.innerHTML = `
                <h3 style="color: #F44336; margin: 0 0 10px 0; font-size: 24px;">حاول مرة أخرى! 😢</h3>
                <p style="color: #555; margin: 0 0 10px 0; font-size: 16px;">انتهت جميع أرواحك.</p>
                <p style="color: #2E7D32; font-weight: bold; font-size: 16px; margin: 0 0 20px 0;">نقاطك: ${score}</p>
                <button class="menu-btn restart-btn" style="background:#FF9800; color:#FFF; border:none; padding:10px 20px; font-size:16px; border-radius:25px; cursor:pointer;">إعادة المحاولة 🔄</button>
            `;

            modal.querySelector("button").addEventListener("click", () => {
                if (window.sound) window.sound.playClick();
                modal.remove();
                level = 1;
                score = 0;
                lives = 5;
                startLevel();
            });

            wrapper.appendChild(modal);
        }

        function startLevel() {
            timeRemaining = 15;
            obstacles = [];
            coins = [];
            player.y = groundY;
            player.vy = 0;
            player.isGrounded = true;
            player.invincible = 0;
            gameActive = true;

            updateUI();
            startTimer();
            gameLoop();
        }

        // Core game loop
        function gameLoop() {
            if (!gameActive) return;

            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // Draw Background sky
            const theme = levelThemes[level - 1];
            ctx.fillStyle = theme.sky;
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Scroll & Draw Clouds
            ctx.fillStyle = "rgba(255,255,255,0.7)";
            bgClouds.forEach(c => {
                c.x -= 0.5;
                if (c.x < -40) c.x = canvas.width + 40;
                
                ctx.beginPath();
                ctx.arc(c.x, c.y, c.size, 0, Math.PI*2);
                ctx.arc(c.x + c.size*0.7, c.y - c.size*0.3, c.size*0.8, 0, Math.PI*2);
                ctx.arc(c.x - c.size*0.7, c.y - c.size*0.2, c.size*0.7, 0, Math.PI*2);
                ctx.fill();
            });

            // Draw Level Name Overlay at top left
            ctx.fillStyle = "rgba(0,0,0,0.4)";
            ctx.font = "bold 11px sans-serif";
            ctx.fillText(theme.name, 10, 20);

            // Draw Ground Platform
            ctx.fillStyle = theme.ground;
            ctx.fillRect(0, groundY, canvas.width, canvas.height - groundY);
            ctx.fillStyle = "#8D6E63"; // dirt underneath
            ctx.fillRect(0, groundY + 8, canvas.width, canvas.height - groundY - 8);

            // Spawns
            spawnObstacle();
            spawnCoin();

            const speed = getLevelSpeed();

            // Handle player physics
            if (!player.isGrounded) {
                player.vy += gravity;
                player.y += player.vy;
                if (player.y >= groundY) {
                    player.y = groundY;
                    player.vy = 0;
                    player.isGrounded = true;
                }
            } else {
                // Running legs animation timer
                player.runFrame = Math.floor(Date.now() / 80) % 4;
            }

            // Invincible flicker timer
            if (player.invincible > 0) {
                player.invincible--;
            }

            // Draw obstacles
            obstacles.forEach((obs, idx) => {
                obs.x -= speed;

                // Draw
                ctx.fillStyle = obs.color;
                if (obs.type === "spike") {
                    ctx.beginPath();
                    ctx.moveTo(obs.x, obs.y);
                    ctx.lineTo(obs.x + obs.width / 2, obs.y - obs.height);
                    ctx.lineTo(obs.x + obs.width, obs.y);
                    ctx.closePath();
                    ctx.fill();
                } else {
                    // Box shape
                    ctx.fillRect(obs.x, obs.y - obs.height, obs.width, obs.height);
                    ctx.strokeStyle = "#3E2723";
                    ctx.lineWidth = 1.5;
                    ctx.strokeRect(obs.x, obs.y - obs.height, obs.width, obs.height);
                }

                // Check collision
                if (player.invincible === 0 && checkCollision(player, obs)) {
                    // Collision! Lose life
                    lives--;
                    player.invincible = 90; // invincibility frames (1.5s)
                    if (window.sound) window.sound.playFail();

                    // Snap player
                    player.y = groundY;
                    player.vy = 0;
                    player.isGrounded = true;

                    updateUI();

                    if (lives <= 0) {
                        showGameOver();
                    }
                }
            });

            // Clean offscreen obstacles
            obstacles = obstacles.filter(obs => obs.x > -30);

            // Draw coins
            coins.forEach(c => {
                c.x -= speed;

                if (!c.collected) {
                    // Yellow shiny coin
                    ctx.fillStyle = "#FFD54F";
                    ctx.beginPath();
                    ctx.arc(c.x, c.y, c.width / 2, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.strokeStyle = "#FF8F00";
                    ctx.lineWidth = 1.5;
                    ctx.stroke();

                    // Star symbol inside
                    ctx.fillStyle = "#FFF";
                    ctx.font = "9px sans-serif";
                    ctx.textAlign = "center";
                    ctx.textBaseline = "middle";
                    ctx.fillText("★", c.x, c.y);

                    // Check collision
                    if (checkCollision(player, { x: c.x - c.width/2, y: c.y + c.height/2, width: c.width, height: c.height })) {
                        c.collected = true;
                        score += 10;
                        if (window.sound) window.sound.playPop();
                        updateUI();
                    }
                }
            });

            // Clean offscreen/collected coins
            coins = coins.filter(c => c.x > -20 && !c.collected);

            // Draw Player Character
            if (player.invincible === 0 || Math.floor(player.invincible / 5) % 2 === 0) {
                drawPlayer(player.x, player.y);
            }

            animationFrameId = requestAnimationFrame(gameLoop);
        }

        // Draw character kid
        function drawPlayer(x, y) {
            // Head
            ctx.fillStyle = "#FFD54F"; // face
            ctx.beginPath();
            ctx.arc(x, y - 38, 11, 0, Math.PI * 2);
            ctx.fill();

            // Eyes
            ctx.fillStyle = "#000";
            ctx.beginPath();
            ctx.arc(x - 4, y - 40, 1.5, 0, Math.PI * 2);
            ctx.arc(x + 4, y - 40, 1.5, 0, Math.PI * 2);
            ctx.fill();

            // Smile
            ctx.strokeStyle = "#E91E63";
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(x, y - 36, 4, 0, Math.PI);
            ctx.stroke();

            // Hair (blue cap)
            ctx.fillStyle = "#0288D1";
            ctx.beginPath();
            ctx.arc(x, y - 41, 12, Math.PI, 0);
            ctx.fill();
            // cap visor
            ctx.fillRect(x, y - 43, 14, 3);

            // Body shirt
            ctx.fillStyle = "#E53935";
            ctx.fillRect(x - 9, y - 27, 18, 18);

            // Legs
            ctx.strokeStyle = "#37474F";
            ctx.lineWidth = 3.5;
            if (player.isGrounded) {
                // Running frames
                const frame = player.runFrame;
                if (frame === 0) {
                    // Left leg forward, right leg back
                    ctx.beginPath();
                    ctx.moveTo(x - 4, y - 9); ctx.lineTo(x - 10, y);
                    ctx.moveTo(x + 4, y - 9); ctx.lineTo(x + 8, y);
                    ctx.stroke();
                } else if (frame === 1) {
                    ctx.beginPath();
                    ctx.moveTo(x - 4, y - 9); ctx.lineTo(x - 4, y);
                    ctx.moveTo(x + 4, y - 9); ctx.lineTo(x + 4, y);
                    ctx.stroke();
                } else if (frame === 2) {
                    // Right leg forward, left leg back
                    ctx.beginPath();
                    ctx.moveTo(x - 4, y - 9); ctx.lineTo(x + 2, y);
                    ctx.moveTo(x + 4, y - 9); ctx.lineTo(x - 4, y);
                    ctx.stroke();
                } else {
                    ctx.beginPath();
                    ctx.moveTo(x - 4, y - 9); ctx.lineTo(x - 2, y);
                    ctx.moveTo(x + 4, y - 9); ctx.lineTo(x + 6, y);
                    ctx.stroke();
                }
            } else {
                // Jumping legs bent
                ctx.beginPath();
                ctx.moveTo(x - 4, y - 9); ctx.lineTo(x - 8, y - 2);
                ctx.moveTo(x + 4, y - 9); ctx.lineTo(x + 8, y - 2);
                ctx.stroke();
            }
        }

        // Standard bounding box collision check
        function checkCollision(p, obj) {
            // Player box
            const pxLeft = p.x - 10;
            const pxRight = p.x + 10;
            const pyTop = p.y - 45; // top of head
            const pyBottom = p.y;   // ground level feet

            // Object box
            const oxLeft = obj.x;
            const oxRight = obj.x + obj.width;
            const oyTop = obj.y - obj.height;
            const oyBottom = obj.y;

            return (pxLeft < oxRight &&
                    pxRight > oxLeft &&
                    pyTop < oyBottom &&
                    pyBottom > oyTop);
        }

        // Exiting cleanup
        container.addEventListener("game-exit", () => {
            gameActive = false;
            cancelAnimationFrame(animationFrameId);
            clearInterval(gameTimerInterval);
        }, { once: true });

        // First launch
        startLevel();
    };
})();
