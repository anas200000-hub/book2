// Game 8: Pop It! (فقاعات البوب إت)
window.initPopitGame = function (container) {
    const rows = 5;
    const cols = 5;
    const rowColors = [
        '#FF3B30', // Red row
        '#FF9500', // Orange row
        '#FFCC00', // Yellow row
        '#4CD964', // Green row
        '#007AFF'  // Blue row
    ];

    let poppedCount = 0;
    const totalBubbles = rows * cols;

    let html = `
        <div class="game-popit-layout">
            <h2 class="game-title">🟢 فقاعات البوب إت 🟢</h2>
            <p class="game-instructions">فرقع كل الفقاعات الملونة! إنها ممتعة ومسلية!</p>
            
            <div class="popit-board-wrapper">
                <div class="popit-board" id="popitBoard">
    `;

    for (let r = 0; r < rows; r++) {
        html += `<div class="popit-row">`;
        for (let c = 0; c < cols; c++) {
            html += `
                <div class="popit-bubble" data-row="${r}" data-col="${c}" style="background-color: ${rowColors[r]}; box-shadow: inset 0 -4px 0 rgba(0,0,0,0.2), 0 4px 6px rgba(0,0,0,0.15);">
                    <div class="bubble-inner"></div>
                </div>
            `;
        }
        html += `</div>`;
    }

    html += `
                </div>
            </div>
            
            <div class="popit-controls">
                <button class="menu-btn restart-btn" id="flipBoardBtn" style="display: none; margin: 20px auto;">اقلب اللوحة 🔄</button>
            </div>
        </div>
    `;

    container.innerHTML = html;

    const board = document.getElementById('popitBoard');
    const flipBtn = document.getElementById('flipBoardBtn');

    // Attach click/touch events to bubbles
    container.querySelectorAll('.popit-bubble').forEach(bubble => {
        const handlePop = function (e) {
            e.preventDefault();
            if (this.classList.contains('popped')) return;

            // Play Pop sound
            if (window.sound) {
                window.sound.playPop();
            }

            // Mark as popped and update styling
            this.classList.add('popped');
            this.style.boxShadow = 'inset 0 4px 6px rgba(0, 0, 0, 0.4)';
            this.style.transform = 'scale(0.92)';

            // Bubble bounce animation
            this.classList.add('pop-active');
            setTimeout(() => this.classList.remove('pop-active'), 150);

            poppedCount++;

            // Check if board fully popped
            if (poppedCount === totalBubbles) {
                showFlipButton();
            }
        };

        bubble.addEventListener('mousedown', handlePop);
        bubble.addEventListener('touchstart', handlePop);
    });

    function showFlipButton() {
        if (window.sound) {
            window.sound.playSuccess();
        }
        flipBtn.style.display = 'block';
        flipBtn.classList.add('bounce-anim');
    }

    // Flip Board event listener
    flipBtn.addEventListener('click', function () {
        if (window.sound) {
            window.sound.playFlip();
        }

        // Apply 3D card flip animation to the board
        board.style.transition = 'transform 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
        
        // Toggle rotation
        if (board.style.transform === 'rotateY(180deg)') {
            board.style.transform = 'rotateY(0deg)';
        } else {
            board.style.transform = 'rotateY(180deg)';
        }

        flipBtn.style.display = 'none';

        // Reset all bubbles after board flips (halfway through the animation)
        setTimeout(() => {
            container.querySelectorAll('.popit-bubble').forEach(bubble => {
                bubble.classList.remove('popped');
                const r = parseInt(bubble.getAttribute('data-row'));
                bubble.style.boxShadow = 'inset 0 -4px 0 rgba(0,0,0,0.2), 0 4px 6px rgba(0,0,0,0.15)';
                bubble.style.transform = 'scale(1)';
            });
            poppedCount = 0;
        }, 300);
    });
};
