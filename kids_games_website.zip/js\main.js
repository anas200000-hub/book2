// Main coordinator script for Kids Games Suite (32 Games Version)
window.getEmojiSVG = function(emojiChar) {
    if (!emojiChar) return '';
    const codePoints = [];
    for (let char of emojiChar) {
        codePoints.push(char.codePointAt(0).toString(16));
    }
    const cleanCodePoints = codePoints.filter(cp => cp !== 'fe0f');
    const hex = cleanCodePoints.join('-');
    return `./assets/emojis/${hex}.svg`;
};

document.addEventListener('DOMContentLoaded', () => {
    const gameHub = document.getElementById('gameHub');
    const gameArea = document.getElementById('gameArea');
    const backBtn = document.getElementById('backBtn');
    
    // Definition of our 32 games
    const gamesList = [
        { id: 'animals', emoji: '🦁', title: 'أصوات الحيوانات', color: 'linear-gradient(135deg, #FF7F50, #FF6B6B)' },
        { id: 'coloring', emoji: '🎨', title: 'كتاب التلوين', color: 'linear-gradient(135deg, #FF69B4, #EC407A)' },
        { id: 'balloons', emoji: '🎈', title: 'فرقعة البالونات', color: 'linear-gradient(135deg, #FFD700, #FF9500)' },
        { id: 'memory', emoji: '🧠', title: 'لعبة الذاكرة', color: 'linear-gradient(135deg, #29B6F6, #0288D1)' },
        { id: 'shapes', emoji: '📐', title: 'مطابقة الأشكال', color: 'linear-gradient(135deg, #66BB6A, #388E3C)' },
        { id: 'catch', emoji: '🍎', title: 'صيد الفواكه', color: 'linear-gradient(135deg, #AB47BC, #7B1FA2)' },
        { id: 'piano', emoji: '🎹', title: 'بيانو الأطفال', color: 'linear-gradient(135deg, #26A69A, #00695C)' },
        { id: 'popit', emoji: '🟢', title: 'فقاعات البوب إت', color: 'linear-gradient(135deg, #EC407A, #FF3D00)' },
        { id: 'oddone', emoji: '🔍', title: 'أوجد المختلف', color: 'linear-gradient(135deg, #5C6BC0, #3949AB)' },
        { id: 'feed', emoji: '🍌', title: 'أطعم الحيوان', color: 'linear-gradient(135deg, #FFB74D, #FFA726)' },
        { id: 'shadow', emoji: '👥', title: 'ظلال الأشكال', color: 'linear-gradient(135deg, #78909C, #546E7A)' },
        { id: 'counting', emoji: '🔢', title: 'عد الأشياء', color: 'linear-gradient(135deg, #81C784, #4CAF50)' },
        { id: 'fireworks', emoji: '🎆', title: 'ألعاب نارية', color: 'linear-gradient(135deg, #4A148C, #1A237E)' },
        { id: 'dressup', emoji: '🧸', title: 'تلبيس الدمية', color: 'linear-gradient(135deg, #FF8A80, #FF5252)' },
        { id: 'tictactoe', emoji: '❌', title: 'لعبة إكس أو', color: 'linear-gradient(135deg, #4DD0E1, #00ACC1)' },
        { id: 'whack', emoji: '🐰', title: 'صيد الأرانب', color: 'linear-gradient(135deg, #A1887F, #8D6E63)' },
        { id: 'englishLetters', emoji: '🔠', title: 'حروف الإنجليزية', color: 'linear-gradient(135deg, #B388FF, #7C4DFF)' },
        { id: 'arabicLetters', emoji: '🅰️', title: 'حروف العربية', color: 'linear-gradient(135deg, #FF80AB, #FF4081)' },
        { id: 'numbers', emoji: '🔢', title: 'بالونات الأرقام', color: 'linear-gradient(135deg, #FFD54F, #FFB300)' },
        { id: 'fruits', emoji: '🍓', title: 'فقاعات الفواكه', color: 'linear-gradient(135deg, #A5D6A7, #66BB6A)' },
        { id: 'halvesPuzzle', emoji: '🧩', title: 'أنصاف الصور', color: 'linear-gradient(135deg, #FF7043, #D84315)' },
        { id: 'tangramPuzzle', emoji: '🏠', title: 'تركيب البيت', color: 'linear-gradient(135deg, #00ACC1, #006064)' },
        { id: 'girlsDressup', emoji: '👧', title: 'تلبيس البنات', color: 'linear-gradient(135deg, #F48FB1, #F06292)' },
        { id: 'picturePuzzle', emoji: '🖼️', title: 'تركيب الصور', color: 'linear-gradient(135deg, #7C4DFF, #651FFF)' },
        { id: 'jumpGame', emoji: '🏃', title: 'لعبة القفز', color: 'linear-gradient(135deg, #00E676, #00C853)' },
        { id: 'mathGame', emoji: '➕', title: 'جمع وطرح', color: 'linear-gradient(135deg, #FF6F00, #E65100)' },
        { id: 'missingItem', emoji: '👁️', title: 'ما الذي اختفى؟', color: 'linear-gradient(135deg, #7B1FA2, #4A148C)' },
        { id: 'sizeOrder', emoji: '📏', title: 'الأصغر للأكبر', color: 'linear-gradient(135deg, #1565C0, #0D47A1)' },
        { id: 'wordScramble', emoji: '🔤', title: 'رتب الكلمة', color: 'linear-gradient(135deg, #6A1B9A, #4A148C)' },
        { id: 'colorNumbers', emoji: '🖍️', title: 'لون بالأرقام', color: 'linear-gradient(135deg, #E65100, #BF360C)' },
        { id: 'cooking', emoji: '🍳', title: 'الطبخ السحري', color: 'linear-gradient(135deg, #BF360C, #7F0000)' },
        { id: 'connectDots', emoji: '✏️', title: 'صل النقاط', color: 'linear-gradient(135deg, #00695C, #004D40)' }
    ];

    // Render the Game Hub
    function renderHub() {
        const grid = document.createElement('div');
        grid.classList.add('game-grid');

        gamesList.forEach(g => {
            const card = document.createElement('div');
            card.classList.add('game-card');
            card.style.background = g.color;
            card.innerHTML = `
                <div class="game-card-emoji"><img src="${window.getEmojiSVG(g.emoji)}" class="game-svg-icon" style="width: 1.1em; height: 1.1em;"></div>
                <div class="game-card-title">${g.title}</div>
            `;
            card.addEventListener('click', () => {
                if (window.sound) {
                    window.sound.resume();
                }
                loadGame(g.id);
            });
            grid.appendChild(card);
        });

        gameHub.appendChild(grid);
    }

    // Load selected game
    function loadGame(gameId) {
        if (window.sound) {
            window.sound.playClick();
        }

        // Hide Hub, show Game Area
        gameHub.style.display = 'none';
        gameArea.style.display = 'block';
        backBtn.style.display = 'flex';
        
        // Hide app header during game
        const appHeader = document.getElementById('appHeader');
        if (appHeader) appHeader.style.display = 'none';

        // Initialize the appropriate game
        switch (gameId) {
            case 'animals':
                if (window.initAnimalsGame) window.initAnimalsGame(gameArea);
                break;
            case 'coloring':
                if (window.initColoringGame) window.initColoringGame(gameArea);
                break;
            case 'balloons':
                if (window.initBalloonsGame) window.initBalloonsGame(gameArea);
                break;
            case 'memory':
                if (window.initMemoryGame) window.initMemoryGame(gameArea);
                break;
            case 'shapes':
                if (window.initShapesGame) window.initShapesGame(gameArea);
                break;
            case 'catch':
                if (window.initCatchGame) window.initCatchGame(gameArea);
                break;
            case 'piano':
                if (window.initPianoGame) window.initPianoGame(gameArea);
                break;
            case 'popit':
                if (window.initPopitGame) window.initPopitGame(gameArea);
                break;
            case 'oddone':
                if (window.initOddOneGame) window.initOddOneGame(gameArea);
                break;
            case 'feed':
                if (window.initFeedGame) window.initFeedGame(gameArea);
                break;
            case 'shadow':
                if (window.initShadowGame) window.initShadowGame(gameArea);
                break;
            case 'counting':
                if (window.initCountingGame) window.initCountingGame(gameArea);
                break;
            case 'fireworks':
                if (window.initFireworksGame) window.initFireworksGame(gameArea);
                break;
            case 'dressup':
                if (window.initDressupGame) window.initDressupGame(gameArea);
                break;
            case 'tictactoe':
                if (window.initTictactoeGame) window.initTictactoeGame(gameArea);
                break;
            case 'whack':
                if (window.initWhackGame) window.initWhackGame(gameArea);
                break;
            case 'englishLetters':
                if (window.initEnglishLettersGame) window.initEnglishLettersGame(gameArea);
                break;
            case 'arabicLetters':
                if (window.initArabicLettersGame) window.initArabicLettersGame(gameArea);
                break;
            case 'numbers':
                if (window.initNumbersGame) window.initNumbersGame(gameArea);
                break;
            case 'fruits':
                if (window.initFruitsGame) window.initFruitsGame(gameArea);
                break;
            case 'halvesPuzzle':
                if (window.initHalvesPuzzleGame) window.initHalvesPuzzleGame(gameArea);
                break;
            case 'tangramPuzzle':
                if (window.initTangramPuzzleGame) window.initTangramPuzzleGame(gameArea);
                break;
            case 'girlsDressup':
                document.querySelector('.app-container').classList.add('wide-mode');
                if (window.initGirlsDressupGame) window.initGirlsDressupGame(gameArea);
                break;
            case 'picturePuzzle':
                if (window.initPicturePuzzleGame) window.initPicturePuzzleGame(gameArea);
                break;
            case 'jumpGame':
                if (window.initJumpGame) window.initJumpGame(gameArea);
                break;
            case 'mathGame':
                if (window.initMathGame) window.initMathGame(gameArea);
                break;
            case 'missingItem':
                if (window.initMissingItemGame) window.initMissingItemGame(gameArea);
                break;
            case 'sizeOrder':
                if (window.initSizeOrderGame) window.initSizeOrderGame(gameArea);
                break;
            case 'wordScramble':
                if (window.initWordScrambleGame) window.initWordScrambleGame(gameArea);
                break;
            case 'colorNumbers':
                if (window.initColorNumbersGame) window.initColorNumbersGame(gameArea);
                break;
            case 'cooking':
                if (window.initCookingGame) window.initCookingGame(gameArea);
                break;
            case 'connectDots':
                if (window.initConnectDotsGame) window.initConnectDotsGame(gameArea);
                break;
        }

        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Back to Game Hub
    function returnToHub() {
        if (window.sound) {
            window.sound.playFlip();
        }

        const exitEvent = new CustomEvent('game-exit');
        gameArea.dispatchEvent(exitEvent);

        document.querySelector('.app-container').classList.remove('wide-mode');
        gameArea.innerHTML = '';
        
        gameArea.style.display = 'none';
        backBtn.style.display = 'none';
        gameHub.style.display = 'flex';

        // Show app header again on main menu
        const appHeader = document.getElementById('appHeader');
        if (appHeader) appHeader.style.display = 'block';
    }

    backBtn.addEventListener('click', returnToHub);

    document.body.addEventListener('click', () => {
        if (window.sound) {
            window.sound.resume();
        }
    }, { once: true });

    renderHub();
});
