<?php
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="bulk_transfers_template.csv"');
header('Cache-Control: max-age=0');

// Add BOM for Excel UTF-8 compatibility
echo "\xEF\xBB\xBF";

// Headers
$headers = ['name', 'iban', 'amount'];
echo implode(',', $headers) . "\n";

// Example row
$example = ['موظف مثال', 'JO12345678901234567890123456', '500.250'];
echo implode(',', $example) . "\n";

exit;
