<?php
require_once __DIR__ . '/config.php';

try {
    $pdo->exec("ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS swift VARCHAR(255) DEFAULT '' AFTER bank_name");
} catch (Exception $e) {
    try {
        $pdo->exec("ALTER TABLE suppliers ADD COLUMN swift VARCHAR(255) DEFAULT '' AFTER bank_name");
    } catch (Exception $e2) {
    }
}

try {
    $pdo->exec("ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS company_name VARCHAR(255) DEFAULT '' AFTER id");
} catch (Exception $e) {
    try {
        $pdo->exec("ALTER TABLE suppliers ADD COLUMN company_name VARCHAR(255) DEFAULT '' AFTER id");
    } catch (Exception $e2) {
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'update') {
        $companyName = trim($_POST['company_name'] ?? '');
        $beneficiary = trim($_POST['beneficiary'] ?? '');
        $bankName = trim($_POST['bank_name'] ?? '');
        $swift = trim($_POST['swift'] ?? '');
        $iban = trim($_POST['iban'] ?? '');

        if ($companyName && $beneficiary && $bankName && $swift && $iban) {
            if ($action === 'update') {
                $id = (int) ($_POST['id'] ?? 0);
                if ($id > 0) {
                    $stmt = $pdo->prepare("UPDATE suppliers SET company_name = ?, beneficiary = ?, bank_name = ?, swift = ?, iban = ? WHERE id = ?");
                    $stmt->execute([$companyName, $beneficiary, $bankName, $swift, $iban, $id]);
                }
            } else {
                $stmt = $pdo->prepare("INSERT INTO suppliers (company_name, beneficiary, bank_name, swift, iban) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$companyName, $beneficiary, $bankName, $swift, $iban]);
            }
        }
    } elseif ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        if ($id > 0) {
            $stmt = $pdo->prepare("DELETE FROM suppliers WHERE id = ?");
            $stmt->execute([$id]);
        }
    } elseif ($action === 'upload_excel') {
        if (isset($_FILES['excel_file']) && $_FILES['excel_file']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['excel_file']['tmp_name'];
            $handle = fopen($file, 'r');

            if ($handle !== false) {
                $firstLine = true;
                $inserted = 0;

                while (($data = fgetcsv($handle, 1000, ',')) !== false) {
                    if ($firstLine) {
                        $firstLine = false;
                        continue;
                    }

                    $companyName = trim($data[0] ?? '');
                    $beneficiary = trim($data[1] ?? '');
                    $bankName = trim($data[2] ?? '');
                    $swift = trim($data[3] ?? '');
                    $iban = trim($data[4] ?? '');

                    if ($companyName && $beneficiary && $bankName && $swift && $iban) {
                        $stmt = $pdo->prepare("INSERT INTO suppliers (company_name, beneficiary, bank_name, swift, iban) VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([$companyName, $beneficiary, $bankName, $swift, $iban]);
                        $inserted++;
                    }
                }

                fclose($handle);
                $_SESSION['upload_message'] = "تم رفع $inserted مورد بنجاح";
            }
        }
    }

    header('Location: manage_suppliers.php');
    exit;
}

$suppliers = [];
try {
    $stmt = $pdo->query("SELECT * FROM suppliers ORDER BY company_name");
    $suppliers = $stmt->fetchAll();
} catch (Exception $e) {
    $suppliers = [];
}

$uploadMessage = $_SESSION['upload_message'] ?? '';
unset($_SESSION['upload_message']);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>إدارة الموردين</title>
    <link rel="icon" href="assets/anas_logo.png">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #004a8f;
            --primary-light: #1b6dc7;
            --accent: #f2b705;
            --bg: #f4f6fb;
            --text: #0f172a;
            --muted: #6b7280;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Cairo', sans-serif;
            background: var(--bg);
            color: var(--text);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: #fff;
            border-radius: 20px;
            padding: 32px;
            box-shadow: 0 20px 45px rgba(15, 23, 42, 0.08);
        }

        h1 {
            color: var(--primary);
            margin-top: 0;
        }

        form {
            background: #f7f9fc;
            padding: 20px;
            border-radius: 14px;
            margin-bottom: 30px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-top: 12px;
        }

        input {
            width: 100%;
            margin-top: 6px;
            padding: 10px 14px;
            border-radius: 12px;
            border: 1px solid #dbe2ef;
            font-size: 15px;
            background: #fff;
        }

        input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(0, 74, 143, 0.1);
        }

        button {
            margin-top: 16px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: #fff;
            border: none;
            border-radius: 12px;
            padding: 12px 24px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(0, 74, 143, 0.25);
        }

        .suppliers-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 20px;
        }

        @media (max-width: 1024px) {
            .suppliers-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 640px) {
            .suppliers-grid {
                grid-template-columns: 1fr;
            }
        }

        .supplier-card {
            background: #f7f9fc;
            border-radius: 14px;
            padding: 20px;
            border: 1px solid #e5e7eb;
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        .supplier-card h3 {
            margin: 0 0 12px 0;
            color: var(--primary);
            font-size: 18px;
        }

        .supplier-info {
            margin-bottom: 8px;
            font-size: 14px;
            color: var(--muted);
        }

        .supplier-info strong {
            color: var(--text);
            display: inline-block;
            min-width: 80px;
        }

        .supplier-actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-top: auto;
        }

        .supplier-actions form {
            margin: 0;
            padding: 0;
            width: 100%;
        }

        .btn-edit,
        .btn-delete {
            display: block;
            width: 100%;
            padding: 10px 14px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            box-sizing: border-box;
            text-align: center;
        }

        .btn-edit {
            background: var(--accent);
            color: #000;
        }

        .btn-edit:hover {
            background: #d9a504;
        }

        .btn-delete {
            background: #dc2626;
            color: #fff;
        }

        .btn-delete:hover {
            background: #b91c1c;
        }

        .top-buttons {
            display: flex;
            gap: 12px;
            margin-bottom: 20px;
            justify-content: flex-end;
        }

        .back-link {
            padding: 8px 16px;
            color: #fff;
            text-decoration: none;
            font-weight: 600;
            border-radius: 12px;
            border: none;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            white-space: nowrap;
            background: #6b7280;
        }

        .back-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(0, 74, 143, 0.25);
        }

        .btn-excel,
        .btn-upload {
            padding: 10px 20px;
            color: #fff;
            text-decoration: none;
            font-weight: 600;
            border-radius: 12px;
            border: none;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            font-size: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            white-space: nowrap;
            margin-left: 10px;
        }

        #formTitle {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 16px;
            color: var(--primary);
        }

        .btn-excel {
            background: #10b981;
        }

        .btn-excel:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(16, 185, 129, 0.25);
            background: #059669;
        }

        .btn-upload {
            background: #f59e0b;
        }

        .btn-upload:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(245, 158, 11, 0.25);
            background: #d97706;
        }

        .upload-message {
            background: #d1fae5;
            color: #065f46;
            padding: 12px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 600;
        }

        #excelFileInput {
            display: none;
        }

        .form-buttons {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 16px;
        }

        .form-buttons-left {
            display: flex;
            gap: 10px;
        }

        .form-buttons-right {
            display: flex;
            gap: 10px;
        }

        header.hero {
            padding: 15px 5%;
            color: #fff;
            background: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }

        .hero-inner {
            width: 100%;
            max-width: 1200px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 24px;
        }

        .hero-content {
            text-align: right;
        }

        .hero-content h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }

        .hero-logo img {
            max-height: 50px;
            filter: brightness(0) invert(1);
        }
    </style>
</head>

<body>
    <header class="hero">
        <div class="hero-inner">
            <div class="hero-content">
                <h1>إدارة الموردين</h1>
            </div>
            <div class="hero-logo">
                <img src="assets/anas_logo.png" alt="شعار مصرف الراجحي">
            </div>
        </div>
    </header>
    <div class="container">
        <div class="top-buttons">
            <a href="index.php" class="back-link">← العودة للصفحة الرئيسية</a>
        </div>

        <form method="post" enctype="multipart/form-data" id="uploadForm" style="display: none;">
            <input type="hidden" name="action" value="upload_excel">
            <input type="file" id="excelFileInput" name="excel_file" accept=".csv"
                onchange="document.getElementById('uploadForm').submit()">
        </form>

        <?php if ($uploadMessage): ?>
            <div class="upload-message"><?php echo htmlspecialchars($uploadMessage, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>

        <form method="post" id="supplierForm">
            <div id="formTitle">إضافة مورد جديد</div>
            <input type="hidden" name="action" id="formAction" value="add">
            <input type="hidden" name="id" id="supplierId" value="">

            <label>اسم الشركة</label>
            <input type="text" name="company_name" id="company_name" required>

            <label>اسم المستفيد</label>
            <input type="text" name="beneficiary" id="beneficiary" required>

            <label>اسم البنك</label>
            <input type="text" name="bank_name" id="bank_name" required>

            <label>رمز السويفت</label>
            <input type="text" name="swift" id="swift" required>

            <label>رقم الآيبان</label>
            <input type="text" name="iban" id="iban" required>

            <div class="form-buttons">
                <div class="form-buttons-left">
                    <button type="submit" id="submitBtn">إضافة مورد</button>
                    <button type="button" onclick="resetForm()" style="background: #6b7280;">إلغاء</button>
                </div>
                <div class="form-buttons-right">
                    <a href="download_template.php" class="btn-excel">📥 تحميل نموذج CSV</a>
                    <button type="button" class="btn-upload"
                        onclick="document.getElementById('excelFileInput').click()">📤 رفع ملف CSV</button>
                </div>
            </div>
        </form>

        <h2>قائمة الموردين</h2>
        <?php if (count($suppliers) === 0): ?>
            <p style="color: var(--muted);">لا يوجد موردون محفوظون حالياً.</p>
        <?php else: ?>
            <div class="suppliers-grid">
                <?php foreach ($suppliers as $supplier): ?>
                    <div class="supplier-card">
                        <h3><?php echo htmlspecialchars($supplier['company_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?></h3>
                        <div class="supplier-info">
                            <strong>المستفيد:</strong>
                            <?php echo htmlspecialchars($supplier['beneficiary'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                        </div>
                        <div class="supplier-info">
                            <strong>البنك:</strong>
                            <?php echo htmlspecialchars($supplier['bank_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                        </div>
                        <div class="supplier-info">
                            <strong>السويفت:</strong>
                            <?php echo htmlspecialchars($supplier['swift'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                        </div>
                        <div class="supplier-info">
                            <strong>الآيبان:</strong>
                            <?php echo htmlspecialchars($supplier['iban'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                        </div>
                        <div class="supplier-actions">
                            <button class="btn-edit"
                                onclick='editSupplier(<?php echo json_encode($supplier, JSON_UNESCAPED_UNICODE); ?>)'>تعديل</button>
                            <form method="post">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?php echo $supplier['id']; ?>">
                                <button type="submit" class="btn-delete"
                                    onclick="return confirm('هل أنت متأكد من حذف هذا المورد؟')">حذف</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function editSupplier(supplier) {
            document.getElementById('formTitle').textContent = 'تعديل المورد';
            document.getElementById('formAction').value = 'update';
            document.getElementById('supplierId').value = supplier.id;
            document.getElementById('company_name').value = supplier.company_name;
            document.getElementById('beneficiary').value = supplier.beneficiary;
            document.getElementById('bank_name').value = supplier.bank_name;
            document.getElementById('swift').value = supplier.swift;
            document.getElementById('iban').value = supplier.iban;
            document.getElementById('submitBtn').textContent = 'تحديث المورد';
            document.getElementById('supplierForm').scrollIntoView({ behavior: 'smooth' });
        }

        function resetForm() {
            document.getElementById('formTitle').textContent = 'إضافة مورد جديد';
            document.getElementById('formAction').value = 'add';
            document.getElementById('supplierId').value = '';
            document.getElementById('supplierForm').reset();
            document.getElementById('submitBtn').textContent = 'إضافة مورد';
        }
    </script>
</body>

</html>