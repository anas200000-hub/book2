<?php
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="suppliers_template.csv"');
header('Cache-Control: max-age=0');

echo "\xEF\xBB\xBF";

$headers = ['اسم الشركة', 'اسم المستفيد', 'اسم البنك', 'رمز السويفت', 'رقم الآيبان'];
echo implode(',', $headers) . "\n";

$example = ['شركة المثال', 'أحمد محمد علي', 'البنك العربي', 'ARABJOAX', 'JO94CBJO0010000000000131000302'];
echo implode(',', $example) . "\n";

exit;
