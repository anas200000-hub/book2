<?php
require_once __DIR__ . '/config.php';

function h($value)
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

// Try to add missing columns to 'books' table if they don't exist
try {
    $pdo->exec("ALTER TABLE books ADD COLUMN entity_name VARCHAR(255) DEFAULT '' AFTER title");
} catch (Exception $e) {
}
try {
    $pdo->exec("ALTER TABLE books ADD COLUMN total_amount DECIMAL(15,2) DEFAULT 0.00 AFTER entity_name");
} catch (Exception $e) {
}
try {
    $pdo->exec("ALTER TABLE books ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER total_amount");
} catch (Exception $e) {
}

// Handle deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_selected') {
    $selectedIds = $_POST['book_ids'] ?? [];
    if (!empty($selectedIds)) {
        $placeholders = implode(',', array_fill(0, count($selectedIds), '?'));
        $stmt = $pdo->prepare("DELETE FROM books WHERE id IN ($placeholders)");
        $stmt->execute($selectedIds);
        $message = "تم حذف الكتب المختارة بنجاح.";
    }
}

// Capture filters
$filterDate = $_GET['f_date'] ?? '';
$filterNumber = $_GET['f_number'] ?? '';
$filterTitle = $_GET['f_title'] ?? '';
$filterEntity = $_GET['f_entity'] ?? '';
$filterAmount = $_GET['f_amount'] ?? '';

// Fetch books with dynamic filtering
$books = [];
try {
    $sql = "SELECT id, book_number, title, entity_name, total_amount, created_at, filters_json FROM books WHERE 1=1";
    $params = [];

    if ($filterDate) {
        $sql .= " AND DATE(created_at) = ?";
        $params[] = $filterDate;
    }
    if ($filterNumber) {
        $sql .= " AND book_number LIKE ?";
        $params[] = "%$filterNumber%";
    }
    if ($filterTitle) {
        $sql .= " AND title = ?";
        $params[] = $filterTitle;
    }
    if ($filterEntity) {
        $sql .= " AND entity_name = ?";
        $params[] = $filterEntity;
    }
    if ($filterAmount) {
        $sql .= " AND total_amount = ?";
        $params[] = $filterAmount;
    }

    $sql .= " ORDER BY id DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $books = $stmt->fetchAll();
} catch (Exception $e) {
    $books = [];
}
// Fetch unique titles and entities for dropdowns
$uniqueTitles = [];
$uniqueEntities = [];
try {
    $uniqueTitles = $pdo->query("SELECT DISTINCT title FROM books WHERE title != '' ORDER BY title")->fetchAll(PDO::FETCH_COLUMN);
    $uniqueEntities = $pdo->query("SELECT DISTINCT entity_name FROM books WHERE entity_name != '' ORDER BY entity_name")->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>سجل الكتب الصادرة</title>
    <link rel="icon" href="assets/anas_logo.png">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #004a8f;
            --primary-light: #1b6dc7;
            --accent: #f2b705;
            --bg: #f4f6fb;
            --text: #0f172a;
            --muted: #6b7280;
            --card-radius: 20px;
        }

        body {
            margin: 0;
            font-family: 'Cairo', sans-serif;
            background: var(--bg);
            color: var(--text);
        }

        .container {
            max-width: 1200px;
            margin: 40px auto;
            background: #fff;
            border-radius: var(--card-radius);
            padding: 32px;
            box-shadow: 0 20px 45px rgba(15, 23, 42, 0.08);
        }

        header.hero {
            padding: 15px 5%;
            color: #fff;
            background: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }

        .hero-inner {
            width: 100%;
            max-width: 1200px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .hero-content h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }

        .hero-logo img {
            max-height: 50px;
            filter: brightness(0) invert(1);
        }

        .top-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            font-size: 15px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: #fff;
        }

        .btn-danger {
            background: #dc2626;
            color: #fff;
        }

        .btn-secondary {
            background: #6b7280;
            color: #fff;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        .filter-card {
            background: #fff;
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 24px;
            border: 1px solid #e5e7eb;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            align-items: flex-end;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .filter-group label {
            font-size: 13px;
            font-weight: 700;
            color: var(--muted);
        }

        .filter-group input,
        .filter-group select {
            padding: 8px 12px;
            border-radius: 8px;
            border: 1px solid #dbe2ef;
            font-size: 14px;
            font-family: inherit;
            background: #fff;
        }

        .filter-actions {
            display: flex;
            gap: 10px;
        }

        .alert {
            padding: 14px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 600;
            background: #d1fae5;
            color: #065f46;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            text-align: right;
            padding: 16px;
            border-bottom: 1px solid #e5e7eb;
        }

        th {
            background: #f9fafb;
            color: var(--primary);
            font-weight: 700;
        }

        tr:hover {
            background: #f8fafc;
        }

        .checkbox-cell {
            width: 40px;
        }

        input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .empty-state {
            text-align: center;
            padding: 60px;
            color: var(--muted);
        }
    </style>
</head>

<body>
    <header class="hero">
        <div class="hero-inner">
            <div class="hero-content">
                <h1>سجل الكتب الصادرة</h1>
            </div>
            <div class="hero-logo">
                <img src="assets/anas_logo.png" alt="Logo">
            </div>
        </div>
    </header>

    <div class="container">
        <?php if (isset($message)): ?>
            <div class="alert"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- Filter Bar -->
        <form method="GET" id="filterForm" class="filter-card">
            <div class="filter-group">
                <label>التاريخ</label>
                <input type="date" name="f_date" value="<?php echo h($filterDate); ?>">
            </div>
            <div class="filter-group">
                <label>رقم الكتاب</label>
                <input type="text" name="f_number" placeholder="بحث بالرقم..." value="<?php echo h($filterNumber); ?>">
            </div>
            <div class="filter-group">
                <label>العنوان</label>
                <select name="f_title">
                    <option value="">كل العناوين</option>
                    <?php foreach ($uniqueTitles as $t): ?>
                        <option value="<?php echo h($t); ?>" <?php echo $filterTitle === $t ? 'selected' : ''; ?>>
                            <?php echo h($t); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="filter-group">
                <label>الجهة / المورد</label>
                <select name="f_entity">
                    <option value="">كل الجهات</option>
                    <?php foreach ($uniqueEntities as $e): ?>
                        <option value="<?php echo h($e); ?>" <?php echo $filterEntity === $e ? 'selected' : ''; ?>>
                            <?php echo h($e); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="filter-group">
                <label>القيمة</label>
                <input type="number" step="0.001" name="f_amount" placeholder="0.000"
                    value="<?php echo h($filterAmount); ?>">
            </div>
            <div class="filter-actions">
                <button type="submit" class="btn btn-primary"
                    style="background: var(--primary); padding: 8px 16px;">تصفية النتائج</button>
                <a href="list_books.php" class="btn btn-secondary" style="padding: 8px 16px; background: #94a3b8;">إعادة
                    تعيين</a>
            </div>
        </form>

        <form method="POST" id="deleteForm" onsubmit="return confirm('هل أنت متأكد من حذف الكتب المختارة؟');">
            <input type="hidden" name="action" value="delete_selected">

            <div class="top-actions">
                <a href="index.php" class="btn btn-secondary">← العودة للرئيسية</a>
                <div style="display: flex; gap: 10px;">
                    <?php if (!empty($books)): ?>
                        <button type="submit" class="btn btn-danger">حذف الكتب المختارة</button>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (empty($books)): ?>
                <div class="empty-state">
                    <h3>لا يوجد كتب صادرة حالياً</h3>
                    <p>سيتم عرض الكتب هنا بمجرد إصدارها من النظام.</p>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th class="checkbox-cell"><input type="checkbox" id="selectAll" onclick="toggleAll(this)"></th>
                            <th>التاريخ</th>
                            <th>رقم الكتاب</th>
                            <th>العنوان / الموضوع</th>
                            <th>الجهة / المورد</th>
                            <th>القيمة الإجمالية</th>
                            <th>تحميل</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($books as $book): ?>
                            <tr>
                                <td class="checkbox-cell">
                                    <input type="checkbox" name="book_ids[]" value="<?php echo $book['id']; ?>">
                                </td>
                                <td><?php echo h(date('d/m/Y', strtotime($book['created_at']))); ?></td>
                                <td><strong><?php echo h($book['book_number']); ?></strong></td>
                                <td><?php echo h($book['title']); ?></td>
                                <td><?php echo h($book['entity_name']); ?></td>
                                <td style="font-weight: bold; color: var(--primary);">
                                    <?php echo h(number_format($book['total_amount'], 2)); ?> دينار
                                </td>
                                <td>
                                    <?php
                                    $filters = json_decode($book['filters_json'], true) ?: [];
                                    $editUrl = 'index.php';
                                    if (isset($filters['request_type'])) {
                                        $editUrl = 'index.php?edit_id=' . $book['id'];
                                    } elseif (strpos($book['title'], 'حوالات داخلية (متعددة الأشخاص)') !== false || isset($filters['employee_name'])) {
                                        $editUrl = 'multiple_transfer.php?edit_id=' . $book['id'];
                                    } elseif (strpos($book['title'], 'حوالة') !== false && (isset($filters['transfer_month']) || isset($filters['items_data']))) {
                                        $editUrl = 'bulk_transfers.php?edit_id=' . $book['id'];
                                    } else {
                                        $editUrl = 'index.php?edit_id=' . $book['id'];
                                    }
                                    ?>
                                    <div style="display: flex; gap: 8px;">
                                        <a href="download_book.php?id=<?php echo $book['id']; ?>" class="btn btn-primary"
                                            style="padding: 6px 12px; font-size: 13px;">تنزيل PDF</a>
                                        <a href="<?php echo $editUrl; ?>" class="btn btn-secondary"
                                            style="padding: 6px 12px; font-size: 13px; background: #fbbf24; color: #000;">تعديل</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </form>
    </div>

    <script>
        function toggleAll(source) {
            const checkboxes = document.getElementsByName('book_ids[]');
            for (let i = 0; i < checkboxes.length; i++) {
                checkboxes[i].checked = source.checked;
            }
        }
    </script>
</body>

</html>