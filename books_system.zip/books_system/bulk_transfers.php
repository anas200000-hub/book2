<?php
require_once __DIR__ . '/config.php';

$editData = [];
if (isset($_GET['edit_id'])) {
    $editId = (int) $_GET['edit_id'];
    $stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->execute([$editId]);
    $book = $stmt->fetch();
    if ($book) {
        $editData = json_decode($book['filters_json'], true) ?: [];
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>حوالات Bulk</title>
    <link rel="icon" href="assets/anas_logo.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #004a8f;
            --primary-light: #1b6dc7;
            --accent: #f2b705;
            --bg: #f4f6fb;
            --text: #0f172a;
            --muted: #6b7280;
            --card-radius: 20px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Cairo', 'Tahoma', sans-serif;
            background: linear-gradient(135deg, rgba(0, 74, 143, 0.95), rgba(0, 114, 188, 0.85)), url('https://www.alrajhibank.com.jo/themes/custom/alrajhi/assets/images/bg_pattern.svg');
            background-size: cover;
            color: var(--text);
        }

        .page-wrapper {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header.hero {
            padding: 15px 5%;
            color: #fff;
            background: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .hero-inner {
            width: 100%;
            max-width: 1200px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 24px;
        }

        .hero-content {
            text-align: right;
        }

        .hero-content h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }

        .hero-logo img {
            max-height: 50px;
            filter: brightness(0) invert(1);
        }

        main {
            flex: 1;
            padding: 40px 5% 60px;
            background: var(--bg);
        }

        .form-card {
            background: #fff;
            border-radius: var(--card-radius);
            box-shadow: 0 20px 45px rgba(15, 23, 42, 0.08);
            padding: 28px 32px;
            max-width: 800px;
            margin: 0 auto;
        }

        form label {
            font-weight: 600;
            display: block;
            margin-top: 18px;
            color: var(--text);
        }

        input,
        select,
        textarea {
            width: 100%;
            margin-top: 6px;
            padding: 10px 14px;
            border-radius: 12px;
            border: 1px solid #dbe2ef;
            font-size: 15px;
            background: #f9fbff;
        }

        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: var(--primary);
            background: #fff;
            box-shadow: 0 0 0 3px rgba(0, 74, 143, 0.1);
        }

        .file-upload-wrapper {
            margin-top: 15px;
            padding: 20px;
            border: 2px dashed #dbe2ef;
            border-radius: 12px;
            text-align: center;
            background: #f9fbff;
        }

        .btn-template {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 16px;
            background: #10b981;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
        }

        .action-row {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }

        .action-row button {
            margin-top: 6px;
            width: auto;
            flex-shrink: 0;
        }

        button[type="submit"] {
            margin-top: 26px;
            width: 100%;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: #fff;
            border: none;
            border-radius: 14px;
            padding: 14px;
            font-size: 17px;
            font-weight: 700;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        button[type="submit"]:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(0, 74, 143, 0.25);
        }

        .btn-fill {
            background: #6366f1;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
        }

        .btn-back {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background: #6b7280;
            color: #fff;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .btn-back:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(107, 114, 128, 0.25);
            background: #4b5563;
        }
    </style>
</head>

<body>
    <div class="page-wrapper">
        <header class="hero">
            <div class="hero-inner">
                <div class="hero-content">
                    <h1>نظام حوالات Bulk</h1>
                </div>
                <div class="hero-logo">
                    <img src="assets/logo.png" alt="شعار مصرف الراجحي">
                </div>
            </div>
        </header>

        <main>
            <div class="form-card">
                <button type="button" class="btn-back" onclick="window.close()">إغلاق الصفحة</button>

                <form action="generate_bulk_transfers.php" method="post" enctype="multipart/form-data" target="_blank">
                    <label for="first_book_number">رقم أول كتاب</label>
                    <input type="text" id="first_book_number" name="first_book_number" required
                        value="<?php echo htmlspecialchars($editData['first_book_number'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">

                    <label for="book_date">تاريخ الكتاب</label>
                    <input type="date" id="book_date" name="book_date"
                        value="<?php echo htmlspecialchars($editData['book_date'] ?? date('Y-m-d'), ENT_QUOTES, 'UTF-8'); ?>">

                    <label for="transfer_type">نوع الحوالات</label>
                    <select id="transfer_type" name="transfer_type" required>
                        <option value="salary" <?php echo (isset($editData['transfer_type']) && $editData['transfer_type'] == 'salary') ? 'selected' : ''; ?>>حوالة رواتب</option>
                        <option value="bonus" <?php echo (isset($editData['transfer_type']) && $editData['transfer_type'] == 'bonus') ? 'selected' : ''; ?>>حوالة مكافآت</option>
                    </select>

                    <label for="transfer_month">عن شهر</label>
                    <div class="action-row">
                        <input type="text" id="transfer_month" name="transfer_month" placeholder="MM / YYYY" required
                            value="<?php echo htmlspecialchars($editData['transfer_month'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                        <button type="button" class="btn-fill" onclick="fillCurrentMonth()">تعبئة الشهر الحالي</button>
                    </div>

                    <div class="file-upload-wrapper">
                        <?php if (isset($editData['items_data'])): ?>
                            <div
                                style="background: #ecfdf5; border: 1px solid #10b981; padding: 10px; border-radius: 8px; margin-bottom: 10px; color: #065f46;">
                                <strong>تنبيه:</strong> تم تحميل بيانات الموظفين من السجل. يمكنك المتابعة أو رفع ملف جديد
                                لاستبدالها.
                            </div>
                            <input type="hidden" name="items_data"
                                value="<?php echo htmlspecialchars($editData['items_data'], ENT_QUOTES, 'UTF-8'); ?>">
                        <?php endif; ?>

                        <a href="download_bulk_template.php" class="btn-template">تنزيل النموذج</a>
                        <input type="file" name="csv_file" accept=".csv" <?php echo isset($editData['items_data']) ? '' : 'required'; ?> style="margin-top: 15px;">
                    </div>

                    <button type="submit">توليد الكتب PDF</button>
                </form>
            </div>
        </main>
    </div>

    <script>
        function fillCurrentMonth() {
            const date = new Date();
            const month = (date.getMonth() + 1).toString().padStart(2, '0');
            const year = date.getFullYear();
            document.getElementById('transfer_month').value = `${month} / ${year}`;
        }
    </script>
</body>

</html>