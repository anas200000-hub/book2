<?php
require_once __DIR__ . '/config.php';

// -- Helpers adapted from generate_book.php --

function respond_with_error($message)
{
    header('Content-Type: text/html; charset=UTF-8');
    echo '<div style="direction:rtl; text-align:right; font-family:tahoma; padding:20px; color:red;">' . htmlspecialchars($message) . '</div>';
    exit;
}

function normalize_amount($value)
{
    $clean = str_replace([' ', ','], '', $value);
    if (!preg_match('/^\d+(\.\d{1,3})?$/', $clean)) {
        return null;
    }
    return $clean;
}

function amount_to_fils($amountString)
{
    $parts = explode('.', $amountString);
    $dinars = (int) $parts[0];
    $fils = 0;
    if (isset($parts[1])) {
        $decimal = substr(str_pad($parts[1], 3, '0', STR_PAD_RIGHT), 0, 3);
        $fils = (int) $decimal;
    }
    return $dinars * 1000 + $fils;
}

function convert_number_to_words($number)
{
    $number = (int) $number;
    if ($number === 0)
        return 'صفر';
    $units = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة'];
    $teens = [10 => 'عشرة', 11 => 'أحد عشر', 12 => 'اثنا عشر', 13 => 'ثلاثة عشر', 14 => 'أربعة عشر', 15 => 'خمسة عشر', 16 => 'ستة عشر', 17 => 'سبعة عشر', 18 => 'ثمانية عشر', 19 => 'تسعة عشر'];
    $tens = ['', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
    $hundredsMap = [1 => 'مائة', 2 => 'مائتان', 3 => 'ثلاثمائة', 4 => 'أربعمائة', 5 => 'خمسمائة', 6 => 'ستمائة', 7 => 'سبعمائة', 8 => 'ثمانمائة', 9 => 'تسعمائة'];
    $scalesSingular = ['', 'ألف', 'مليون', 'مليار'];
    $scalesDual = ['', 'ألفان', 'مليونان', 'ملياران'];
    $scalesPlural = ['', 'آلاف', 'ملايين', 'مليارات'];

    $triplet = function ($n) use ($units, $teens, $tens, $hundredsMap) {
        $parts = [];
        $hundreds = (int) floor($n / 100);
        $remainder = $n % 100;
        if ($hundreds > 0)
            $parts[] = $hundredsMap[$hundreds];
        if ($remainder > 0) {
            if ($remainder < 10)
                $parts[] = $units[$remainder];
            elseif ($remainder < 20)
                $parts[] = $teens[$remainder];
            else {
                $ones = $remainder % 10;
                $tensIndex = (int) floor($remainder / 10);
                $segment = $tens[$tensIndex];
                if ($ones > 0)
                    $parts[] = $units[$ones] . ' و ' . $segment;
                else
                    $parts[] = $segment;
            }
        }
        return trim(implode(' و ', $parts));
    };

    $segments = [];
    $index = 0;
    while ($number > 0) {
        $value = $number % 1000;
        if ($value !== 0) {
            $words = $triplet($value);
            if ($index === 0)
                $segments[] = $words;
            else {
                if ($value === 1)
                    $segments[] = $scalesSingular[$index];
                elseif ($value === 2)
                    $segments[] = $scalesDual[$index];
                elseif ($value >= 3 && $value <= 10)
                    $segments[] = ($words ? $words . ' ' : '') . $scalesPlural[$index];
                else
                    $segments[] = ($words ? $words . ' ' : '') . $scalesSingular[$index];
            }
        }
        $number = (int) floor($number / 1000);
        $index++;
    }
    return implode(' و ', array_reverse($segments));
}

function format_amount_text($filsValue)
{
    if ($filsValue <= 0)
        return ['numeric' => '0.000', 'textual' => 'صفر دينار'];
    $dinars = intdiv($filsValue, 1000);
    $fils = $filsValue % 1000;
    $numeric = number_format($filsValue / 1000, 3, '.', ','); // Changed to 3 decimal places as per user request
    $words = convert_number_to_words($dinars);
    $text = ($words ? $words . ' دينار' : 'صفر دينار');
    if ($fils > 0) {
        $text .= ' و ' . $fils . ' فلس';
    }
    $text .= ' لاغير';
    return [
        'numeric' => $numeric,
        'textual' => 'فقط ' . $text,
    ];
}

function h($value)
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function asset_data_uri($filename)
{
    $path = __DIR__ . '/assets/' . $filename;
    if (!file_exists($path))
        return '';
    $mime = mime_content_type($path) ?: 'image/png';
    $data = base64_encode(file_get_contents($path));
    return 'data:' . $mime . ';base64,' . $data;
}

// -- Main Processing --

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond_with_error('طريقة الطلب غير صحيحة.');
}

// 1. Inputs
$firstBookNumber = trim($_POST['first_book_number'] ?? '');
$bookDate = $_POST['book_date'] ?? date('Y-m-d');
$transferType = $_POST['transfer_type'] ?? '';
$transferMonth = trim($_POST['transfer_month'] ?? '');
if (!$firstBookNumber || !$transferType || !$transferMonth) {
    respond_with_error('يرجى تعبئة جميع الحقول المطلوبة');
}

// Parse Date
$timestamp = strtotime($bookDate);
$formattedDate = date('d / m / Y', $timestamp);
if ($firstBookNumber === '') {
    $firstBookNumber = date('Ymd', $timestamp) . '01';
}

// 2. CSV Handling or Re-generation Data
$validTransfers = [];

if (isset($_POST['re_generation']) && isset($_POST['items_data'])) {
    $validTransfers = json_decode($_POST['items_data'], true) ?: [];
} else {
    if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        respond_with_error('يرجى تحميل ملف CSV صالح.');
    }

    $csvFile = $_FILES['csv_file']['tmp_name'];
    $rows = array_map('str_getcsv', file($csvFile));
    $header = array_shift($rows); // Remove header

    foreach ($rows as $index => $row) {
        if (count($row) < 3)
            continue;

        $name = trim($row[0]);
        $name = preg_replace('/[\x00-\x1F\x7F\xEF\xBB\xBF]/', '', $name);

        $iban = trim($row[1]);
        $amountStr = trim($row[2]);
        $normalized = normalize_amount($amountStr);

        if ($name && $iban && $normalized) {
            $fils = amount_to_fils($normalized);
            if ($fils > 0) {
                $validTransfers[] = [
                    'name' => $name,
                    'iban' => $iban,
                    'fils' => $fils
                ];
            }
        }
    }
}

if (empty($validTransfers)) {
    respond_with_error('لم يتم العثور على بيانات صالحة.');
}

// 3. Pagination Logic (Max 10,000 JOD per page)
$pages = [];
$currentPage = [];
$currentTotalFils = 0;
$maxFils = 10000 * 1000;

foreach ($validTransfers as $transfer) {
    if ($currentTotalFils + $transfer['fils'] > $maxFils) {
        // Close current page
        if (!empty($currentPage)) {
            $pages[] = ['items' => $currentPage, 'totalFils' => $currentTotalFils];
        }
        // Start new page
        $currentPage = [];
        $currentTotalFils = 0;
    }
    $currentPage[] = $transfer;
    $currentTotalFils += $transfer['fils'];
}
// Add last page
if (!empty($currentPage)) {
    $pages[] = ['items' => $currentPage, 'totalFils' => $currentTotalFils];
}

// 4. Generate Books Data
$generatedBooks = [];
$baseNum = $firstBookNumber;
// Split base number logic
$prefix = substr($baseNum, 0, 8);
$startSuffix = (int) substr($baseNum, -2);

foreach ($pages as $idx => $page) {
    $suffix = $startSuffix + $idx;
    $bookNum = $prefix . str_pad($suffix, 2, '0', STR_PAD_LEFT);

    $typeLabel = ($transferType === 'salary') ? 'رواتب' : 'مكافآت';
    $headerTitle = "حوالة $typeLabel شهر $transferMonth - " . ($idx + 1);
    $subjectLine = "الموضوع: تحويل $typeLabel الموظفين لشهر $transferMonth";

    $totalFormatted = number_format($page['totalFils'] / 1000, 2, '.', ','); // Two decimal places for the total in body text
    $bodyText = "نرفق لكم $typeLabel موظفينا شهر $transferMonth بقيمة $totalFormatted دينار، راجين منكم صرفها لكل موظف من حساب الشركة الدينار (901340010930618) حسب الجدول أدناه وتقييد عمولات التحويل إن وجدت كاملة على حسابنا:";

    $rowsHtml = [];
    foreach ($page['items'] as $item) {
        $amt = format_amount_text($item['fils']);
        $rowsHtml[] = [
            'name' => $item['name'],
            'iban' => $item['iban'],
            'bank_name' => 'مصرف الراجحي',
            'amount_num' => $amt['numeric'], // 3 decimal places
            'amount_text' => $amt['textual'],
        ];
    }

    $generatedBooks[] = [
        'number' => $bookNum,
        'date' => $formattedDate,
        'header_title' => $headerTitle,
        'subject' => $subjectLine,
        'body' => $bodyText,
        'rows' => $rowsHtml,
        'total_num' => $totalFormatted,
    ];

    // Record in books registry only if not a re-generation
    if (!isset($_POST['re_generation'])) {
        try {
            $filtersPayload = $_POST;
            // Crucial: Save the items data so we can re-download without the CSV file
            $filtersPayload['items_data'] = json_encode($validTransfers, JSON_UNESCAPED_UNICODE);

            $filtersJson = json_encode($filtersPayload, JSON_UNESCAPED_UNICODE);
            $insert = $pdo->prepare('INSERT INTO books (book_number, title, entity_name, total_amount, filters_json) VALUES (?, ?, ?, ?, ?)');
            $insert->execute([$bookNum, $headerTitle, 'موظفي الشركة (تحويل جماعي)', ($page['totalFils'] / 1000), $filtersJson]);
        } catch (Exception $e) {
            // Silently continue
        }
    }
}

$logoDataUri = asset_data_uri('logo.png');
$signatureDataUri = asset_data_uri('signature.png');

ob_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>كتب الحوالات</title>
    <style>
        @page {
            size: A4;
            margin: 10mm;
        }

        body {
            font-family: "Arial", "Tahoma", sans-serif;
            direction: rtl;
            text-align: right;
            font-size: 14pt;
            margin: 0;
        }

        .page {
            min-height: 100%;
            position: relative;
            page-break-after: always;
        }

        .page:last-child {
            page-break-after: auto;
        }

        /* HEADER TABLE */
        .header-table {
            width: 100%;
            direction: ltr;
            margin-bottom: 20px;
            border: none;
            border-collapse: collapse;
            /* Ensure no spacing issues */
        }

        .header-table td {
            border: none;
            vertical-align: top;
            padding: 0;
        }

        .header-logo {
            text-align: left;
            width: 50%;
            /* Give explicit width just in case, or let it flow */
        }

        .header-logo img {
            max-height: 120px;
        }

        .header-info {
            text-align: right;
            direction: rtl;
            vertical-align: top;
        }

        .header-info .line {
            margin-bottom: 6px;
            font-size: 14pt;
        }

        .bold-header {
            text-align: center;
            font-weight: bold;
            text-decoration: underline;
            margin: 20px 0;
            font-size: 16pt;
        }

        .subject-line {
            font-weight: bold;
            text-align: right;
            margin: 20px 0;
            font-size: 14pt;
        }

        .greeting {
            margin: 20px 0;
        }

        .body-text {
            margin: 15px 0;
            line-height: 1.6;
        }

        .main-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 12pt;
        }

        .main-table th,
        .main-table td {
            border: 1px solid #000;
            padding: 6px;
            text-align: center;
            vertical-align: middle;
        }

        .main-table th {
            background-color: #e0e0e0;
            font-weight: bold;
        }

        .col-name {
            width: 25%;
        }

        .col-iban {
            width: 25%;
            white-space: nowrap;
        }

        .col-bank {
            width: 15%;
        }

        .col-amt-num {
            width: 10%;
            white-space: nowrap;
        }

        .col-amt-txt {
            width: 25%;
            font-size: 11pt;
        }

        .main-table td.col-name,
        .main-table td.col-amt-txt {
            text-align: right;
            padding-right: 5px;
        }

        .respect {
            text-align: center;
            font-weight: bold;
            margin-top: 30px;
            margin-bottom: 40px;
        }

        /* FOOTER TABLE */
        .footer-table {
            width: 100%;
            direction: ltr;
            border: none;
            margin-top: 20px;
            border-collapse: collapse;
        }

        .footer-table td {
            border: none;
            vertical-align: bottom;
            padding: 0;
        }

        .footer-text-cell {
            text-align: left;
            width: 60%;
            /* Give more space for text */
        }

        .footer-text-container {
            display: inline-block;
            text-align: center;
            /* Centers the content (Company Name) relative to the container width which is defined by the longest line (Signatory) */
            margin-left: 20mm;
        }

        .footer-sig-cell {
            text-align: right;
            width: 40%;
        }

        .footer-sig-cell img {
            max-height: 120px;
        }
    </style>
</head>

<body>
    <?php foreach ($generatedBooks as $book): ?>
        <div class="page">
            <!-- Header Table -->
            <table class="header-table">
                <tr>
                    <td class="header-logo">
                        <img src="<?php echo $logoDataUri; ?>" alt="Logo">
                    </td>
                    <!-- Info removed from here -->
                </tr>
            </table>

            <div class="bold-header"><?php echo $book['header_title']; ?></div>

            <!-- Date and Number below title -->
            <div style="text-align: right; margin-bottom: 20px; font-size: 14pt;">
                <div>التاريخ: <?php echo $book['date']; ?></div>
                <div>الرقم: <?php echo $book['number']; ?></div>
            </div>

            <div class="greeting">
                <strong>السادة مصرف الراجحي المحترمين</strong><br>
                الفرع الرئيسي؛<br>
                تحية طيبة وبعد،،
            </div>

            <div class="subject-line"><?php echo $book['subject']; ?></div>

            <div class="body-text">
                <?php echo $book['body']; ?>
            </div>

            <table class="main-table">
                <thead>
                    <tr>
                        <th class="col-name">اسم الموظف</th>
                        <th class="col-iban">رقم حساب الموظف</th>
                        <th class="col-bank">اسم البنك</th>
                        <th class="col-amt-num">صافي الراتب (بالدينار<br>الأردني) بالأرقام</th>
                        <th class="col-amt-txt">صافي الراتب (بالدينار<br>الأردني) بالكلمات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($book['rows'] as $row): ?>
                        <tr>
                            <td class="col-name"><?php echo h($row['name']); ?></td>
                            <td class="col-iban"><?php echo h($row['iban']); ?></td>
                            <td class="col-bank"><?php echo h($row['bank_name']); ?></td>
                            <td class="col-amt-num"><?php echo h($row['amount_num']); ?></td>
                            <td class="col-amt-txt"><?php echo h($row['amount_text']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="respect">وتفضلوا بقبول فائق الاحترام والتقدير</div>

            <!-- Footer Table -->
            <table class="footer-table">
                <tr>
                    <td class="footer-text-cell" colspan="2">
                        <div class="footer-text-container">
                            <div style="font-weight: bold; margin-bottom: 5px;">شركة اجادة للنظم</div>
                            <div>المفوض بالتوقيع: السيد نبيل موسى البكيرات</div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td style="width: 50%;"></td>
                    <td class="footer-sig-cell" style="width: 50%;">
                        <img src="<?php echo $signatureDataUri; ?>" alt="Signature">
                    </td>
                </tr>
            </table>
        </div>
    <?php endforeach; ?>
</body>

</html>
<?php
$html = ob_get_clean();
$tmpDir = __DIR__ . '/tmp';
if (!is_dir($tmpDir))
    mkdir($tmpDir, 0777, true);

$typeStr = ($transferType === 'salary') ? 'رواتب' : 'مكافآت';
$pdfFileName = "حوالات " . $typeStr . " شهر " . $transferMonth . ".pdf";
$htmlFile = $tmpDir . '/' . uniqid('bulk_') . '.html';
$pdfFile = $tmpDir . '/' . uniqid('bulk_') . '.pdf';

file_put_contents($htmlFile, $html);
$wkhtml = '"C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe"';
// margin-bottom reduced to allow footer space if needed, checking style
$command = $wkhtml . ' --margin-left 15mm --margin-right 15mm --margin-top 10mm --margin-bottom 10mm ' . escapeshellarg($htmlFile) . ' ' . escapeshellarg($pdfFile);
shell_exec($command);

if (file_exists($pdfFile)) {
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $pdfFileName . '"');
    readfile($pdfFile);
    unlink($htmlFile);
    unlink($pdfFile);
    exit;
}
respond_with_error('لم يتم إنشاء ملف PDF.');
