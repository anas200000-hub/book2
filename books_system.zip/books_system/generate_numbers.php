<?php
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'generate') {
        $date = trim($_POST['date'] ?? date('Ymd'));
        $count = (int) ($_POST['count'] ?? 10);

        if ($count < 1)
            $count = 1;
        if ($count > 99)
            $count = 99;

        $numbers = [];
        for ($i = 1; $i <= $count; $i++) {
            $numbers[] = $date . str_pad($i, 2, '0', STR_PAD_LEFT);
        }

        echo json_encode(['success' => true, 'numbers' => $numbers]);
        exit;
    } elseif ($action === 'delete') {
        echo json_encode(['success' => true]);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>توليد أرقام الكتب</title>
    <link rel="icon" href="assets/anas_logo.png">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #004a8f;
            --primary-light: #1b6dc7;
            --accent: #f2b705;
            --bg: #f4f6fb;
            --text: #0f172a;
            --muted: #6b7280;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Cairo', sans-serif;
            background: var(--bg);
            color: var(--text);
            padding: 40px 20px;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
            border-radius: 20px;
            padding: 32px;
            box-shadow: 0 20px 45px rgba(15, 23, 42, 0.08);
        }

        h1 {
            color: var(--primary);
            margin-top: 0;
        }

        .form-group {
            background: #f7f9fc;
            padding: 20px;
            border-radius: 14px;
            margin-bottom: 30px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-top: 12px;
        }

        input,
        select {
            width: 100%;
            margin-top: 6px;
            padding: 10px 14px;
            border-radius: 12px;
            border: 1px solid #dbe2ef;
            font-size: 15px;
            background: #fff;
        }

        input:focus,
        select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(0, 74, 143, 0.1);
        }

        button {
            margin-top: 16px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: #fff;
            border: none;
            border-radius: 12px;
            padding: 12px 24px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(0, 74, 143, 0.25);
        }

        .numbers-list {
            margin-top: 30px;
        }

        .number-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 16px;
            background: #f7f9fc;
            border-radius: 10px;
            margin-bottom: 10px;
        }

        .number-text {
            font-size: 18px;
            font-weight: 600;
            color: var(--primary);
        }

        .number-actions {
            display: flex;
            gap: 8px;
        }

        .btn-copy,
        .btn-delete {
            padding: 6px 16px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            font-weight: 600;
        }

        .btn-copy {
            background: var(--accent);
            color: #000;
        }

        .btn-copy:hover {
            background: #d9a504;
        }

        .btn-delete {
            background: #dc2626;
            color: #fff;
        }

        .btn-delete:hover {
            background: #b91c1c;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background: #6b7280;
            color: #fff;
            text-decoration: none;
            font-weight: 600;
            border-radius: 12px;
            border: none;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .back-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(107, 114, 128, 0.25);
            background: #4b5563;
        }
    </style>
</head>

<body>
    <div class="container">
        <button class="back-link" onclick="window.close()">إغلاق الصفحة</button>

        <h1>توليد أرقام الكتب</h1>

        <div class="form-group">
            <label>التاريخ</label>
            <input type="date" id="dateInput" value="<?php echo date('Y-m-d'); ?>">

            <label>عدد الأرقام (1-99)</label>
            <input type="number" id="countInput" min="1" max="99" value="10">

            <button onclick="generateNumbers()">توليد الأرقام</button>
        </div>

        <div class="numbers-list" id="numbersList"></div>
    </div>

    <script>
        function generateNumbers() {
            const dateInput = document.getElementById('dateInput').value;
            const count = parseInt(document.getElementById('countInput').value) || 10;

            const dateObj = new Date(dateInput);
            const year = dateObj.getFullYear();
            const month = String(dateObj.getMonth() + 1).padStart(2, '0');
            const day = String(dateObj.getDate()).padStart(2, '0');
            const dateStr = year + month + day;

            const numbers = [];
            for (let i = 1; i <= Math.min(count, 99); i++) {
                numbers.push(dateStr + String(i).padStart(2, '0'));
            }

            displayNumbers(numbers);
        }

        function displayNumbers(numbers) {
            const container = document.getElementById('numbersList');
            container.innerHTML = '';

            numbers.forEach(number => {
                const item = document.createElement('div');
                item.className = 'number-item';
                item.innerHTML = `
                    <span class="number-text">${number}</span>
                    <div class="number-actions">
                        <button class="btn-copy" onclick="copyNumber('${number}', this)">نسخ</button>
                        <button class="btn-delete" onclick="deleteNumber(this)">حذف</button>
                    </div>
                `;
                container.appendChild(item);
            });
        }

        function copyNumber(number, btn) {
            navigator.clipboard.writeText(number).then(() => {
                const originalText = btn.innerText;
                btn.innerText = 'تم النسخ';
                setTimeout(() => {
                    btn.innerText = originalText;
                }, 1500);
            });
        }

        function deleteNumber(btn) {
            btn.closest('.number-item').remove();
        }
    </script>
</body>

</html>