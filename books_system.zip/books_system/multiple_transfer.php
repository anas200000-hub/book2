<?php
require_once __DIR__ . '/config.php';

$editData = [];
if (isset($_GET['edit_id'])) {
    $editId = (int) $_GET['edit_id'];
    $stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->execute([$editId]);
    $book = $stmt->fetch();
    if ($book) {
        $editData = json_decode($book['filters_json'], true) ?: [];
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>حوالة داخلية متعددة الأشخاص</title>
    <link rel="icon" href="assets/anas_logo.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #004a8f;
            --primary-light: #1b6dc7;
            --accent: #f2b705;
            --bg: #f4f6fb;
            --text: #0f172a;
            --muted: #6b7280;
            --card-radius: 20px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Cairo', 'Tahoma', sans-serif;
            background: linear-gradient(135deg, rgba(0, 74, 143, 0.95), rgba(0, 114, 188, 0.85)), url('https://www.alrajhibank.com.jo/themes/custom/alrajhi/assets/images/bg_pattern.svg');
            background-size: cover;
            color: var(--text);
        }

        .page-wrapper {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header.hero {
            padding: 15px 5%;
            color: #fff;
            background: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .hero-inner {
            width: 100%;
            max-width: 1200px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 24px;
        }

        .hero-content {
            text-align: right;
        }

        .hero-content h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }

        .hero-logo img {
            max-height: 50px;
            filter: brightness(0) invert(1);
        }

        main {
            flex: 1;
            padding: 40px 5% 60px;
            background: var(--bg);
        }

        .form-card {
            background: #fff;
            border-radius: var(--card-radius);
            box-shadow: 0 20px 45px rgba(15, 23, 42, 0.08);
            padding: 28px 32px;
            max-width: 1000px;
            margin: 0 auto;
        }

        form label {
            font-weight: 600;
            display: block;
            margin-top: 18px;
            color: var(--text);
        }

        input,
        select,
        textarea {
            width: 100%;
            margin-top: 6px;
            padding: 10px 14px;
            border-radius: 12px;
            border: 1px solid #dbe2ef;
            font-size: 15px;
            background: #f9fbff;
        }

        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: var(--primary);
            background: #fff;
            box-shadow: 0 0 0 3px rgba(0, 74, 143, 0.1);
        }

        .table-container {
            margin-top: 30px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        table th {
            background: var(--primary);
            color: #fff;
            padding: 12px;
            text-align: center;
            font-weight: 600;
        }

        table td {
            padding: 10px;
            border: 1px solid #dbe2ef;
        }

        table td input {
            margin: 0;
        }

        .btn-action {
            padding: 6px 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            margin: 0 3px;
        }

        .btn-edit {
            background: #3b82f6;
            color: #fff;
        }

        .btn-delete {
            background: #ef4444;
            color: #fff;
        }

        .btn-add {
            margin-top: 15px;
            padding: 10px 20px;
            background: #10b981;
            color: #fff;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
        }

        .total-section {
            margin-top: 20px;
            padding: 15px;
            background: #f0f9ff;
            border-radius: 12px;
            text-align: center;
            font-size: 18px;
            font-weight: 700;
            color: var(--primary);
        }

        button[type="submit"] {
            margin-top: 26px;
            width: 100%;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: #fff;
            border: none;
            border-radius: 14px;
            padding: 14px;
            font-size: 17px;
            font-weight: 700;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        button[type="submit"]:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(0, 74, 143, 0.25);
        }

        .btn-back {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background: #6b7280;
            color: #fff;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .btn-back:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(107, 114, 128, 0.25);
            background: #4b5563;
        }
    </style>
</head>

<body>
    <div class="page-wrapper">
        <header class="hero">
            <div class="hero-inner">
                <div class="hero-content">
                    <h1>حوالة داخلية متعددة الأشخاص</h1>
                </div>
                <div class="hero-logo">
                    <img src="assets/logo.png" alt="شعار مصرف الراجحي">
                </div>
            </div>
        </header>

        <main>
            <div class="form-card">
                <button type="button" class="btn-back" onclick="window.close()">إغلاق الصفحة</button>

                <form action="generate_multiple_transfer.php" method="post" target="_blank">
                    <label for="first_book_number">رقم أول كتاب</label>
                    <input type="text" id="first_book_number" name="first_book_number"
                        value="<?php echo htmlspecialchars($editData['first_book_number'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">

                    <label for="book_date">تاريخ الكتاب</label>
                    <input type="date" id="book_date" name="book_date"
                        value="<?php echo htmlspecialchars($editData['book_date'] ?? date('Y-m-d'), ENT_QUOTES, 'UTF-8'); ?>">

                    <label for="transfer_description">وصف التحويل</label>
                    <input type="text" id="transfer_description" name="transfer_description"
                        placeholder="مثال: بدل عمل إضافي" required
                        value="<?php echo htmlspecialchars($editData['transfer_description'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">

                    <div class="table-container">
                        <h3>بيانات الموظفين</h3>
                        <table id="employeesTable">
                            <thead>
                                <tr>
                                    <th style="width: 35%">الاسم الرباعي</th>
                                    <th style="width: 35%">رقم الآيبان</th>
                                    <th style="width: 15%">القيمة (دينار)</th>
                                    <th style="width: 15%">إجراءات</th>
                                </tr>
                            </thead>
                            <tbody id="tableBody">
                                <?php if (!empty($editData['employee_name'])): ?>
                                    <?php foreach ($editData['employee_name'] as $idx => $name): ?>
                                        <tr>
                                            <td><input type="text" name="employee_name[]" required
                                                    value="<?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>"></td>
                                            <td><input type="text" name="employee_iban[]" required
                                                    value="<?php echo htmlspecialchars($editData['employee_iban'][$idx] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                                            </td>
                                            <td><input type="text" name="employee_amount[]" class="amount-input" required
                                                    value="<?php echo htmlspecialchars($editData['employee_amount'][$idx] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                                            </td>
                                            <td style="text-align: center;">
                                                <button type="button" class="btn-action btn-delete"
                                                    onclick="deleteRow(this)">حذف</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td><input type="text" name="employee_name[]" required></td>
                                        <td><input type="text" name="employee_iban[]" required></td>
                                        <td><input type="text" name="employee_amount[]" class="amount-input" required></td>
                                        <td style="text-align: center;">
                                            <button type="button" class="btn-action btn-delete"
                                                onclick="deleteRow(this)">حذف</button>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <button type="button" class="btn-add" onclick="addRow()">+ إضافة موظف</button>
                    </div>

                    <div class="total-section">
                        المجموع الكلي: <span id="totalAmount">0.00</span> دينار
                    </div>

                    <button type="submit">توليد الكتاب PDF</button>
                </form>
            </div>
        </main>
    </div>

    <script>
        function addRow() {
            const tableBody = document.getElementById('tableBody');
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
        <td><input type="text" name="employee_name[]" required></td>
        <td><input type="text" name="employee_iban[]" required></td>
        <td><input type="text" name="employee_amount[]" class="amount-input" required></td>
        <td style="text-align: center;">
            <button type="button" class="btn-action btn-delete" onclick="deleteRow(this)">حذف</button>
        </td>
    `;
            tableBody.appendChild(newRow);
            attachAmountListeners();
        }

        function deleteRow(btn) {
            const row = btn.closest('tr');
            const tableBody = document.getElementById('tableBody');
            if (tableBody.children.length > 1) {
                row.remove();
                calculateTotal();
            } else {
                alert('يجب أن يبقى موظف واحد على الأقل');
            }
        }

        function calculateTotal() {
            const amounts = document.querySelectorAll('.amount-input');
            let total = 0;
            amounts.forEach(input => {
                const value = parseFloat(input.value) || 0;
                total += value;
            });
            document.getElementById('totalAmount').textContent = total.toFixed(3);
        }

        function attachAmountListeners() {
            const amounts = document.querySelectorAll('.amount-input');
            amounts.forEach(input => {
                input.removeEventListener('input', calculateTotal);
                input.addEventListener('input', calculateTotal);
            });
        }

        }

        // Initialize
        calculateTotal();
        attachAmountListeners();
    </script>
</body>

</html>