<?php
require_once __DIR__ . '/config.php';

const BANK_ACCOUNT_IBAN = 'JO98RJHI9010090100340010930618';

function respond_with_error($message)
{
    header('Content-Type: text/plain; charset=UTF-8');
    echo $message;
    exit;
}

function normalize_amount($value)
{
    $clean = str_replace([' ', ','], '', $value);
    if (!preg_match('/^\d+(\.\d{1,3})?$/', $clean)) {
        return null;
    }
    return $clean;
}

function amount_to_fils($amountString)
{
    $parts = explode('.', $amountString);
    $dinars = (int) $parts[0];
    $fils = 0;
    if (isset($parts[1])) {
        $decimal = substr(str_pad($parts[1], 3, '0', STR_PAD_RIGHT), 0, 3);
        $fils = (int) $decimal;
    }
    return $dinars * 1000 + $fils;
}

function convert_number_to_words($number)
{
    $number = (int) $number;
    if ($number === 0) {
        return 'صفر';
    }
    $units = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة'];
    $teens = [10 => 'عشرة', 11 => 'أحد عشر', 12 => 'اثنا عشر', 13 => 'ثلاثة عشر', 14 => 'أربعة عشر', 15 => 'خمسة عشر', 16 => 'ستة عشر', 17 => 'سبعة عشر', 18 => 'ثمانية عشر', 19 => 'تسعة عشر'];
    $tens = ['', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
    $hundredsMap = [1 => 'مائة', 2 => 'مائتان', 3 => 'ثلاثمائة', 4 => 'أربعمائة', 5 => 'خمسمائة', 6 => 'ستمائة', 7 => 'سبعمائة', 8 => 'ثمانمائة', 9 => 'تسعمائة'];
    $scalesSingular = ['', 'ألف', 'مليون', 'مليار'];
    $scalesDual = ['', 'ألفان', 'مليونان', 'ملياران'];
    $scalesPlural = ['', 'آلاف', 'ملايين', 'مليارات'];

    $triplet = function ($n) use ($units, $teens, $tens, $hundredsMap) {
        $parts = [];
        $hundreds = (int) floor($n / 100);
        $remainder = $n % 100;
        if ($hundreds > 0) {
            $parts[] = $hundredsMap[$hundreds];
        }
        if ($remainder > 0) {
            if ($remainder < 10) {
                $parts[] = $units[$remainder];
            } elseif ($remainder < 20) {
                $parts[] = $teens[$remainder];
            } else {
                $ones = $remainder % 10;
                $tensIndex = (int) floor($remainder / 10);
                $segment = $tens[$tensIndex];
                if ($ones > 0) {
                    $parts[] = $units[$ones] . ' و ' . $segment;
                } else {
                    $parts[] = $segment;
                }
            }
        }
        return trim(implode(' و ', $parts));
    };

    $segments = [];
    $index = 0;
    while ($number > 0) {
        $value = $number % 1000;
        if ($value !== 0) {
            $words = $triplet($value);
            if ($index === 0) {
                $segments[] = $words;
            } else {
                if ($value === 1) {
                    $segments[] = $scalesSingular[$index];
                } elseif ($value === 2) {
                    $segments[] = $scalesDual[$index];
                } elseif ($value >= 3 && $value <= 10) {
                    $segments[] = ($words ? $words . ' ' : '') . $scalesPlural[$index];
                } else {
                    $segments[] = ($words ? $words . ' ' : '') . $scalesSingular[$index];
                }
            }
        }
        $number = (int) floor($number / 1000);
        $index++;
    }

    return implode(' و ', array_reverse($segments));
}

function format_amount_text($filsValue)
{
    $dinars = intdiv($filsValue, 1000);
    $fils = $filsValue % 1000;
    $numeric = number_format($filsValue / 1000, 2, '.', ',');
    $words = convert_number_to_words($dinars);
    $text = ($words ? $words . ' دينار' : 'صفر دينار');
    if ($fils > 0) {
        $text .= ' و ' . $fils . ' فلس';
    }
    $text .= ' لا غير';
    return [
        'numeric' => '(' . $numeric . ' دينار)',
        'textual' => $text,
    ];
}

function h($value)
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function asset_data_uri($filename)
{
    $path = __DIR__ . '/assets/' . $filename;
    if (!file_exists($path)) {
        return '';
    }
    $mime = mime_content_type($path) ?: 'image/png';
    $data = base64_encode(file_get_contents($path));
    return 'data:' . $mime . ';base64,' . $data;
}

$firstBookNumber = trim($_POST['first_book_number'] ?? '');
$bookDateInput = trim($_POST['book_date'] ?? '');
if ($bookDateInput === '') {
    $bookDateInput = date('Y-m-d');
}
$timestamp = strtotime($bookDateInput);
if ($timestamp === false) {
    respond_with_error('تنسيق التاريخ غير صحيح.');
}
$formattedDate = date('d / m / Y', $timestamp);
if ($firstBookNumber === '') {
    $firstBookNumber = date('Ymd', $timestamp) . '01';
}

$employeeNames = $_POST['employee_name'] ?? [];
$employeeIbans = $_POST['employee_iban'] ?? [];
$employeeAmounts = $_POST['employee_amount'] ?? [];
$transferDescription = trim($_POST['transfer_description'] ?? '');

if (empty($employeeNames) || empty($employeeIbans) || empty($employeeAmounts)) {
    respond_with_error('الرجاء إدخال بيانات الموظفين.');
}

if ($transferDescription === '') {
    respond_with_error('الرجاء إدخال وصف التحويل.');
}

$employees = [];
$totalAmountFils = 0;

for ($i = 0; $i < count($employeeNames); $i++) {
    $name = trim($employeeNames[$i] ?? '');
    $iban = trim($employeeIbans[$i] ?? '');
    $amount = trim($employeeAmounts[$i] ?? '');

    if ($name === '' || $iban === '' || $amount === '') {
        continue;
    }

    $normalizedAmount = normalize_amount($amount);
    if ($normalizedAmount === null) {
        respond_with_error('قيمة غير صحيحة للموظف: ' . $name);
    }

    $amountFils = amount_to_fils($normalizedAmount);
    $totalAmountFils += $amountFils;

    $employees[] = [
        'name' => $name,
        'iban' => $iban,
        'amount' => number_format($amountFils / 1000, 3, '.', ','),
    ];
}

if (empty($employees)) {
    respond_with_error('لا توجد بيانات موظفين صحيحة.');
}

$totalAmountDisplay = format_amount_text($totalAmountFils);

$logoDataUri = asset_data_uri('logo.png');
$signatureDataUri = asset_data_uri('signature.png');

// Record in books registry only if not a re-generation
if (!isset($_POST['re_generation'])) {
    try {
        $filtersPayload = $_POST;
        $filtersJson = json_encode($filtersPayload, JSON_UNESCAPED_UNICODE);
        $insert = $pdo->prepare('INSERT INTO books (book_number, title, entity_name, total_amount, filters_json) VALUES (?, ?, ?, ?, ?)');
        $insert->execute([$firstBookNumber, 'طلب حوالات داخلية (متعددة الأشخاص)', 'متعدد الأشخاص', ($totalAmountFils / 1000), $filtersJson]);
    } catch (Exception $e) {
        // Silently continue if DB fails
    }
}

ob_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>حوالة داخلية متعددة</title>
    <style>
        @page {
            size: A4;
            margin: 20mm;
        }

        body {
            font-family: "Arial", "Tahoma", sans-serif;
            direction: rtl;
            text-align: right;
            font-size: 16pt;
            margin: 0;
        }

        .page {
            min-height: 100%;
            position: relative;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            direction: ltr;
            margin-bottom: 10px;
        }

        .logo {
            text-align: left;
        }

        .logo img {
            max-height: 140px;
        }

        .info {
            text-align: right;
            direction: rtl;
            margin-top: -32pt;
        }

        .info .line {
            margin-bottom: 6px;
            font-size: 14pt;
        }

        .info .number-line {
            margin-right: 3mm;
        }

        .book-number {
            letter-spacing: 0.16mm;
        }

        .greeting {
            margin-top: 12px;
            font-size: 16pt;
        }

        .greeting .bold {
            font-weight: bold;
        }

        .subject-line {
            margin: 25px 0 15px;
            text-align: center;
        }

        .subject-line span {
            display: inline-block;
            border-bottom: 1px solid #000;
            padding: 0 10px 5px;
            font-weight: bold;
            font-size: 16pt;
        }

        .body-text {
            font-size: 16pt;
        }

        .body-text p {
            margin: 0 0 12px;
            line-height: 1.7;
        }

        .employees-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 14pt;
        }

        .employees-table th {
            background: #f0f0f0;
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
            font-weight: bold;
        }

        .employees-table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
        }

        .respect-spacer {
            height: 16pt;
        }

        .respect {
            text-align: center;
            font-weight: bold;
            font-size: 16pt;
            margin: 16pt 0 32pt 0;
        }

        .footer {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
        }

        .footer-left {
            text-align: left;
            direction: ltr;
            font-size: 16pt;
        }

        .footer-left .company {
            font-weight: bold;
            margin-left: 23mm;
            margin-bottom: 8pt;
        }

        .signature {
            text-align: right;
            margin-top: 32pt;
        }

        .signature img {
            max-height: 130px;
        }
    </style>
</head>

<body>
    <div class="page">
        <div class="header">
            <div class="logo">
                <?php if ($logoDataUri !== ''): ?>
                    <img src="<?php echo h($logoDataUri); ?>" alt="Logo">
                <?php endif; ?>
            </div>
            <div class="info">
                <div class="line">التاريخ: <?php echo h($formattedDate); ?></div>
                <div class="line number-line">الرقم: <span class="book-number"><?php echo h($firstBookNumber); ?></span>
                </div>
                <div style="height: 16pt;"></div>
                <div class="greeting">
                    <div class="bold">السادة مصرف الراجحي المحترمين</div>
                    <div>الفرع الرئيسي؛</div>
                    <div>تحية طيبة وبعد،،</div>
                </div>
            </div>
        </div>
        <div class="subject-line">
            <span>الموضوع: طلب حوالة داخلية</span>
        </div>
        <div class="body-text">
            <p>
                يرجى التكرم بتحويل مبلغ <span class="amount"><?php echo h($totalAmountDisplay['numeric']); ?></span>
                <?php echo h($totalAmountDisplay['textual']); ?> من حسابنا لديكم رقم <?php echo BANK_ACCOUNT_IBAN; ?>
                وذلك <?php echo h($transferDescription); ?> للموظفين التالية أسماؤهم:
            </p>
            <table class="employees-table">
                <thead>
                    <tr>
                        <th style="width: 40%">الاسم</th>
                        <th style="width: 40%">رقم الآيبان</th>
                        <th style="width: 20%">المبلغ (دينار)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($employees as $index => $employee): ?>
                        <tr>
                            <td><?php echo h($employee['name']); ?></td>
                            <td><?php echo h($employee['iban']); ?></td>
                            <td><?php echo h($employee['amount']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="respect-spacer"></div>
        <div class="respect">وتفضلوا بقبول فائق الإحترام والتقدير</div>
        <div class="footer">
            <div class="footer-left">
                <div class="company">شركة اجادة للنظم </div>
                <div>المفوض بالتوقيع: السيد نبيل موسى البكيرات</div>
            </div>
            <div class="signature">
                <div style="height: 16pt;"></div>
                <?php if ($signatureDataUri !== ''): ?>
                    <img src="<?php echo h($signatureDataUri); ?>" alt="Signature">
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>

</html>
<?php
$html = ob_get_clean();
$tmpDir = __DIR__ . '/tmp';
if (!is_dir($tmpDir)) {
    mkdir($tmpDir, 0777, true);
}
$htmlFile = $tmpDir . '/multiple_transfer_' . $firstBookNumber . '.html';
$pdfFile = $tmpDir . '/multiple_transfer_' . $firstBookNumber . '.pdf';
file_put_contents($htmlFile, $html);
$wkhtml = '"C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe"';
$command = $wkhtml . ' --margin-left 25mm --margin-right 25mm --margin-top 10mm --margin-bottom 10mm ' . escapeshellarg($htmlFile) . ' ' . escapeshellarg($pdfFile);
shell_exec($command);
if (file_exists($pdfFile)) {
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="طلب حوالات داخلية.pdf"');
    readfile($pdfFile);
    unlink($htmlFile);
    unlink($pdfFile);
    exit;
}
respond_with_error('لم يتم إنشاء ملف PDF. تأكد من مسار wkhtmltopdf.');
