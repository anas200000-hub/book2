<?php
require_once __DIR__ . '/config.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id <= 0) {
    die('ID غير صالح.');
}

$stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
$stmt->execute([$id]);
$book = $stmt->fetch();

if (!$book) {
    die('لم يتم العثور على الكتاب.');
}

$filters = json_decode($book['filters_json'], true);
if (!$filters) {
    die('بيانات الكتاب غير صالحة.');
}

// Populate $_POST for the generation scripts
foreach ($filters as $key => $value) {
    $_POST[$key] = $value;
}

// Set re-generation flag to skip DB insertion
$_POST['re_generation'] = 1;

// Determine which script to call based on the title or filters
$title = $book['title'];
$generator = '';

if (isset($filters['request_type'])) {
    // Standard book generation
    $generator = 'generate_book.php';
} elseif (strpos($title, 'حوالات داخلية (متعددة الأشخاص)') !== false || isset($filters['employee_name'])) {
    // Multiple internal transfers
    $generator = 'generate_multiple_transfer.php';
} elseif (strpos($title, 'حوالة') !== false && isset($filters['transfer_month'])) {
    // Bulk transfers
    if (!isset($filters['items_data'])) {
        die('عذراً، لا يمكن إعادة تحميل هذه الحوالة الجماعية لأن بياناتها لم تُحفظ عند الإصدار (كتب قديمة).');
    }
    $generator = 'generate_bulk_transfers.php';
}

if ($generator && file_exists(__DIR__ . '/' . $generator)) {
    // Reset specific POST if needed to avoid confusion
    // (e.g., if generate_book.php expects first_book_number to match $book['book_number'])
    $_POST['first_book_number'] = $book['book_number'];

    // Include the generator script - it will handle headers and output
    require __DIR__ . '/' . $generator;
    exit;
} else {
    die('لا يمكن تحديد نوع الكتاب لإعادة توليده.');
}
