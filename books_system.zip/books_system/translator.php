<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>مترجم (عربي/إنجليزي)</title>
    <link rel="icon" href="assets/anas_logo.png">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #004a8f;
            --primary-light: #1b6dc7;
            --accent: #f2b705;
            --bg: #f4f6fb;
            --text: #0f172a;
            --muted: #6b7280;
            --card-radius: 20px;
        }

        body {
            margin: 0;
            font-family: 'Cairo', sans-serif;
            background: linear-gradient(135deg, rgba(0, 74, 143, 0.95), rgba(0, 114, 188, 0.85)), url('https://www.alrajhibank.com.jo/themes/custom/alrajhi/assets/images/bg_pattern.svg');
            background-size: cover;
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background: #fff;
            border-radius: var(--card-radius);
            padding: 32px;
            box-shadow: 0 20px 45px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
        }

        h2 {
            margin-top: 0;
            color: var(--primary);
            text-align: center;
            margin-bottom: 24px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text);
        }

        textarea {
            width: 100%;
            padding: 16px;
            border-radius: 12px;
            border: 1px solid #dbe2ef;
            font-size: 16px;
            font-family: inherit;
            box-sizing: border-box;
            background: #f9fbff;
            min-height: 150px;
            resize: vertical;
        }

        select {
            width: 100%;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid #dbe2ef;
            font-size: 16px;
            font-family: inherit;
            box-sizing: border-box;
            background: #f9fbff;
        }

        .btn-group {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }

        .btn {
            flex: 1;
            padding: 14px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            transition: all 0.2s;
            border: none;
            font-family: inherit;
        }

        .btn-primary {
            background: var(--primary);
            color: #fff;
        }

        .btn-secondary {
            background: #64748b;
            color: #fff;
        }

        .btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        .loading {
            display: none;
            text-align: center;
            margin-top: 10px;
            color: var(--primary);
            font-weight: 700;
        }

        .loading div {
            width: 12px;
            height: 12px;
            background-color: var(--primary);
            border-radius: 100%;
            display: inline-block;
            animation: sk-bouncedelay 1.4s infinite ease-in-out both;
        }

        .loading div:nth-child(1) { animation-delay: -0.32s; }
        .loading div:nth-child(2) { animation-delay: -0.16s; }

        @keyframes sk-bouncedelay {
            0%, 80%, 100% { transform: scale(0); }
            40% { transform: scale(1.0); }
        }

        .spell-result {
            margin-top: 15px;
            padding: 15px;
            background: #fffbeb;
            border-radius: 12px;
            border: 1px solid #fde68a;
            display: none;
        }

        .error-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #fef3c7;
        }

        .error-item:last-child { border-bottom: none; }

        .error-word {
            color: #b91c1c;
            font-weight: 700;
        }

        .suggestion-chip {
            display: inline-block;
            padding: 4px 10px;
            background: #10b981;
            color: #fff;
            border-radius: 20px;
            font-size: 13px;
            margin-right: 5px;
            cursor: pointer;
            transition: all 0.2s;
        }
        .suggestion-chip:hover { transform: scale(1.1); }
    </style>
</head>

<body>
    <div style="display: flex; flex-direction: row; flex-wrap: wrap; gap: 30px; width: 100%; max-width: 1200px; margin: 40px auto; align-items: stretch; justify-content: center;">
        <!-- Translator Card -->
        <div class="card" style="flex: 1; min-width: 300px;">
            <h2><span style="font-size: 24px; margin-left: 10px;">🌐</span>مترجم (عربي/إنجليزي)</h2>

            <div class="form-group">
                <label>اتجاة الترجمة</label>
                <select id="lang_pair">
                    <option value="en|ar" selected>من الإنجليزية إلى العربية</option>
                    <option value="ar|en">من العربية إلى الإنجليزية</option>
                </select>
            </div>

            <div class="form-group">
                <label>النص المراد ترجمته</label>
                <textarea id="source_text" placeholder="اكتب النص هنا..." autofocus></textarea>
            </div>

            <div class="form-group">
                <label>الترجمة الفورية</label>
                <textarea id="translated_text" placeholder="النتائج ستظهر هنا..." readonly style="background: #f1f5f9; cursor: default;"></textarea>
            </div>

            <div class="loading" id="loader">
                <div></div><div></div><div></div>
                جاري الترجمة...
            </div>

            <div class="btn-group">
                <button class="btn btn-primary" onclick="translateInPlace()">ترجمة فورية</button>
                <button class="btn btn-secondary" style="background: #10b981;" onclick="translateExternal()">عبر Google</button>
                <a href="index.php" class="btn btn-secondary">إغلاق</a>
            </div>
        </div>

        <!-- Spell Checker Card -->
        <div class="card" style="flex: 1; min-width: 300px;">
            <h2><span style="font-size: 24px; margin-left: 10px;">✍️</span>التدقيق الإملائي (عربي/إنجليزي)</h2>
            
            <div class="form-group">
                <label>لغة التدقيق</label>
                <select id="spell_lang">
                    <option value="en-US" selected>الإنجليزية (En-US)</option>
                    <option value="ar">العربية</option>
                </select>
            </div>

            <div class="form-group">
                <label>النص للتدقيق</label>
                <textarea id="spell_text" placeholder="اكتب الكلمة أو الجملة هنا للتدقيق..."></textarea>
            </div>

            <div id="spell_suggestions" class="spell-result"></div>

            <div class="loading" id="spell_loader">
                <div></div><div></div><div></div>
                جاري الفحص...
            </div>

            <div class="btn-group">
                <button class="btn btn-primary" style="background: var(--accent); color: #000;" onclick="checkSpelling()">فحص وتحليل النص</button>
            </div>
        </div>
    </div>

    <script>
        async function translateInPlace() {
            const text = document.getElementById('source_text').value.trim();
            const pair = document.getElementById('lang_pair').value.split('|');
            const sl = pair[0];
            const tl = pair[1];
            const resultArea = document.getElementById('translated_text');
            const loader = document.getElementById('loader');

            if (!text) {
                alert('يرجى إدخال النص أولاً');
                return;
            }

            loader.style.display = 'block';
            resultArea.value = '';

            try {
                const response = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${sl}|${tl}`);
                const data = await response.json();
                
                if (data.responseData) {
                    resultArea.value = data.responseData.translatedText;
                } else {
                    resultArea.value = "حدث خطأ في جلب الترجمة.";
                }
            } catch (error) {
                resultArea.value = "فشل الاتصال بخدمة الترجمة.";
            } finally {
                loader.style.display = 'none';
            }
        }

        function translateExternal() {
            const text = document.getElementById('source_text').value.trim();
            const pair = document.getElementById('lang_pair').value.split('|');
            const sl = pair[0];
            const tl = pair[1];

            if (!text) {
                alert('يرجى إدخال النص أولاً');
                return;
            }

            const url = `https://translate.google.com/?sl=${sl}&tl=${tl}&text=${encodeURIComponent(text)}&op=translate`;
            window.open(url, '_blank');
        }

        // Spell Check Logic
        async function checkSpelling() {
            const text = document.getElementById('spell_text').value.trim();
            const lang = document.getElementById('spell_lang').value;
            const resultDiv = document.getElementById('spell_suggestions');
            const loader = document.getElementById('spell_loader');

            if (!text) {
                alert('يرجى إدخال النص للتدقيق');
                return;
            }

            loader.style.display = 'block';
            resultDiv.style.display = 'none';
            resultDiv.innerHTML = '';

            try {
                const response = await fetch(`https://api.languagetool.org/v2/check`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `text=${encodeURIComponent(text)}&language=${lang}`
                });
                
                const data = await response.json();
                
                if (data.matches && data.matches.length > 0) {
                    let html = '<div style="font-weight:700; margin-bottom:10px; color:#92400e;">نتائج الفحص:</div>';
                    data.matches.forEach(match => {
                        const word = match.context.text.substr(match.context.offset, match.context.length);
                        html += `
                            <div class="error-item">
                                <div><span class="error-word" style="text-decoration: underline wavy red;">${word}</span>: ${match.message}</div>
                                <div style="margin-top: 5px;">
                                    ${match.replacements.slice(0, 5).map(rep => `<span class="suggestion-chip" onclick="applyCorrection('${word.replace(/'/g, "\\'")}', '${rep.value.replace(/'/g, "\\'")}')">${rep.value}</span>`).join('')}
                                </div>
                            </div>
                        `;
                    });
                    resultDiv.innerHTML = html;
                    resultDiv.style.display = 'block';
                } else {
                    resultDiv.innerHTML = '<div style="color:#065f46; font-weight:700;">✅ النص سليم إملائياً ونحوياً!</div>';
                    resultDiv.style.display = 'block';
                }
            } catch (error) {
                resultDiv.innerHTML = '<div style="color:#b91c1c;">حدث خطأ في فحص النص. تأكد من وجود اتصال بإنترنت.</div>';
                resultDiv.style.display = 'block';
            } finally {
                loader.style.display = 'none';
            }
        }

        function applyCorrection(oldWord, newWord) {
            const spellText = document.getElementById('spell_text');
            spellText.value = spellText.value.replace(oldWord, newWord);
            checkSpelling(); // Re-check after correction
        }

        // Support Ctrl+Enter to translate in place
        document.getElementById('source_text').addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'Enter') translateInPlace();
        });
        document.getElementById('spell_text').addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'Enter') checkSpelling();
        });
    </script>
</body>

</html>