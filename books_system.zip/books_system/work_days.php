<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>احتساب أيام العمل</title>
    <link rel="icon" href="assets/anas_logo.png">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #004a8f;
            --primary-light: #1b6dc7;
            --accent: #f2b705;
            --bg: #f4f6fb;
            --text: #0f172a;
            --muted: #6b7280;
            --card-radius: 20px;
        }

        body {
            margin: 0;
            font-family: 'Cairo', sans-serif;
            background: linear-gradient(135deg, rgba(0, 74, 143, 0.95), rgba(0, 114, 188, 0.85)), url('https://www.alrajhibank.com.jo/themes/custom/alrajhi/assets/images/bg_pattern.svg');
            background-size: cover;
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background: #fff;
            border-radius: var(--card-radius);
            padding: 32px;
            box-shadow: 0 20px 45px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 500px;
        }

        h2 {
            margin-top: 0;
            color: var(--primary);
            text-align: center;
            margin-bottom: 24px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text);
        }

        input {
            width: 100%;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid #dbe2ef;
            font-size: 16px;
            font-family: inherit;
            box-sizing: border-box;
            background: #f9fbff;
        }

        input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(0, 74, 143, 0.1);
        }

        input[readonly] {
            background: #f1f5f9;
            font-weight: 700;
            color: var(--primary);
        }

        .results {
            margin-top: 24px;
            padding: 16px;
            background: #f0f9ff;
            border-radius: 16px;
            border: 1px dashed var(--primary);
        }

        .btn-group {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }

        .btn {
            flex: 1;
            padding: 14px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            transition: all 0.2s;
            border: none;
            font-family: inherit;
        }

        .btn-primary {
            background: var(--primary);
            color: #fff;
        }

        .btn-secondary {
            background: #64748b;
            color: #fff;
        }

        .btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
    </style>
</head>

<body>
    <div class="card">
        <h2><span style="font-size: 24px; margin-left: 10px;">📅</span>احتساب أيام العمل</h2>

        <div class="form-group">
            <label>تاريخ البداية</label>
            <input type="date" id="start_date" onchange="calculate()">
        </div>

        <div class="form-group">
            <label>تاريخ النهاية</label>
            <input type="date" id="end_date" onchange="calculate()">
        </div>

        <div class="form-group">
            <label>عدد أيام العطل الرسمية</label>
            <input type="number" id="holidays" placeholder="0" min="0" oninput="calculate()">
        </div>

        <div class="results">
            <div class="form-group">
                <label>مجموع أيام العمل</label>
                <input type="text" id="work_days" readonly value="0">
            </div>

            <div class="form-group" style="margin-bottom: 0;">
                <label>عدد ساعات العمل (إجمالي)</label>
                <input type="text" id="work_hours" readonly value="0">
            </div>
        </div>

        <div class="btn-group">
            <a href="index.php" class="btn btn-secondary">إغلاق والعودة</a>
        </div>
    </div>

    <script>
        function calculate() {
            const startStr = document.getElementById('start_date').value;
            const endStr = document.getElementById('end_date').value;
            const holidayInput = document.getElementById('holidays').value;
            const holidays = parseInt(holidayInput) || 0;

            if (!startStr || !endStr) return;

            let start = new Date(startStr);
            let end = new Date(endStr);

            if (start > end) {
                document.getElementById('work_days').value = "خطأ: البداية بعد النهاية";
                document.getElementById('work_hours').value = "0";
                return;
            }

            let count = 0;
            let current = new Date(start);

            while (current <= end) {
                const dayOfWeek = current.getDay();
                // 5 is Friday, 6 is Saturday
                if (dayOfWeek !== 5 && dayOfWeek !== 6) {
                    count++;
                }
                current.setDate(current.getDate() + 1);
            }

            let finalWorkDays = Math.max(0, count - holidays);
            let finalHours = finalWorkDays * 8;

            document.getElementById('work_days').value = finalWorkDays + " يوم عمل";
            document.getElementById('work_hours').value = finalHours + " ساعة";
        }
    </script>
</body>

</html>