<?php
// config.php

$host = 'localhost';
$db   = 'books_system';  // اسم قاعدة البيانات التي أنشأناها في phpMyAdmin
$user = 'root';          // في XAMPP غالباً المستخدم root
$pass = '';              // بدون كلمة مرور افتراضياً في XAMPP
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die('Database Connection Failed: ' . $e->getMessage());
}