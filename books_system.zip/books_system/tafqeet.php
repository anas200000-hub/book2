<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>تفقيط الأرقام</title>
    <link rel="icon" href="assets/anas_logo.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #004a8f;
            --primary-light: #1b6dc7;
            --accent: #f2b705;
            --bg: #f4f6fb;
            --text: #0f172a;
            --muted: #6b7280;
            --card-radius: 20px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Cairo', 'Tahoma', sans-serif;
            background: linear-gradient(135deg, rgba(0, 74, 143, 0.95), rgba(0, 114, 188, 0.85)), url('https://www.alrajhibank.com.jo/themes/custom/alrajhi/assets/images/bg_pattern.svg');
            background-size: cover;
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 700px;
            background: #fff;
            border-radius: var(--card-radius);
            box-shadow: 0 20px 45px rgba(15, 23, 42, 0.15);
            padding: 40px;
            position: relative;
        }

        h1 {
            text-align: center;
            color: var(--primary);
            margin-top: 0;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text);
        }

        input[type="number"] {
            width: 100%;
            padding: 14px;
            border-radius: 12px;
            border: 2px solid #dbe2ef;
            font-size: 18px;
            font-family: inherit;
            transition: border-color 0.2s;
        }

        input[type="number"]:focus {
            outline: none;
            border-color: var(--primary);
        }

        .output-group {
            position: relative;
            background: #f9fbff;
            border: 1px solid #dbe2ef;
            border-radius: 12px;
            padding: 15px;
            min-height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .output-text {
            font-size: 16px;
            line-height: 1.6;
            color: var(--text);
            flex: 1;
            margin-left: 10px;
        }

        .copy-btn {
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 8px 16px;
            font-family: inherit;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
            flex-shrink: 0;
            transition: background 0.2s;
        }

        .copy-btn:hover {
            background: var(--primary-light);
        }

        .copy-btn.copied {
            background: #10b981;
        }

        .close-btn {
            display: block;
            width: 100%;
            padding: 14px;
            border-radius: 14px;
            background: #6b7280;
            color: #fff;
            text-align: center;
            text-decoration: none;
            font-weight: 700;
            font-size: 16px;
            transition: background 0.2s;
            margin-top: 20px;
            border: none;
            cursor: pointer;
        }

        .close-btn:hover {
            background: #dc2626;
        }

        /* English output specific direction */
        .output-en {
            direction: ltr;
            text-align: left;
        }

        /* Make sure copy button is on the right visually in LTR context, but flex handles it */
        .output-group.en-group {
            flex-direction: row-reverse;
        }

        .output-group.en-group .output-text {
            margin-left: 0;
            margin-right: 10px;
        }
    </style>
</head>

<body>

    <div class="container">
        <h1>تفقيط الأرقام</h1>

        <div class="form-group">
            <label for="amount">أدخل الرقم (دينار)</label>
            <input type="number" id="amount" placeholder="0.000" step="any" autofocus>
        </div>

        <div class="form-group">
            <label>التفقيط العربي</label>
            <div class="output-group">
                <div class="output-text" id="arabicText">---</div>
                <button class="copy-btn" onclick="copyText('arabicText', this)">نسخ</button>
            </div>
        </div>

        <div class="form-group">
            <label>English Tafqeet</label>
            <div class="output-group en-group">
                <div class="output-text output-en" id="englishText">---</div>
                <button class="copy-btn" onclick="copyText('englishText', this)">Copy</button>
            </div>
        </div>

        <button class="close-btn"
            onclick="window.close(); if(!window.opener) window.location.href='index.php';">إغلاق</button>
    </div>

    <script>
        // --- ARABIC LOGIC ---
        function numToWordsAr(n) {
            if (n === 0) return "صفر";
            const units = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة"];
            const teens = ["عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"];
            const tens = ["", "", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"];
            const hundreds = ["", "مائة", "مائتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسعمائة"];

            const scales = ["", "ألف", "مليون", "مليار"];
            const scalesDual = ["", "ألفان", "مليونان", "ملياران"];
            const scalesPlural = ["", "آلاف", "ملايين", "مليارات"];

            function triplet(num) {
                let h = Math.floor(num / 100);
                let r = num % 100;
                let parts = [];
                if (h > 0) parts.push(hundreds[h]);

                if (r > 0) {
                    if (r < 10) parts.push(units[r]);
                    else if (r < 20) parts.push(teens[r - 10]);
                    else {
                        let u = r % 10;
                        let t = Math.floor(r / 10);
                        if (u > 0) parts.push(units[u] + " و " + tens[t]);
                        else parts.push(tens[t]);
                    }
                }
                return parts.join(" و ");
            }

            let segments = [];
            let scaleIdx = 0;
            while (n > 0) {
                let chunk = n % 1000;
                if (chunk > 0) {
                    let chunkText = triplet(chunk);
                    let suffix = "";
                    if (scaleIdx > 0) {
                        if (chunk === 1) suffix = scales[scaleIdx];
                        else if (chunk === 2) suffix = scalesDual[scaleIdx];
                        else if (chunk >= 3 && chunk <= 10) suffix = (chunkText ? chunkText + " " : "") + scalesPlural[scaleIdx];
                        else suffix = (chunkText ? chunkText + " " : "") + scales[scaleIdx];
                        segments.push(suffix);
                    } else {
                        segments.push(chunkText);
                    }
                }
                n = Math.floor(n / 1000);
                scaleIdx++;
            }
            return segments.reverse().join(" و ");
        }

        // --- ENGLISH LOGIC ---
        function numToWordsEn(n) {
            if (n === 0) return "Zero";
            const units = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"];
            const teens = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
            const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
            const scales = ["", "Thousand", "Million", "Billion"];

            function triplet(num) {
                let h = Math.floor(num / 100);
                let r = num % 100;
                let parts = [];
                if (h > 0) parts.push(units[h] + " Hundred");

                if (r > 0) {
                    if (r < 10) parts.push(units[r]);
                    else if (r < 20) parts.push(teens[r - 10]);
                    else {
                        let u = r % 10;
                        let t = Math.floor(r / 10);
                        if (u > 0) parts.push(tens[t] + " " + units[u]);
                        else parts.push(tens[t]);
                    }
                }
                return parts.join(" "); // English uses space, no 'and' inside triplet usually unless specific style, standard is space
            }

            let segments = [];
            let scaleIdx = 0;
            while (n > 0) {
                let chunk = n % 1000;
                if (chunk > 0) {
                    let chunkText = triplet(chunk);
                    if (scaleIdx > 0) chunkText += " " + scales[scaleIdx];
                    segments.push(chunkText);
                }
                n = Math.floor(n / 1000);
                scaleIdx++;
            }
            // Join with spaces. "and" logic usually applied before tens/units but simplistic approach is fine.
            // For official checks, usually "One Thousand One Hundred AND Fifty". 
            // Better to join with " " here for standard notation.
            return segments.reverse().join(" ");
        }

        const amountInput = document.getElementById('amount');
        const arOutput = document.getElementById('arabicText');
        const enOutput = document.getElementById('englishText');

        amountInput.addEventListener('input', () => {
            let val = parseFloat(amountInput.value);
            if (isNaN(val) || val < 0) {
                arOutput.textContent = "---";
                enOutput.textContent = "---";
                return;
            }

            // Split Integer and Decimal/Fils
            // Ensure 3 decimal precision for fils
            let fixed = val.toFixed(3);
            let parts = fixed.split('.');
            let dinars = parseInt(parts[0], 10);
            let fils = parseInt(parts[1], 10);

            // Arabic
            let arText = "";
            let arDinars = numToWordsAr(dinars);
            arText = "فقط " + (dinars > 0 ? arDinars + " دينار أردني" : "صفر دينار أردني");
            if (fils > 0) {
                arText += " و " + fils + " فلس";
            }
            arText += " لا غير";
            arOutput.textContent = arText;

            // English
            let enText = "";
            let enDinars = numToWordsEn(dinars);
            enText = "Only " + (dinars > 0 ? enDinars + " Jordanian Dinars" : "Zero Jordanian Dinars");
            if (fils > 0) {
                // fils is just number
                enText += " and " + fils + " fils";
            }
            // En doesn't strictly need "la ghair" but usually "Only" at start suffices.
            enOutput.textContent = enText;
        });

        function copyText(elementId, btn) {
            const text = document.getElementById(elementId).innerText;
            if (text === "---") return;

            navigator.clipboard.writeText(text).then(() => {
                const original = btn.innerText;
                btn.innerText = "تم النسخ";
                btn.classList.add('copied');
                setTimeout(() => {
                    btn.innerText = original;
                    btn.classList.remove('copied');
                }, 2000);
            });
        }
    </script>
</body>

</html>