<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>احتساب ضريبة دخل الموظف</title>
    <link rel="icon" href="assets/anas_logo.png">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #004a8f;
            --primary-light: #1b6dc7;
            --accent: #f2b705;
            --bg: #f4f6fb;
            --text: #0f172a;
            --muted: #6b7280;
            --card-radius: 20px;
        }

        body {
            margin: 0;
            font-family: 'Cairo', sans-serif;
            background: linear-gradient(135deg, rgba(0, 74, 143, 0.95), rgba(0, 114, 188, 0.85)), url('https://www.alrajhibank.com.jo/themes/custom/alrajhi/assets/images/bg_pattern.svg');
            background-size: cover;
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background: #fff;
            border-radius: var(--card-radius);
            padding: 32px;
            box-shadow: 0 20px 45px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 550px;
        }

        h2 {
            margin-top: 0;
            color: var(--primary);
            text-align: center;
            margin-bottom: 24px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text);
        }

        select,
        input {
            width: 100%;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid #dbe2ef;
            font-size: 16px;
            font-family: inherit;
            box-sizing: border-box;
            background: #f9fbff;
        }

        .results {
            margin-top: 24px;
            padding: 24px;
            background: #f8fafc;
            border-radius: 16px;
            border: 2px solid #e2e8f0;
        }

        .result-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #e2e8f0;
        }

        .result-item:last-child {
            border-bottom: none;
        }

        .result-label {
            font-weight: 600;
            color: var(--muted);
        }

        .result-val {
            font-weight: 700;
            color: var(--primary);
            font-size: 18px;
        }

        .btn-group {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }

        .btn {
            flex: 1;
            padding: 14px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            transition: all 0.2s;
            border: none;
            font-family: inherit;
        }

        .btn-secondary {
            background: #64748b;
            color: #fff;
        }

        .tax-info {
            font-size: 12px;
            color: var(--muted);
            margin-top: 15px;
            line-height: 1.6;
            background: #fffbeb;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #fde68a;
        }
    </style>
</head>

<body>
    <div class="card">
        <h2><span style="font-size: 24px; margin-left: 10px;">📉</span>محتسب ضريبة الدخل</h2>

        <div class="form-group">
            <label>نوع الاحتساب</label>
            <select id="calc_type" onchange="handleTypeChange()">
                <option value="monthly">شهرياً</option>
                <option value="yearly">سنوياً</option>
            </select>
        </div>

        <div class="form-group">
            <label id="amount_label">الراتب الشهري (دينار)</label>
            <input type="number" id="amount" placeholder="0.00" oninput="calculate()">
        </div>

        <div class="form-group">
            <label>نوع الإعفاء</label>
            <select id="exemption_type" onchange="calculate()">
                <option value="9000">إعفاء شخصي (9000 دينار)</option>
                <option value="18000">إعفاء عائلي (18000 دينار)</option>
            </select>
        </div>

        <div class="results">
            <div class="result-item">
                <span class="result-label">الضريبة الشهرية:</span>
                <span class="result-val" id="monthly_tax">0.00 دينار</span>
            </div>
            <div class="result-item">
                <span class="result-label">الضريبة السنوية:</span>
                <span class="result-val" id="yearly_tax">0.00 دينار</span>
            </div>
            <div class="result-item">
                <span class="result-label">صافي الدخل السنوي:</span>
                <span class="result-val" id="net_yearly">0.00 دينار</span>
            </div>
        </div>

        <div class="tax-info">
            <strong>شرائح الضريبة المستخدمة:</strong><br>
            حتى 5,000 د.أ: 5% | 5,001 - 10,000: 10% | 10,001 - 15,000: 15% | 15,001 - 20,000: 20% | ما زاد: 25%.
        </div>

        <div class="btn-group">
            <a href="index.php" class="btn btn-secondary">إغلاق والعودة</a>
        </div>
    </div>

    <script>
        function handleTypeChange() {
            const type = document.getElementById('calc_type').value;
            const label = document.getElementById('amount_label');
            label.innerText = (type === 'monthly') ? 'الراتب الشهري (دينار)' : 'إجمالي الدخل السنوي (دينار)';
            calculate();
        }

        function calculate() {
            const type = document.getElementById('calc_type').value;
            const amountInput = parseFloat(document.getElementById('amount').value) || 0;
            const exemption = parseFloat(document.getElementById('exemption_type').value);

            let yearlyIncome = (type === 'monthly') ? (amountInput * 12) : amountInput;
            let taxableIncome = Math.max(0, yearlyIncome - exemption);

            let totalTax = 0;

            if (taxableIncome > 0) {
                // Tier 1: 0 - 5000 (5%)
                let t1 = Math.min(taxableIncome, 5000);
                totalTax += t1 * 0.05;

                // Tier 2: 5001 - 10000 (10%)
                if (taxableIncome > 5000) {
                    let t2 = Math.min(taxableIncome - 5000, 5000);
                    totalTax += t2 * 0.10;
                }

                // Tier 3: 10001 - 15000 (15%)
                if (taxableIncome > 10000) {
                    let t3 = Math.min(taxableIncome - 10000, 5000);
                    totalTax += t3 * 0.15;
                }

                // Tier 4: 15001 - 20000 (20%)
                if (taxableIncome > 15000) {
                    let t4 = Math.min(taxableIncome - 15000, 5000);
                    totalTax += t4 * 0.20;
                }

                // Tier 5: > 20000 (25%)
                if (taxableIncome > 20000) {
                    let t5 = taxableIncome - 20000;
                    totalTax += t5 * 0.25;
                }
            }

            let monthlyTax = totalTax / 12;
            let netYearly = yearlyIncome - totalTax;

            document.getElementById('monthly_tax').innerText = monthlyTax.toFixed(2) + " دينار";
            document.getElementById('yearly_tax').innerText = totalTax.toFixed(2) + " دينار";
            document.getElementById('net_yearly').innerText = netYearly.toFixed(2) + " دينار";
        }
    </script>
</body>

</html>