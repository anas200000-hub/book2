<?php
require_once __DIR__ . '/config.php';
$suppliers = [];
try {
    $stmt = $pdo->query("SELECT id, company_name, beneficiary FROM suppliers ORDER BY company_name");
    $suppliers = $stmt->fetchAll();
} catch (Exception $e) {
    $suppliers = [];
}
$requestTypes = [
    'bank_transfer' => 'طلب حوالة بنكية - للموردين فقط',
    'efawateer' => 'طلب تسديد أي فواتيركم',
    'internal_cash' => 'طلب حوالة داخلية - عهدة مصاريف نقدية',
    'internal_eos' => 'طلب حوالة داخلية - مستحقات نهاية الخدمة',
    'claim_payment' => 'تسديد دفعة مطالبة الكهرباء - الراجحي',
    'internal_general' => 'طلب حوالة داخلية'
];

$editData = [];
if (isset($_GET['edit_id'])) {
    $editId = (int) $_GET['edit_id'];
    $stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->execute([$editId]);
    $book = $stmt->fetch();
    if ($book) {
        $editData = json_decode($book['filters_json'], true) ?: [];
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>نظام الكتب </title>
    <link rel="icon" href="assets/anas_logo.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #004a8f;
            --primary-light: #1b6dc7;
            --accent: #f2b705;
            --bg: #f4f6fb;
            --text: #0f172a;
            --muted: #6b7280;
            --card-radius: 20px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Cairo', 'Tahoma', sans-serif;
            background: linear-gradient(135deg, rgba(0, 74, 143, 0.95), rgba(0, 114, 188, 0.85)), url('https://www.alrajhibank.com.jo/themes/custom/alrajhi/assets/images/bg_pattern.svg');
            background-size: cover;
            color: var(--text);
        }

        .page-wrapper {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header.hero {
            padding: 15px 5%;
            color: #fff;
            background: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .hero-inner {
            width: 100%;
            max-width: 1200px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 24px;
        }

        .hero-content {
            text-align: right;
        }

        .hero-content h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }

        .hero-logo img {
            max-height: 50px;
            filter: brightness(0) invert(1);
        }

        main {
            flex: 1;
            padding: 40px 5% 60px;
            background: var(--bg);
        }

        .layout {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .info-card,
        .form-card {
            background: #fff;
            border-radius: var(--card-radius);
            box-shadow: 0 20px 45px rgba(15, 23, 42, 0.08);
            padding: 28px 32px;
        }

        .info-card h3 {
            margin-top: 0;
            color: var(--primary);
        }

        .info-list {
            list-style: none;
            padding: 0;
            margin: 15px 0 0;
        }

        .info-list li {
            margin-bottom: 10px;
            color: var(--muted);
        }

        form label {
            font-weight: 600;
            display: block;
            margin-top: 18px;
            color: var(--text);
        }

        input,
        select,
        textarea {
            width: 100%;
            margin-top: 6px;
            padding: 10px 14px;
            border-radius: 12px;
            border: 1px solid #dbe2ef;
            font-size: 15px;
            background: #f9fbff;
        }

        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: var(--primary);
            background: #fff;
            box-shadow: 0 0 0 3px rgba(0, 74, 143, 0.1);
        }

        textarea {
            min-height: 70px;
            resize: vertical;
        }

        .field-note {
            font-size: 13px;
            color: var(--muted);
            margin-top: 6px;
        }

        .sections {
            display: block;
        }

        button {
            margin-top: 26px;
            width: 100%;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: #fff;
            border: none;
            border-radius: 14px;
            padding: 14px;
            font-size: 17px;
            font-weight: 700;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(0, 74, 143, 0.25);
        }

        .required-hint {
            color: var(--accent);
            font-size: 13px;
        }

        @media (max-width: 640px) {
            header.hero {
                padding: 20px;
            }

            main {
                padding: 30px 20px;
            }

            .form-card,
            .info-card {
                padding: 22px;
            }
        }
    </style>
</head>

<body>
    <div class="page-wrapper">
        <header class="hero">
            <div class="hero-inner">
                <div class="hero-content">
                    <h1>نظام إدارة الكتب</h1>
                </div>
                <div class="hero-logo">
                    <img src="assets/anas_logo.png" alt="شعار مصرف الراجحي">
                </div>
            </div>
        </header>

        <main>
            <div class="layout">
                <section class="info-card">
                    <h3>أدوات النظام</h3>
                    <div style="display: flex; flex-direction: column; gap: 12px; margin-top: 20px;">
                        <a href="manage_suppliers.php"
                            style="display: block; padding: 14px 20px; background: linear-gradient(135deg, var(--primary), var(--primary-light)); color: #fff; text-decoration: none; border-radius: 12px; text-align: center; font-weight: 600; transition: transform 0.2s;">
                            إدارة الموردين
                        </a>
                        <a href="list_books.php"
                            style="display: block; padding: 14px 20px; background: linear-gradient(135deg, var(--primary), var(--primary-light)); color: #fff; text-decoration: none; border-radius: 12px; text-align: center; font-weight: 600; transition: transform 0.2s;">
                            سجل الكتب الصادرة
                        </a>
                        <a href="generate_numbers.php" target="_blank"
                            style="display: block; padding: 14px 20px; background: linear-gradient(135deg, var(--primary), var(--primary-light)); color: #fff; text-decoration: none; border-radius: 12px; text-align: center; font-weight: 600; transition: transform 0.2s;">
                            توليد أرقام كتب
                        </a>
                    </div>

                    <h3 style="margin-top: 30px; font-size: 18px;">خدمات إضافية</h3>
                    <div style="display: flex; flex-direction: column; gap: 12px; margin-top: 15px;">
                        <a href="multiple_transfer.php" target="_blank"
                            style="display: block; padding: 14px 20px; background: #6b7280; color: #fff; text-decoration: none; border-radius: 12px; text-align: center; font-weight: 600; transition: transform 0.2s;">
                            حوالة داخلية متعددة الأشخاص
                        </a>
                        <a href="bulk_transfers.php" target="_blank"
                            style="display: block; padding: 14px 20px; background: #6b7280; color: #fff; text-decoration: none; border-radius: 12px; text-align: center; font-weight: 600; transition: transform 0.2s;">
                            حوالات Bulk
                        </a>
                        <a href="tafqeet.php"
                            style="display: block; padding: 14px 20px; background: #6b7280; color: #fff; text-decoration: none; border-radius: 12px; text-align: center; font-weight: 600; transition: transform 0.2s;">
                            تفقيط الأرقام
                        </a>
                        <a href="javascript:void(0)"
                            onclick="window.open('calculator.php', 'calc', 'width=450,height=700,status=no,toolbar=no,menubar=no')"
                            style="display: block; padding: 14px 20px; background: #6b7280; color: #fff; text-decoration: none; border-radius: 12px; text-align: center; font-weight: 600; transition: transform 0.2s;">
                            آلة حاسبة
                        </a>
                        <a href="work_days.php"
                            style="display: block; padding: 14px 20px; background: #6b7280; color: #fff; text-decoration: none; border-radius: 12px; text-align: center; font-weight: 600; transition: transform 0.2s;">
                            احتساب أيام العمل
                        </a>
                        <a href="tax_calculator.php"
                            style="display: block; padding: 14px 20px; background: #6b7280; color: #fff; text-decoration: none; border-radius: 12px; text-align: center; font-weight: 600; transition: transform 0.2s;">
                            احتساب ضريبة الدخل
                        </a>
                        <a href="translator.php"
                            style="display: block; padding: 14px 20px; background: #6b7280; color: #fff; text-decoration: none; border-radius: 12px; text-align: center; font-weight: 600; transition: transform 0.2s;">
                            مترجم (عربي/إنجليزي)
                        </a>
                    </div>
                </section>

                <section class="form-card">
                    <form action="generate_book.php" method="post" target="_blank">
                        <label for="first_book_number">رقم أول كتاب</label>
                        <input type="text" id="first_book_number" name="first_book_number"
                            value="<?php echo htmlspecialchars($editData['first_book_number'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">

                        <label for="book_date">تاريخ الكتاب</label>
                        <input type="date" id="book_date" name="book_date"
                            value="<?php echo htmlspecialchars($editData['book_date'] ?? date('Y-m-d'), ENT_QUOTES, 'UTF-8'); ?>">

                        <label for="request_type">الموضوع</label>
                        <select id="request_type" name="request_type">
                            <?php foreach ($requestTypes as $value => $label): ?>
                                <option value="<?php echo $value; ?>" <?php echo (isset($editData['request_type']) && $editData['request_type'] == $value) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($label, ENT_QUOTES, 'UTF-8'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>

                        <label for="total_amount">قيمة الطلب (دينار)</label>
                        <input type="text" id="total_amount" name="total_amount" required
                            value="<?php echo htmlspecialchars($editData['total_amount'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                        <div data-section="bank_transfer,claim_payment" class="sections">
                            <label for="invoice_number">رقم الفاتورة / المطالبة</label>
                            <input type="text" id="invoice_number" name="invoice_number"
                                data-required="bank_transfer,claim_payment"
                                value="<?php echo htmlspecialchars($editData['invoice_number'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                        </div>

                        <div data-section="bank_transfer" class="sections">
                            <label for="service_description">نوع الخدمة او البضاعة</label>
                            <input type="text" id="service_description" name="service_description"
                                data-required="bank_transfer"
                                value="<?php echo htmlspecialchars($editData['service_description'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">

                            <label for="supplier_id">المورد</label>
                            <select id="supplier_id" name="supplier_id" data-required="bank_transfer">
                                <option value="">اختر المورد</option>
                                <?php foreach ($suppliers as $supplier): ?>
                                    <option value="<?php echo $supplier['id']; ?>" <?php echo (isset($editData['supplier_id']) && $editData['supplier_id'] == $supplier['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($supplier['company_name'] ?? $supplier['beneficiary'], ENT_QUOTES, 'UTF-8'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div data-section="efawateer" class="sections">
                            <label for="efawateer_entity">جهة أي فواتيركم</label>



                            <select id="efawateer_entity" name="efawateer_entity" data-required="efawateer">
                                <option value="">اختر الجهة</option>
                                <option value="دائرة ضريبة الدخل والمبيعات" <?php echo (isset($editData['efawateer_entity']) && $editData['efawateer_entity'] == 'دائرة ضريبة الدخل والمبيعات') ? 'selected' : ''; ?>>دائرة ضريبة الدخل والمبيعات</option>
                                <option value="المؤسسة العامة للضمان الاجتماعي" <?php echo (isset($editData['efawateer_entity']) && $editData['efawateer_entity'] == 'المؤسسة العامة للضمان الاجتماعي') ? 'selected' : ''; ?>>المؤسسة العامة للضمان الاجتماعي
                                </option>
                                <option value="other" <?php echo (isset($editData['efawateer_entity']) && $editData['efawateer_entity'] == 'other') ? 'selected' : ''; ?>>جهة أخرى</option>
                            </select>
                            <div id="efawateer_other_container" style="display:none;">
                                <label for="efawateer_other_entity_name">اسم الجهة</label>
                                <input type="text" id="efawateer_other_entity_name" name="efawateer_other_entity_name"
                                    value="<?php echo htmlspecialchars($editData['efawateer_other_entity_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            </div>
                            <label for="efawateer_description" id="efawateer_desc_label">وصف السداد</label>
                            <input type="text" id="efawateer_description" name="efawateer_description"
                                placeholder="مثال: عن اقتطاعات الموظفين شهر 9-2025"
                                value="<?php echo htmlspecialchars($editData['efawateer_description'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">

                            <div id="efawateer_ref_container">
                                <label for="efawateer_reference">الرقم المرجعي</label>
                                <input type="text" id="efawateer_reference" name="efawateer_reference"
                                    value="<?php echo htmlspecialchars($editData['efawateer_reference'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            </div>
                        </div>

                        <div data-section="internal_cash" class="sections">
                            <div class="field-note">سيتم التحويل إلى حساب السيد أحمد حسين مصطفى أبو عيد تلقائياً.</div>
                        </div>

                        <div data-section="internal_eos" class="sections">
                            <label for="beneficiary_name">اسم المستفيد</label>
                            <input type="text" id="beneficiary_name" name="beneficiary_name"
                                data-required="internal_eos"
                                value="<?php echo htmlspecialchars($editData['beneficiary_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            <label for="beneficiary_iban">رقم الآيبان</label>
                            <input type="text" id="beneficiary_iban" name="beneficiary_iban"
                                data-required="internal_eos"
                                value="<?php echo htmlspecialchars($editData['beneficiary_iban'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                        </div>

                        <div data-section="claim_payment" class="sections">
                            <label for="claim_description">نوع المطالبة</label>
                            <input type="text" id="claim_description" name="claim_description"
                                data-required="claim_payment" placeholder="مثال: مطالبة الكهرباء والمياه"
                                value="<?php echo htmlspecialchars($editData['claim_description'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            <label for="claim_period_from">الفترة من</label>
                            <input type="text" id="claim_period_from" name="claim_period_from"
                                data-required="claim_payment" placeholder="مثال: 6-2025"
                                value="<?php echo htmlspecialchars($editData['claim_period_from'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            <label for="claim_period_to">الفترة إلى</label>
                            <input type="text" id="claim_period_to" name="claim_period_to" data-required="claim_payment"
                                placeholder="مثال: 7-2025"
                                value="<?php echo htmlspecialchars($editData['claim_period_to'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                        </div>

                        <div data-section="internal_general" class="sections">
                            <label for="internal_beneficiary_name">اسم المستفيد</label>
                            <input type="text" id="internal_beneficiary_name" name="internal_beneficiary_name"
                                data-required="internal_general"
                                value="<?php echo htmlspecialchars($editData['internal_beneficiary_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            <label for="internal_beneficiary_iban">رقم الآيبان</label>
                            <input type="text" id="internal_beneficiary_iban" name="internal_beneficiary_iban"
                                data-required="internal_general"
                                value="<?php echo htmlspecialchars($editData['internal_beneficiary_iban'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            <label for="internal_description">تفاصيل الدفعة</label>
                            <textarea id="internal_description" name="internal_description"
                                data-required="internal_general"
                                placeholder="مثال: بدل عمل اضافي"><?php echo htmlspecialchars($editData['internal_description'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                        </div>

                        <button type="submit">توليد الكتب PDF</button>
                    </form>
                </section>
            </div>
        </main>
    </div>

    <script>
        const requestType = document.getElementById('request_type');
        const sections = document.querySelectorAll('[data-section]');
        const requiredFields = document.querySelectorAll('[data-required]');

        // eFawateerCom specific elements
        const efawateerEntity = document.getElementById('efawateer_entity');
        const efawateerOtherContainer = document.getElementById('efawateer_other_container');
        const efawateerOtherName = document.getElementById('efawateer_other_entity_name');
        const efawateerDescLabel = document.getElementById('efawateer_desc_label');
        const efawateerDescInput = document.getElementById('efawateer_description');
        const efawateerRefContainer = document.getElementById('efawateer_ref_container');
        const efawateerRefInput = document.getElementById('efawateer_reference');

        function toggleSections() {
            const type = requestType.value;
            sections.forEach(section => {
                const list = section.dataset.section.split(',');
                section.style.display = list.includes(type) ? 'block' : 'none';
            });
            requiredFields.forEach(field => {
                // Skip eFawateer reference check here, handled separately
                if (field.id === 'efawateer_reference') return;

                const needed = field.dataset.required.split(',');
                field.required = needed.includes(type);
            });

            if (type === 'efawateer') {
                handleEfawateerChange();
            }
        }

        function handleEfawateerChange() {
            const entity = efawateerEntity.value;
            const isOther = entity === 'other';
            const isTax = entity === 'دائرة ضريبة الدخل والمبيعات';
            const isSS = entity === 'المؤسسة العامة للضمان الاجتماعي';

            // Toggle Other Name field
            efawateerOtherContainer.style.display = isOther ? 'block' : 'none';
            efawateerOtherName.required = isOther;

            // Customize Label and Placeholder
            if (isTax || isSS) {
                efawateerDescLabel.textContent = 'الشهر والسنة';
                efawateerDescInput.placeholder = 'مثال: 8-2025';
            } else {
                efawateerDescLabel.textContent = 'وصف السداد';
                efawateerDescInput.placeholder = 'وصف عملية السداد';
            }

            // Handle Reference Number
            if (isSS) {
                efawateerRefContainer.style.display = 'none';
                efawateerRefInput.value = '1777570000312237';
                efawateerRefInput.required = false; // logic handled backend/hidden
            } else {
                efawateerRefContainer.style.display = 'block';
                if (!isTax && !isOther && efawateerRefInput.value === '1777570000312237') {
                    efawateerRefInput.value = ''; // Clean up if switching back
                }
                efawateerRefInput.required = true;
            }
        }

        toggleSections();
        handleEfawateerChange();
        requestType.addEventListener('change', toggleSections);
        efawateerEntity.addEventListener('change', handleEfawateerChange);
    </script>
</body>

</html>