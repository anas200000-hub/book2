<?php
require_once __DIR__ . '/config.php';

const BANK_ACCOUNT_IBAN = 'JO98RJHI9010090100340010930618';
const INTERNAL_CASH_BENEFICIARY = 'أحمد حسين مصطفى أبو عيد';
const INTERNAL_CASH_IBAN = 'JO72RJHI9070090700340010025462';

function respond_with_error($message)
{
    header('Content-Type: text/plain; charset=UTF-8');
    echo $message;
    exit;
}

function normalize_amount($value)
{
    $clean = str_replace([' ', ','], '', $value);
    if (!preg_match('/^\d+(\.\d{1,3})?$/', $clean)) {
        return null;
    }
    return $clean;
}

function amount_to_fils($amountString)
{
    $parts = explode('.', $amountString);
    $dinars = (int) $parts[0];
    $fils = 0;
    if (isset($parts[1])) {
        $decimal = substr(str_pad($parts[1], 3, '0', STR_PAD_RIGHT), 0, 3);
        $fils = (int) $decimal;
    }
    return $dinars * 1000 + $fils;
}

function convert_number_to_words($number)
{
    $number = (int) $number;
    if ($number === 0) {
        return 'صفر';
    }
    $units = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة'];
    $teens = [10 => 'عشرة', 11 => 'أحد عشر', 12 => 'اثنا عشر', 13 => 'ثلاثة عشر', 14 => 'أربعة عشر', 15 => 'خمسة عشر', 16 => 'ستة عشر', 17 => 'سبعة عشر', 18 => 'ثمانية عشر', 19 => 'تسعة عشر'];
    $tens = ['', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
    $hundredsMap = [1 => 'مائة', 2 => 'مائتان', 3 => 'ثلاثمائة', 4 => 'أربعمائة', 5 => 'خمسمائة', 6 => 'ستمائة', 7 => 'سبعمائة', 8 => 'ثمانمائة', 9 => 'تسعمائة'];
    $scalesSingular = ['', 'ألف', 'مليون', 'مليار'];
    $scalesDual = ['', 'ألفان', 'مليونان', 'ملياران'];
    $scalesPlural = ['', 'آلاف', 'ملايين', 'مليارات'];

    $triplet = function ($n) use ($units, $teens, $tens, $hundredsMap) {
        $parts = [];
        $hundreds = (int) floor($n / 100);
        $remainder = $n % 100;
        if ($hundreds > 0) {
            $parts[] = $hundredsMap[$hundreds];
        }
        if ($remainder > 0) {
            if ($remainder < 10) {
                $parts[] = $units[$remainder];
            } elseif ($remainder < 20) {
                $parts[] = $teens[$remainder];
            } else {
                $ones = $remainder % 10;
                $tensIndex = (int) floor($remainder / 10);
                $segment = $tens[$tensIndex];
                if ($ones > 0) {
                    $parts[] = $units[$ones] . ' و ' . $segment;
                } else {
                    $parts[] = $segment;
                }
            }
        }
        return trim(implode(' و ', $parts));
    };

    $segments = [];
    $index = 0;
    while ($number > 0) {
        $value = $number % 1000;
        if ($value !== 0) {
            $words = $triplet($value);
            if ($index === 0) {
                $segments[] = $words;
            } else {
                if ($value === 1) {
                    $segments[] = $scalesSingular[$index];
                } elseif ($value === 2) {
                    $segments[] = $scalesDual[$index];
                } elseif ($value >= 3 && $value <= 10) {
                    $segments[] = ($words ? $words . ' ' : '') . $scalesPlural[$index];
                } else {
                    $segments[] = ($words ? $words . ' ' : '') . $scalesSingular[$index];
                }
            }
        }
        $number = (int) floor($number / 1000);
        $index++;
    }

    return implode(' و ', array_reverse($segments));
}

function get_ordinal_label($index)
{
    $labels = [
        1 => 'الأولى',
        2 => 'الثانية',
        3 => 'الثالثة',
        4 => 'الرابعة',
        5 => 'الخامسة',
        6 => 'السادسة',
        7 => 'السابعة',
        8 => 'الثامنة',
        9 => 'التاسعة',
        10 => 'العاشرة',
        11 => 'الحادية عشرة',
        12 => 'الثانية عشرة',
    ];
    return $labels[$index] ?? ($index . '');
}




function format_amount_text($filsValue)
{
    $dinars = intdiv($filsValue, 1000);
    $fils = $filsValue % 1000;
    $numeric = number_format($filsValue / 1000, 2, '.', ',');
    $words = convert_number_to_words($dinars);
    $text = ($words ? $words . ' دينار' : 'صفر دينار');
    if ($fils > 0) {
        $text .= ' و ' . $fils . ' فلس';
    }
    $text .= ' لا غير';
    return [
        'numeric' => '(' . $numeric . ' دينار)',
        'textual' => $text,
    ];
}



function generate_book_numbers($baseNumber, $count)
{
    if (!preg_match('/^\d{10}$/', $baseNumber)) {
        respond_with_error('تنسيق رقم الكتاب غير صحيح. الرجاء إدخال رقم مكون من 10 خانات.');
    }
    $prefix = substr($baseNumber, 0, 8);
    $startSuffix = (int) substr($baseNumber, -2);
    if ($startSuffix + $count - 1 > 99) {
        respond_with_error('لا يمكن توليد أكثر من 99 كتاباً في نفس التاريخ.');
    }
    $numbers = [];
    for ($i = 0; $i < $count; $i++) {
        $numbers[] = $prefix . str_pad($startSuffix + $i, 2, '0', STR_PAD_LEFT);
    }
    return $numbers;
}

$requestLabels = [
    'bank_transfer' => 'طلب حوالة بنكية',
    'efawateer' => 'طلب تسديد أي فواتيركم',
    'internal_cash' => 'طلب حوالة داخلية - عهدة مصاريف نقدية',
    'internal_eos' => 'طلب حوالة داخلية - مستحقات نهاية الخدمة',
    'claim_payment' => 'تسديد دفعة مطالبة',
    'internal_general' => 'طلب حوالة داخلية',
];

$requestType = $_POST['request_type'] ?? 'bank_transfer';
if (!array_key_exists($requestType, $requestLabels)) {
    respond_with_error('نوع الطلب غير صالح.');
}

$firstBookNumber = trim($_POST['first_book_number'] ?? '');
$bookDateInput = trim($_POST['book_date'] ?? '');
if ($bookDateInput === '') {
    $bookDateInput = date('Y-m-d');
}
$timestamp = strtotime($bookDateInput);
if ($timestamp === false) {
    respond_with_error('تنسيق التاريخ غير صحيح.');
}
$formattedDate = date('d / m / Y', $timestamp);
if ($firstBookNumber === '') {
    $firstBookNumber = date('Ymd', $timestamp) . '01';
}

$amountInput = $_POST['total_amount'] ?? '';
$normalizedAmount = normalize_amount($amountInput);
if ($normalizedAmount === null) {
    respond_with_error('الرجاء إدخال قيمة رقمية صحيحة للمبلغ.');
}
$totalAmountFils = amount_to_fils($normalizedAmount);
if ($totalAmountFils <= 0) {
    respond_with_error('المبلغ يجب أن يكون أكبر من صفر.');
}

$invoiceNumber = trim($_POST['invoice_number'] ?? '');
$serviceDescription = trim($_POST['service_description'] ?? '');
$supplierId = isset($_POST['supplier_id']) ? (int) $_POST['supplier_id'] : 0;
$efawateerEntitySelect = trim($_POST['efawateer_entity'] ?? '');
$efawateerOtherName = trim($_POST['efawateer_other_entity_name'] ?? '');
$efawateerDescriptionInput = trim($_POST['efawateer_description'] ?? '');
$efawateerReference = trim($_POST['efawateer_reference'] ?? '');

$efawateerEntity = $efawateerEntitySelect;
if ($efawateerEntitySelect === 'other') {
    $efawateerEntity = $efawateerOtherName;
}

// Logic to construct description and enforce reference based on Entity Type
$efawateerDescription = $efawateerDescriptionInput; // Default for 'other'
if ($efawateerEntitySelect === 'دائرة ضريبة الدخل والمبيعات' && $efawateerDescriptionInput !== '') {
    $efawateerDescription = 'اقتطاعات الموظفين لشهر ' . $efawateerDescriptionInput;
} elseif ($efawateerEntitySelect === 'المؤسسة العامة للضمان الاجتماعي') {
    if ($efawateerDescriptionInput !== '') {
        $efawateerDescription = 'اشتراكات الضمان الاجتماعي لشهر ' . $efawateerDescriptionInput;
    }
    // Enforce reference for Social Security
    $efawateerReference = '1777570000312237';
}

$beneficiaryName = trim($_POST['beneficiary_name'] ?? '');
$beneficiaryIban = trim($_POST['beneficiary_iban'] ?? '');
$claimDescription = trim($_POST['claim_description'] ?? '');
$claimPeriodFrom = trim($_POST['claim_period_from'] ?? '');
$claimPeriodTo = trim($_POST['claim_period_to'] ?? '');
$internalDescription = trim($_POST['internal_description'] ?? '');
$internalBeneficiaryName = trim($_POST['internal_beneficiary_name'] ?? '');
$internalBeneficiaryIban = trim($_POST['internal_beneficiary_iban'] ?? '');

switch ($requestType) {
    case 'bank_transfer':
        if ($supplierId === 0 || $invoiceNumber === '' || $serviceDescription === '') {
            respond_with_error('الرجاء تعبئة جميع حقول طلب الحوالة البنكية.');
        }
        break;
    case 'efawateer':
        if ($efawateerEntity === '' || $efawateerReference === '') {
            respond_with_error('الرجاء اختيار الجهة والرقم المرجعي لطلب تسديد أي فواتيركم.');
        }
        break;
    case 'internal_eos':
        if ($beneficiaryName === '' || $beneficiaryIban === '') {
            respond_with_error('الرجاء تعبئة اسم ورقم آيبان المستفيد لمستحقات نهاية الخدمة.');
        }
        break;
    case 'claim_payment':
        if ($invoiceNumber === '' || $claimDescription === '' || $claimPeriodFrom === '' || $claimPeriodTo === '') {
            respond_with_error('الرجاء تعبئة كامل بيانات مطالبة السداد.');
        }
        break;
    case 'internal_general':
        if ($internalBeneficiaryName === '' || $internalBeneficiaryIban === '' || $internalDescription === '') {
            respond_with_error('الرجاء تعبئة جميع حقول طلب الحوالة الداخلية.');
        }
        break;
    default:
        break;
}

$subjectText = $requestLabels[$requestType];
if ($requestType === 'claim_payment' && $invoiceNumber !== '') {
    $subjectText .= ' رقم ' . $invoiceNumber;
}
if ($requestType === 'internal_general' && $invoiceNumber !== '') {
    $subjectText .= ' رقم ' . $invoiceNumber;
}

$supplierInfo = null;
if ($requestType === 'bank_transfer') {
    $stmt = $pdo->prepare('SELECT beneficiary, bank_name, swift, iban FROM suppliers WHERE id = ? LIMIT 1');
    $stmt->execute([$supplierId]);
    $supplierInfo = $stmt->fetch();
    if (!$supplierInfo) {
        respond_with_error('لم يتم العثور على بيانات المورد المحدد.');
    }
}

$maxPerBookFils = 10000 * 1000;
$remaining = $totalAmountFils;
$amountChunks = [];
while ($remaining > 0) {
    $chunk = min($remaining, $maxPerBookFils);
    $amountChunks[] = $chunk;
    $remaining -= $chunk;
}

$bookNumbers = generate_book_numbers($firstBookNumber, count($amountChunks));

$entityTrackingName = '';
switch ($requestType) {
    case 'bank_transfer':
        $entityTrackingName = $supplierInfo['beneficiary'] ?? '';
        break;
    case 'efawateer':
        $entityTrackingName = $efawateerEntity;
        break;
    case 'internal_eos':
        $entityTrackingName = $beneficiaryName;
        break;
    case 'claim_payment':
        $entityTrackingName = 'مصرف الراجحي - تسديد مطالبة';
        break;
    case 'internal_general':
        $entityTrackingName = $internalBeneficiaryName;
        break;
    case 'internal_cash':
        $entityTrackingName = 'أحمد حسين مصطفى أبو عيد (عهدة)';
        break;
}

// Record in registry only if not a re-generation
if (!isset($_POST['re_generation'])) {
    $filtersPayload = $_POST;
    $filtersJson = json_encode($filtersPayload, JSON_UNESCAPED_UNICODE);
    $insert = $pdo->prepare('INSERT INTO books (book_number, title, entity_name, total_amount, filters_json) VALUES (?, ?, ?, ?, ?)');
    $insert->execute([$firstBookNumber, $subjectText, $entityTrackingName, ($totalAmountFils / 1000), $filtersJson]);
}

$logoDataUri = asset_data_uri('logo.png');
$signatureDataUri = asset_data_uri('signature.png');

$booksData = [];
$totalBooks = count($amountChunks);
foreach ($amountChunks as $index => $chunkFils) {
    $booksData[] = [
        'number' => $bookNumbers[$index],
        'amount_fils' => $chunkFils,
        'amount_display' => format_amount_text($chunkFils),
        'ordinal_phrase' => $totalBooks > 1 ? 'الدفعة ' . get_ordinal_label($index + 1) . ' ' : '',
    ];
}

function h($value)
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function asset_data_uri($filename)
{
    $path = __DIR__ . '/assets/' . $filename;
    if (!file_exists($path)) {
        return '';
    }
    $mime = mime_content_type($path) ?: 'image/png';
    $data = base64_encode(file_get_contents($path));
    return 'data:' . $mime . ';base64,' . $data;
}

$logoDataUri = asset_data_uri('logo.png');
$signatureDataUri = asset_data_uri('signature.png');

ob_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>كتب طلبات</title>
    <style>
        @page {
            size: A4;
            margin: 20mm;
        }

        body {
            font-family: "Arial", "Tahoma", sans-serif;
            direction: rtl;
            text-align: right;
            font-size: 16pt;
            margin: 0;
        }

        .page {
            min-height: 100%;
            position: relative;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            direction: ltr;
            margin-bottom: 10px;
        }

        .logo {
            text-align: left;
        }

        .logo img {
            max-height: 140px;
        }

        .info {
            text-align: right;
            direction: rtl;
            margin-top: -32pt;
        }

        .info .line {
            margin-bottom: 6px;
            font-size: 14pt;
        }

        .info .number-line {
            margin-right: 3mm;
        }

        .book-number {
            letter-spacing: 0.16mm;
        }

        .greeting {
            margin-top: 12px;
            font-size: 16pt;
        }

        .greeting .bold {
            font-weight: bold;
        }

        .subject-line {
            margin: 25px 0 15px;
            text-align: center;
        }

        .subject-line span {
            display: inline-block;
            border-bottom: 1px solid #000;
            padding: 0 10px 5px;
            font-weight: bold;
            font-size: 16pt;
        }

        .body-text {
            font-size: 16pt;
        }

        .body-text p {
            margin: 0 0 12px;
            line-height: 1.7;
        }

        .supplier-block {
            margin-top: 15px;
            text-align: left;
            direction: ltr;
            font-size: 16pt;
        }

        .supplier-block div {
            margin-bottom: 4px;
        }

        .respect-spacer {
            height: 16pt;
        }

        .respect {
            text-align: center;
            font-weight: bold;
            font-size: 16pt;
            margin: 16pt 0 32pt 0;
        }

        .footer {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
        }

        .footer-left {
            text-align: left;
            direction: ltr;
            font-size: 16pt;
        }

        .footer-left .company {
            font-weight: bold;
            margin-left: 23mm;
            margin-bottom: 8pt;
        }

        .signature {
            text-align: right;
            margin-top: 32pt;
        }

        .signature img {
            max-height: 130px;
        }

        .page-break {
            page-break-after: always;
        }
    </style>
</head>

<body>
    <?php foreach ($booksData as $idx => $book): ?>
        <div class="page">
            <div class="header">
                <div class="logo">
                    <?php if ($logoDataUri !== ''): ?>
                        <img src="<?php echo h($logoDataUri); ?>" alt="Logo">
                    <?php endif; ?>
                </div>
                <div class="info">
                    <div class="line">التاريخ: <?php echo h($formattedDate); ?></div>
                    <div class="line number-line">الرقم: <span class="book-number"><?php echo h($book['number']); ?></span>
                    </div>
                    <div style="height: 16pt;"></div>
                    <div class="greeting">
                        <div class="bold">السادة مصرف الراجحي المحترمين</div>
                        <div>الفرع الرئيسي؛</div>
                        <div>تحية طيبة وبعد،،</div>
                    </div>
                </div>
            </div>
            <div class="subject-line">
                <span>الموضوع: <?php echo h($subjectText); ?></span>
            </div>
            <div class="body-text">
                <?php switch ($requestType):
                    case 'bank_transfer': ?>
                        <p>
                            يرجى التكرم بالعمل على تحويل مبلغ <span
                                class="amount"><?php echo h($book['amount_display']['numeric']); ?></span>
                            <?php echo h($book['amount_display']['textual']); ?>، من حسابنا لديكم رقم
                            <?php echo BANK_ACCOUNT_IBAN; ?>،
                            وذلك <?php echo h($book['ordinal_phrase']); ?>عن سداد فاتورة رقم <?php echo h($invoiceNumber); ?>
                            <?php echo h($serviceDescription); ?>،
                            على الحساب التالي:
                        </p>
                        <div class="supplier-block">
                            <div>- <strong>Beneficiary:</strong> <?php echo h($supplierInfo['beneficiary']); ?></div>
                            <div>- <strong>Bank name:</strong> <?php echo h($supplierInfo['bank_name']); ?></div>
                            <div>- <strong>Bank Swift:</strong> <?php echo h($supplierInfo['swift']); ?></div>
                            <div>- <strong>IBAN:</strong> <?php echo h($supplierInfo['iban']); ?></div>
                        </div>
                        <?php break;
                    case 'efawateer': ?>
                        <p>
                            يرجى التكرم بالعمل على تسديد مبلغ <span
                                class="amount"><?php echo h($book['amount_display']['numeric']); ?></span>
                            <?php echo h($book['amount_display']['textual']); ?>، من حسابنا لديكم رقم
                            <?php echo BANK_ACCOUNT_IBAN; ?>،
                            إلى
                            <?php echo h($efawateerEntity); ?>             <?php if ($book['ordinal_phrase'] !== '')
                                                echo ' - ' . trim($book['ordinal_phrase']); ?>
                            <?php if ($efawateerDescription !== ''): ?>
                                عن
                                <?php echo h($efawateerDescription); ?>             <?php endif; ?>
                            على الرقم المرجعي (<?php echo h($efawateerReference); ?>).
                        </p>
                        <?php break;
                    case 'internal_cash': ?>
                        <p>
                            يرجى التكرم بالعمل على تحويل مبلغ <span
                                class="amount"><?php echo h($book['amount_display']['numeric']); ?></span>
                            <?php echo h($book['amount_display']['textual']); ?>، من حسابنا لديكم رقم
                            <?php echo BANK_ACCOUNT_IBAN; ?>،
                            إلى حساب السيد <?php echo INTERNAL_CASH_BENEFICIARY; ?> رقم (<?php echo INTERNAL_CASH_IBAN; ?>).
                        </p>
                        <?php break;
                    case 'internal_eos': ?>
                        <p>
                            يرجى التكرم بالعمل على تحويل مبلغ <span
                                class="amount"><?php echo h($book['amount_display']['numeric']); ?></span>
                            <?php echo h($book['amount_display']['textual']); ?>، من حسابنا لديكم رقم
                            <?php echo BANK_ACCOUNT_IBAN; ?>،
                            إلى <?php echo h($beneficiaryName); ?> رقم (<?php echo h($beneficiaryIban); ?>) وذلك عن مستحقات نهاية
                            الخدمة.
                        </p>
                        <?php break;
                    case 'claim_payment': ?>
                        <p>
                            يرجى التكرم بالعمل على قيد مبلغ <span
                                class="amount"><?php echo h($book['amount_display']['numeric']); ?></span>
                            <?php echo h($book['amount_display']['textual']); ?>، من حسابنا لديكم رقم
                            <?php echo BANK_ACCOUNT_IBAN; ?>،
                            لصالح مصرف الراجحي وذلك عن تسديد <?php echo h($claimDescription); ?> رقم
                            <?php echo h($invoiceNumber); ?>
                            عن الفترة من <?php echo h($claimPeriodFrom); ?> إلى <?php echo h($claimPeriodTo); ?>.
                        </p>
                        <?php break;
                    case 'internal_general': ?>
                        <p>
                            يرجى التكرم بالعمل على تحويل مبلغ <span
                                class="amount"><?php echo h($book['amount_display']['numeric']); ?></span>
                            <?php echo h($book['amount_display']['textual']); ?>، من حسابنا لديكم رقم
                            <?php echo BANK_ACCOUNT_IBAN; ?>،
                            إلى حساب <?php echo h($internalBeneficiaryName); ?> رقم (<?php echo h($internalBeneficiaryIban); ?>)
                            وذلك عن <?php echo h($internalDescription); ?>.
                        </p>
                <?php endswitch; ?>
            </div>
            <div class="respect-spacer"></div>
            <div class="respect">وتفضلوا بقبول فائق الإحترام والتقدير</div>
            <div class="footer">
                <div class="footer-left">
                    <div class="company">شركة اجادة للنظم </div>
                    <div>المفوض بالتوقيع: السيد نبيل موسى البكيرات</div>
                </div>
                <div class="signature">
                    <div style="height: 16pt;"></div>
                    <?php if ($signatureDataUri !== ''): ?>
                        <img src="<?php echo h($signatureDataUri); ?>" alt="Signature">
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php if ($idx < count($booksData) - 1): ?>
            <div class="page-break"></div>
        <?php endif; ?>
    <?php endforeach; ?>
</body>

</html>
<?php
$html = ob_get_clean();
$tmpDir = __DIR__ . '/tmp';
if (!is_dir($tmpDir)) {
    mkdir($tmpDir, 0777, true);
}
$htmlFile = $tmpDir . '/book_' . $firstBookNumber . '.html';
$pdfFile = $tmpDir . '/book_' . $firstBookNumber . '.pdf';
file_put_contents($htmlFile, $html);
$wkhtml = '"C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe"';
$command = $wkhtml . ' --margin-left 25mm --margin-right 25mm --margin-top 10mm --margin-bottom 10mm ' . escapeshellarg($htmlFile) . ' ' . escapeshellarg($pdfFile);
shell_exec($command);
$pdfFileName = 'book_' . $firstBookNumber . '.pdf';

if ($requestType === 'bank_transfer') {
    $supplierName = $supplierInfo['beneficiary'] ?? '';
    $pdfFileName = "حوالة " . $supplierName . " عن فاتورة " . $invoiceNumber . ".pdf";
} elseif ($requestType === 'efawateer') {
    $pdfFileName = "دفعات " . $efawateerEntity . " شهر " . $efawateerDescriptionInput . ".pdf";
} elseif ($requestType === 'internal_cash') {
    $pdfFileName = "حوالة عهدة نثرية.pdf";
} elseif ($requestType === 'internal_eos') {
    $pdfFileName = "حوالة مستحقات نهاية الخدمة " . $beneficiaryName . ".pdf";
} elseif ($requestType === 'claim_payment') {
    $pdfFileName = "حوالة تسديد مطالبة الكهرباء والمياه - الراجحي.pdf";
} elseif ($requestType === 'internal_general') {
    $pdfFileName = "طلب حوالة داخلية.pdf";
}

if (file_exists($pdfFile)) {
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $pdfFileName . '"');
    readfile($pdfFile);
    unlink($htmlFile);
    unlink($pdfFile);
    exit;
}
respond_with_error('لم يتم إنشاء ملف PDF. تأكد من مسار wkhtmltopdf.');
