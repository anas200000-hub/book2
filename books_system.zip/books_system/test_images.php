<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>Test Images</title>
</head>
<body>
    <p>اختبار صورة اللوجو:</p>
    <img src="assets/logo.png" style="max-height:80px;"><br>

    <p>اختبار صورة التوقيع:</p>
    <img src="assets/signature.png" style="max-height:80px;">
</body>
</html>