<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>آلة حاسبة تفاعلية</title>
    <link rel="icon" href="assets/anas_logo.png">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #004a8f;
            --bg: #1e293b;
            --calc-bg: #0f172a;
            --btn-op: #3b82f6;
            --btn-num: #334155;
            --accent: #fbbf24;
        }

        body {
            margin: 0;
            padding: 20px;
            font-family: 'Cairo', sans-serif;
            background: var(--bg);
            color: #fff;
            display: flex;
            flex-direction: column;
            height: 100vh;
            box-sizing: border-box;
        }

        .calc-container {
            flex: 1;
            display: grid;
            grid-template-columns: 1fr;
            grid-template-rows: auto 1fr auto;
            gap: 15px;
        }

        .display-area {
            background: var(--calc-bg);
            padding: 20px;
            border-radius: 16px;
            text-align: left;
            box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.5);
        }

        #prev-op {
            color: #94a3b8;
            font-size: 14px;
            min-height: 20px;
            word-wrap: break-word;
        }

        #current-op {
            font-size: 32px;
            font-weight: 700;
            margin-top: 5px;
            word-wrap: break-word;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }

        button {
            padding: 15px;
            font-size: 20px;
            font-weight: 700;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.2s;
            font-family: inherit;
        }

        .btn-num {
            background: var(--btn-num);
            color: #fff;
        }

        .btn-op {
            background: var(--btn-op);
            color: #fff;
        }

        .btn-danger {
            background: #ef4444;
            color: #fff;
        }

        .btn-accent {
            background: var(--accent);
            color: #000;
        }

        button:hover {
            filter: brightness(1.2);
            transform: scale(1.02);
        }

        button:active {
            transform: scale(0.95);
        }

        .history-panel {
            background: rgba(15, 23, 42, 0.5);
            border-radius: 16px;
            padding: 15px;
            max-height: 150px;
            overflow-y: auto;
            border: 1px solid #334155;
        }

        .history-title {
            font-size: 14px;
            font-weight: 700;
            color: var(--accent);
            margin-bottom: 8px;
            border-bottom: 1px solid #334155;
            padding-bottom: 4px;
        }

        .history-item {
            font-size: 13px;
            color: #cbd5e1;
            padding: 4px 0;
            border-bottom: 1px solid #1e293b;
            text-align: left;
            cursor: pointer;
        }

        .history-item:hover {
            color: #fff;
        }

        .close-btn {
            background: #64748b;
            color: #fff;
            width: 100%;
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="calc-container">
        <div class="display-area">
            <div id="prev-op"></div>
            <div id="current-op">0</div>
        </div>

        <div class="grid">
            <button class="btn-danger" onclick="clearCalc()">C</button>
            <button class="btn-op" onclick="appendOp('/')">÷</button>
            <button class="btn-op" onclick="appendOp('*')">×</button>
            <button class="btn-danger" onclick="deleteLast()">DEL</button>

            <button class="btn-num" onclick="appendNum('7')">7</button>
            <button class="btn-num" onclick="appendNum('8')">8</button>
            <button class="btn-num" onclick="appendNum('9')">9</button>
            <button class="btn-op" onclick="appendOp('-')">-</button>

            <button class="btn-num" onclick="appendNum('4')">4</button>
            <button class="btn-num" onclick="appendNum('5')">5</button>
            <button class="btn-num" onclick="appendNum('6')">6</button>
            <button class="btn-op" onclick="appendOp('+')">+</button>

            <button class="btn-num" onclick="appendNum('1')">1</button>
            <button class="btn-num" onclick="appendNum('2')">2</button>
            <button class="btn-num" onclick="appendNum('3')">3</button>
            <button class="btn-accent" style="grid-row: span 2;" onclick="calculate()">=</button>

            <button class="btn-num" style="grid-column: span 2;" onclick="appendNum('0')">0</button>
            <button class="btn-num" onclick="appendNum('.')">.</button>
        </div>

        <div class="history-panel">
            <div class="history-title">سجل العمليات</div>
            <div id="history-list"></div>
        </div>

        <button class="close-btn" onclick="window.close()">إغلاق الآلة الحاسبة</button>
    </div>

    <script>
        let currentInput = "0";
        let previousInput = "";
        let history = [];

        const currentDisplay = document.getElementById('current-op');
        const prevDisplay = document.getElementById('prev-op');
        const historyList = document.getElementById('history-list');

        function updateDisplay() {
            currentDisplay.innerText = currentInput;
            prevDisplay.innerText = previousInput;
        }

        function appendNum(num) {
            if (currentInput === "0" && num !== ".") {
                currentInput = num;
            } else {
                if (num === "." && currentInput.includes(".")) return;
                currentInput += num;
            }
            updateDisplay();
        }

        function appendOp(op) {
            if (currentInput === "" && previousInput === "") return;
            if (currentInput === "") {
                previousInput = previousInput.slice(0, -1) + op;
            } else {
                previousInput = currentInput + op;
                currentInput = "";
            }
            updateDisplay();
        }

        function clearCalc() {
            currentInput = "0";
            previousInput = "";
            updateDisplay();
        }

        function deleteLast() {
            if (currentInput.length > 1) {
                currentInput = currentInput.slice(0, -1);
            } else {
                currentInput = "0";
            }
            updateDisplay();
        }

        function calculate() {
            if (previousInput === "" || currentInput === "") return;

            let expression = previousInput + currentInput;
            try {
                let result = eval(expression);
                // Handle decimals
                if (result.toString().includes('.')) {
                    result = parseFloat(result.toFixed(4));
                }

                addToHistory(expression + " = " + result);
                currentInput = result.toString();
                previousInput = "";
                updateDisplay();
            } catch (e) {
                currentInput = "Error";
                updateDisplay();
            }
        }

        function addToHistory(item) {
            history.unshift(item);
            if (history.length > 20) history.pop();
            renderHistory();
        }

        function renderHistory() {
            historyList.innerHTML = history.map(item => `<div class="history-item" onclick="loadHistory('${item}')">${item}</div>`).join('');
        }

        function loadHistory(item) {
            const parts = item.split(' = ');
            currentInput = parts[1];
            previousInput = "";
            updateDisplay();
        }

        // Support Keyboard
        window.addEventListener('keydown', (e) => {
            if (e.key >= 0 && e.key <= 9) appendNum(e.key);
            if (e.key === '.') appendNum('.');
            if (e.key === '+' || e.key === '-' || e.key === '*' || e.key === '/') appendOp(e.key);
            if (e.key === 'Enter' || e.key === '=') calculate();
            if (e.key === 'Backspace') deleteLast();
            if (e.key === 'Escape') clearCalc();
        });
    </script>
</body>

</html>